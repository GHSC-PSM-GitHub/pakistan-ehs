$(function () {
  $("#batch").change(function () {
    var batch_id = $("#batch").val();
    $.ajax({
      type: "POST",
      url: "get_batch_info",
      data: {
        batch_id: batch_id,
      },
      dataType: "json",
      success: function (data) {
        $("#available_quantity").val(data.available_qty);
        $("#quantity").attr("max", data.available_qty);
        $("#batch_expiry").val(data.expiry_date);
      },
    });
  });

  $("#stock_issue").validate({
    rules: {
      refernce_number: "required",
      issuance_time: "required",
      product: "required",
      batch: "required",
      expiry_date: "required",
      quantity: {
        required: true,
        number: true,
        min: 1,
        step: 1,
      },
    },
  });

  $("#product").change(function () {
    $("#batch").attr("disabled", true);
    var product = $("#product").val();
    var wh_id = $("#center_from").val();
    $.ajax({
      type: "POST",
      url: "get_batches_of_wh",
      data: {
        item_id: product,
        wh_id: wh_id,
      },
      dataType: "html",
      success: function (data) {
        alertify.success("Please select the Batch now.");
        $("#batch").attr("disabled", false);
        $("#batch").html(data);
        $("#batch").trigger("change");
      },
    });
  });

  $("#center_from").change(function () {
    $("#product").attr("disabled", true);
    var id = $(this).val();
    $.ajax({
      type: "POST",
      url: "get_available_prods_of_wh",
      data: {
        wh_id: id,
      },
      dataType: "html",
      success: function (data) {
        if (!data) {
          alertify.error("No Stock available at this center");
        } else {
          //alertify.success("Please select the product now.");
          $("#product").attr("disabled", false);
          $("#product").html(data);
        }
      },
    });
  });
  
  $("#issue_to").change(function () {
    $.ajax({
      type: "POST",
      url: "get_center_patients",
      data: {
        issue_type: $(this).val(),
      },
      dataType: "html",
      success: function (data) {
        $("#center_patient").html(data);
      },
    });
  });
  $("#save_temp_issue").click(function () {
    $.ajax({
      type: "POST",
      url: "save_temporary_records",
      data: {
        stock_master_id: $("#stock_master_id").val(),
      },
      dataType: "html",
      success: function (data) {
        window.location.href = "stock_issue_search";
      },
    });
  });
});

deletepp();
function deletepp() {
  $("button[id$='-deletepp']").click(function () {
    if (confirm("Are you sure you want to remove?")) {
      var value = $(this).attr("id");
      var params = value.replace("-deletepp", "");
      var arr = params.split("_");

      $.ajax({
        type: "POST",
        url: "ajax_del_stock_detail",
        data: {
          b_id: arr[0],
          d_id: arr[1]
        },
        dataType: "html",
        success: function (data) {
          window.location = baseurl + "inventory_management/stock_issue";
        },
      });

    }
  });
}
