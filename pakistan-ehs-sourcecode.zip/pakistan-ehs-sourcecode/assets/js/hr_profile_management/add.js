$("#pmc_expiry, #dob, #doj").datepicker({
  format: "dd/mm/yyyy",
});

$(".searchable").select2({
  selectOnClose: true,
});
