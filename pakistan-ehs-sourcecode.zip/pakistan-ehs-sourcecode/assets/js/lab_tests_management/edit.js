$(function () {
  console.log("ready!");
  $("#btn_add_item").click(function () {
    $("#div_add_item").slideDown();
    $("html, body").animate(
      {
        scrollTop: $("#add_form").offset().top,
      },
      1000
    );
  });
});
