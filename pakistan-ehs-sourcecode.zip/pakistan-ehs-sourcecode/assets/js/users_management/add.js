$(function () {
  $("#add_user_form").validate({
    rules: {
      username: "required",
      login_id: "required",
      password: "required",
      confirm_password: {
        required: true,
        equalTo: "#password",
      },
      email: "required",
      phone: {
        required: true,
        number: true,
      },
      province: "required",
      district: "required",
      role_id: "required",
      status: "required",
    },
  });
});
