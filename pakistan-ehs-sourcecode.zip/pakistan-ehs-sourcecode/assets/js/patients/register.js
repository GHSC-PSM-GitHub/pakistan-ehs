$("#btnrdt").click(function () {
  $.post("ajax_add_rdt", $("#rdt").serialize(), function (data, status) {
    $("#rdt_result").html(data);
    delete_rdt();
  });
});

$("form#data").validate();
calculate_age();

//$("form#data").submit(function (e) {
/*$.post(
    "ignore_duplication",
    { name: $("#full_name").val(), cnic: $("#nic_no").val() },
    function (data, status) {
      if (data) {
        e.preventDefault();
        $("#p_result").html(data);
        $(".patient-detail").modal();
      }
    }
  );
*/
/*var cnic = $("#cnic").val();
  var mobile_phone = $("#mobile_phone").val();
  var landline = $("#landline").val();

  if (cnic == "" && mobile_phone == "" && landline == "") {
    e.preventDefault();
    alert(
      "Please enter at least one of the following information. CNIC, Mobile Number Landline Number"
    );
  }*/
//});

/*var typed_into = false;
$("#cnic").on({
  keypress: function () {
    typed_into = true;
    $("#cnic").inputmask({ mask: "99999-9999999-9", placeholder: "" });
  },
  change: function () {
    if (typed_into) {
      alert("type");
      typed_into = false; //reset type listener
    } else {
      //var str = $("#cnic").val();
      //str.substring(12);
      //alert(str);
      //$("#cnic").val(str);
      $("#cnic").inputmask({ mask: "99999-9999999-9", placeholder: "" });
      alert("not type");
    }
    
  },
});*/

$("#cnic").inputmask({ mask: "99999-9999999-9", placeholder: "" });
$("#mobile_phone").inputmask({ mask: "(0999) 999-9999", placeholder: "" });
$("#landline").inputmask({ mask: "(099) 999-9999", placeholder: "" });

$("#father_guardian_nic").inputmask();
$("#reg_fees").inputmask({ mask: "9", repeat: 10, greedy: false });
$("#age").inputmask({ mask: "9", repeat: 3, greedy: false });

$(".check_duplicate").change(function () {
  $.post(
    "check_duplicate",
    { text: $(this).val(), id: $(this).attr("id") },
    function (data, status) {
      if (data) {
        $("#p_result").html(data);
        $(".patient-detail").modal();
      }
    }
  );
});

$(".searchable").select2({
  selectOnClose: true,
});

function calculate_age(dob, method) {
  if (method == "age2dob") {
    var birthDate = moment().subtract(dob, "years");
    $("#day").val(birthDate.format("D"));
    $("#month").val(birthDate.format("M"));
    $("#year").val(birthDate.format("YYYY"));
  } else {
    var dob =
      $("#year").val() + "-" + $("#month").val() + "-" + $("#day").val();
    var a = moment();
    var b = moment(dob, "YYYY-MM-DD");
    var age_dt = a.diff(b, "years");

    $("#age").val(age_dt);
  }
}

function delete_rdt() {
  $("button[id$='-delete']").click(function () {
    if (confirm("Are you sure you want to delete?")) {
      var value = $(this).attr("id");
      var params = value.replace("-delete", "");
      var arr = params.split("_");
      $.post(
        "ajax_del_rdt",
        {
          pk_id: arr[0],
          p_id: arr[1],
        },
        function (data, status) {
          $("#rdt_result").html(data);
          delete_rdt();
        }
      );
    }
  });
}

$("#btnpreexam").click(function () {
  if ($("#visit_code_master").val() != "") {
    var data = $("#preexam").serializeArray();
    data.push({ name: "visit_date", value: $("#visit_code_master").val() });

    $.post("ajax_add_preexam", data, function (data, status) {
      $("#preexam_result").html(data);
      delete_preexam();
    });
  } else {
    alert("Please select visit code!");
  }
});

$("#markto").change(function () {
  $.post("fetch_combo", { id: $("#markto").val() }, function (data, status) {
    $("#facility_div").html(data);
  });
});

$("#lab_list").change(function () {
  $.post(
    "ajax_get_labs",
    { id: $("#lab_list").val() },
    function (data, status) {
      $("#lab_test_div").html(data);
      $("#lab_test").select2();
    }
  );
});

function delete_preexam() {
  $("button[id$='-deletepreexam']").click(function () {
    if (confirm("Are you sure you want to cancel?")) {
      var value = $(this).attr("id");
      var params = value.replace("-deletepreexam", "");
      var arr = params.split("_");
      $.post(
        "ajax_del_preexam",
        {
          pk_id: arr[0],
          p_id: arr[1],
        },
        function (data, status) {
          $("#preexam_result").html(data);
          delete_preexam();
        }
      );
    }
  });
}

$("#btnlabtest").click(function () {
  $.post(
    "ajax_add_labtest",
    $("#labtest").serialize(),
    function (data, status) {
      $("#labtest_result").html(data);
      delete_labtest();
    }
  );
});

function delete_labtest() {
  $("button[id$='-deletelab']").click(function () {
    if (confirm("Are you sure you want to cancel?")) {
      var value = $(this).attr("id");
      var params = value.replace("-deletelab", "");
      var arr = params.split("_");
      $.post(
        "ajax_del_labtest",
        {
          pk_id: arr[0],
          p_id: arr[1],
        },
        function (data, status) {
          $("#labtest_result").html(data);
          delete_labtest();
        }
      );
    }
  });
}

$("#btnop").click(function () {
  if ($("#visit_code_master").val() != "") {
    var dataa = $("#form_op").serializeArray();
    dataa.push({ name: "visit_code", value: $("#visit_code_master").val() });

    $.post(
      "ajax_add_otherproduct",
      dataa,
      function (data, status) {
        $("#op_result").html(data);
        delete_op();
      }
    );
  } else {
    alert("Please select visit code!");
  }

  
});

function delete_op() {
  $("button[id$='-deleteop']").click(function () {
    if (confirm("Are you sure you want to cancel?")) {
      var value = $(this).attr("id");
      var params = value.replace("-deleteop", "");
      var arr = params.split("_");
      $.post(
        "ajax_del_otherproduct",
        {
          pk_id: arr[0],
          p_id: arr[1],
        },
        function (data, status) {
          $("#op_result").html(data);
          delete_op();
        }
      );
    }
  });
}

$("#test_date, #sample_date, #start_date, #last_dose_date").datepicker({
  format: "dd/mm/yyyy",
});

$("#visit_date").datetimepicker();

$("#btncnote").click(function () {
  if ($("#visit_code_master").val() != "") {
    var dataa = $("#cnotes").serializeArray();
    dataa.push({ name: "disease_date", value: $("#visit_code_master").val() });

    $.post("ajax_add_cnote", dataa, function (data, status) {
      $("#cnote_result").html(data);
      delete_cnote();
    });
  } else {
    alert("Please select visit code!");
  }
});

function delete_cnote() {
  $("button[id$='-deletecnote']").click(function () {
    if (confirm("Are you sure you want to cancel?")) {
      var value = $(this).attr("id");
      var params = value.replace("-deletecnote", "");
      var arr = params.split("_");
      $.post(
        "ajax_del_cnote",
        {
          pk_id: arr[0],
          p_id: arr[1],
        },
        function (data, status) {
          $("#cnote_result").html(data);
          delete_cnote();
        }
      );
    }
  });
}

$("#btnipd").click(function () {
  $.post("ajax_add_ipd", $("#ipd").serialize(), function (data, status) {
    $("#ipd_result").html(data);
    delete_ipd();
  });
});

delete_ps();
delete_ba();
delete_labtest();
delete_preexam();
delete_cnote();
deletepp();

$("#btndischarge").click(function () {
  $.post(
    "ajax_add_discharge",
    $("#form_discharge").serialize(),
    function (data, status) {
      alert("Patient has been discharged successfully!");
      //$("#discharge_result").html(data);
    }
  );
});

$("#btnps").click(function () {
  if ($("#facility").val()) {
    $.post("ajax_add_ps", $("#form_ps").serialize(), function (data, status) {
      $("#ps_result").html(data);
      $("#add_notes").val(parseInt($("#add_notes").val()) + 1);
      delete_ps();
    });
  } else {
    alert("Please select department");
  }
});
var fewSeconds = 5;
$('#btnps').click(function(){
    // Ajax request
    var btn = $(this);
    btn.prop('disabled', true);
    setTimeout(function(){
        btn.prop('disabled', false);
    }, fewSeconds*1000);
});
function delete_ps() {
  $("button[id$='-deleteps']").click(function () {
    if (confirm("Are you sure you want to cancel?")) {
      var value = $(this).attr("id");
      var params = value.replace("-deleteps", "");
      var arr = params.split("_");
      $.post(
        "ajax_del_ps",
        {
          pk_id: arr[0],
          p_id: arr[1],
        },
        function (data, status) {
          $("#ps_result").html(data);
          delete_ps();
        }
      );
    }
  });
}

$("#btnba").click(function () {
  $.post("ajax_add_ba", $("#form_ba").serialize(), function (data, status) {
    $("#ba_result").html(data);
    delete_ba();
  });
});

function delete_ba() {
  $("button[id$='-deleteba']").click(function () {
    if (confirm("Are you sure you want to cancel?")) {
      var value = $(this).attr("id");
      var params = value.replace("-deleteba", "");
      var arr = params.split("_");
      $.post(
        "ajax_del_ba",
        {
          pk_id: arr[0],
          p_id: arr[1],
        },
        function (data, status) {
          $("#ba_result").html(data);
          delete_ba();
        }
      );
    }
  });
}

function delete_ipd() {
  $("button[id$='-deleteipd']").click(function () {
    if (confirm("Are you sure you want to cancel?")) {
      var value = $(this).attr("id");
      var params = value.replace("-deleteipd", "");
      var arr = params.split("_");
      $.post(
        "ajax_del_ipd",
        {
          pk_id: arr[0],
          p_id: arr[1],
        },
        function (data, status) {
          $("#ipd_result").html(data);
          delete_ipd();
        }
      );
    }
  });
}

$("#btnprescription").click(function () {
  if ($("#visit_code_master").val() != "" && $("#product").val() != "") {
    $("#prescriptions").validate();
    var dataa = $("#prescriptions").serializeArray();
    dataa.push({ name: "visit_code", value: $("#visit_code_master").val() });

    $.post(
      baseurl + "inventory_management/stock_issue_patients2",
      dataa,
      function (data, status) {
        $("#prescription_result").html(data);
        deletepp();
      }
    );
    $('form#prescriptions').trigger("reset");
    $('form#prescriptions select').trigger("change");
  } else {
    alert("Please select visit code and product!");
  }

  
});



function deletepp() {
  $("button[id$='-deletepp']").click(function () {
    if (confirm("Are you sure you want to cancel?")) {
      var value = $(this).attr("id");
      var params = value.replace("-deletepp", "");
      var arr = params.split("_");
      $.post(
        baseurl + "inventory_management/ajax_del_patient_pres",
        {
          b_id: arr[0],
          d_id: arr[1],
          m_id: arr[2],
          p_id: arr[3]
        },
        function (data, status) {
          $("#prescription_result").html(data);
          deletepp();
        }
      );
    }
  });
}

function delete_prescription() {
  $("button[id$='-deleteprescription']").click(function () {
    if (confirm("Are you sure you want to cancel?")) {
      var value = $(this).attr("id");
      var params = value.replace("-deleteprescription", "");
      var arr = params.split("_");
      $.post(
        "ajax_del_prescription",
        {
          pk_id: arr[0],
          p_id: arr[1],
        },
        function (data, status) {
          $("#prescription_result").html(data);
          delete_prescription();
        }
      );
    }
  });
}

$("#token").click(function () {
  $("#gen-token").slideDown();
});

$("#consultant").change(function () {
  var markto = $("#markto").val();
  if (markto == 1 || markto == 2) {
    $("#get-token").slideDown();

    var txt = $("#consultant option:selected").text();
    let suffix = parseInt(txt.match(/\d+/));
    let token = suffix + 1;
    $("#tokenno").html(token);
    var pname = $("#full_name").val();
    $("#patientname").html(pname);
    words = txt.split("(");
    $("#consultantname").html(words[0]);
  } else {
    $("#get-token").hide();
  }
});

$("#generate_token").click(function () {
  $.post(
    "ajax_gen_token",
    {
      p_id: $("#pk_id").val(),
      d_id: $("#doctors").val(),
    },
    function (data, status) {
      $(".token").html(data);
      $(".token").show();
      //$(".token").slideToggle();
    }
  );
});

function printdiv() {
  $("#printbtn").hide();
  var prtContent = $("#get-token");
  var WinPrint = window.open(
    "",
    "",
    "left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0"
  );
  WinPrint.document.write(prtContent.html());
  WinPrint.document.close();
  WinPrint.focus();
  WinPrint.print();
  WinPrint.close();
  $("#printbtn").show();
}

$("#hr_type_id").change(function () {
  $.post("ajax_get_hr", { id: $(this).val() }, function (data, status) {
    $("#hr_id").html(data);
  });
});

$(function () {
  $("#prescriptions").validate({
    rules: {
      refernce_number: "required",
      issuance_time: "required",
      product: "required",
      batch: "required",
      expiry_date: "required",
      quantity: {
        required: true,
        number: true,
        min: 1,
        step: 1,
      },
    },
  });

  $("#product").change(function () {
    $("#batch").attr("disabled", true);
    var product = $("#product").val();
    var wh_id = $("#center_from").val();
    $.ajax({
      type: "POST",
      url: baseurl + "inventory_management/get_batches_of_wh",
      data: {
        item_id: product,
        wh_id: wh_id,
      },
      dataType: "html",
      success: function (data) {
        //alertify.success("Please select the Batch now.");
        $("#batch").attr("disabled", false);
        $("#batch").html(data);
        $("#batch").trigger("change");
      },
    });
  });

  $("#product").change(function () {
    var product = $("#product").val();
    $.ajax({
      type: "POST",
      url: baseurl + "inventory_management/get_product_unit",
      data: {
        item_id: product,
      },
      dataType: "html",
      success: function (data) {
        $("#prod_unit").html(data);
      },
    });
  });

  $("#batch").change(function () {
    var batch_id = $("#batch").val();
    $.ajax({
      type: "POST",
      url: baseurl + "inventory_management/get_batch_info",
      data: {
        batch_id: batch_id,
      },
      dataType: "json",
      success: function (data) {
        $("#available_quantity").val(data.available_qty);
        $("#quantity").attr("max", data.available_qty);
        $("#batch_expiry").val(data.expiry_date);
      },
    });
  });
});

/*$("#visit_code_master").change(function (){
  var sel_val = $(this).val();
  $("select.select2me").each(function() {
    $(this).val(sel_val).select2().trigger('change');
  });
});*/
