$("#mergebutton").click(function (e) {
  e.preventDefault();

  if (
    confirm("Are you sure you want to merge selected patients medical records?")
  ) {
    $.post(
      "merge_patients",
      $("#mergeform").serialize(),
      function (data, status) {
        alert("Patients merge successfully");
        window.location = "merge";
      }
    );
  }
});
