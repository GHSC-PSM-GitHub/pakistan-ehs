apply_masks();

$("#search_by").change(function () {
  apply_masks();
});

function apply_masks() {
  var input_var = $("#search_by").val();

  if (input_var == "mobile_no") {
    $("#search_text").inputmask("(9999) 999-9999");
  } else if (input_var == "nic_no") {
    $("#search_text").inputmask("99999-9999999-9");
  } else if (input_var == "mr_no") {
    $("#search_text").inputmask("99-99999");
  } else if (input_var == "created_date") {
    $("#search_text").inputmask("9999-99-99");
  } else {
    $("#search_text").inputmask("remove");
  }
}