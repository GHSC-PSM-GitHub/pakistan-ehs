$(function () {
  $("#category").change(function () {
    var value = $("#category option:selected").text();
    $("#category_name").val(value);
  });
  $("#add_wh_type").validate({
    rules: {
      category: "required",
      type_name: "required",
    },
  });
});
