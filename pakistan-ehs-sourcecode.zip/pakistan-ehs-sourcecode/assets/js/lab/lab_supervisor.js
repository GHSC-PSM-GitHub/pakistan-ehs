$("button[id$='-lab']").click(function () {
  var value = $(this).attr("id");
  var params = value.replace("-lab", "");
  var arr = params.split("_");
  $.post(
    "ajax_lab_detail",
    {
      pk_id: arr[0],
      p_id: arr[1],
    },
    function (data, status) {
      $("#lab_result").html(data);
    }
  );
});

$("button[id$='-patient']").click(function () {
  var value = $(this).attr("id");
  var params = value.replace("-patient", "");
  var arr = params.split("_");
  $.post(
    "ajax_patient_detail",
    {
      pk_id: arr[0],
      p_id: arr[1],
    },
    function (data, status) {
      $("#patient_result").html(data);
    }
  );
});
