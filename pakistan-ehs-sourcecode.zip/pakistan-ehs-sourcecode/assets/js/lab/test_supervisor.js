$("#appr_assign_top,#appr_assign_bottom").click(function () {
  $.post("/hepc/lab/ajax-lab-worker", function (data, status) {
    $("#assign_to_result").html(data);

    $("#lab_worker").change(function () {
      $(".alert").show();
      $("#success_msg").html("Tasks has been assigned to Lab Worker");
    });
  });
});
