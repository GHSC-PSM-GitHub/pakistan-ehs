$(function () {
  $("#add_product").validate({
    rules: {
      product_name: "required",
      generic_name_id: "required",
      strength_id: "required",
      method_type_id: "required",
      manufacturer_id: "required",
      category_id: "required",
      sub_category_id: "required",
    },
  });
  $("#generic_name_id").change(function () {
    var value = $("#generic_name_id option:selected").text();
    $("#generic_name").val(value);
  });
  $("#strength_id").change(function () {
    var value = $("#strength_id option:selected").text();
    $("#strength").val(value);
  });
  $("#method_type_id").change(function () {
    var value = $("#method_type_id option:selected").text();
    $("#method_type").val(value);
  });
  $("#category_id").change(function () {
    var value = $("#category_id option:selected").text();
    $("#category").val(value);
  });
  $("#sub_category_id").change(function () {
    var value = $("#sub_category_id option:selected").text();
    $("#sub_category").val(value);
  });
  $("#manufacturer_id").change(function () {
    var value = $("#manufacturer_id option:selected").text();
    $("#manufacturer").val(value);
  });
});
