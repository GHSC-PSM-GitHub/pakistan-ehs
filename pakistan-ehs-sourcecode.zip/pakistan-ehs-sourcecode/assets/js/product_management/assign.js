var table = $('#datatable-buttons1').DataTable();

$("#assignbtn").click(function (e) {
  e.preventDefault();

  if (confirm("Are you sure you want to update/add selected products?")) {
    $.post(
      "assign", table.$("input").serialize(),
      function (data, status) {
        alert("Products updated successfully");
        window.location = "index";
      }
    );
  }
});