<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-20 11:14:32 --> Severity: Error --> Call to undefined function base_url() D:\xampp\htdocs\hepc\application\views\forgot.php 25
ERROR - 2020-07-20 11:14:33 --> Severity: Error --> Call to undefined function base_url() D:\xampp\htdocs\hepc\application\views\forgot.php 25
