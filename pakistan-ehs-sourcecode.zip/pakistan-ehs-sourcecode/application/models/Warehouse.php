<?php

//require_once 'database.php';

/**
 * clsStockMaster
 * @package classes
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Warehouse extends Base_model {

    // table name
    protected static $table_name = "warehouses";
    // db connection
    private $conn;
    //db fileds
    protected static $db_fields = array('warehouse_name', 'district_id', 'province_id', 'tehsil_id', 'uc_id',  'stakeholder_id', 'province_name', 'district_name', 'uc_name', 'tehsil_name', 'city_name', 'category_id', 'category_name', 'facility_type_id', 'facility_type_name', 'facility_code', 'contact_person', 'contact_number', 'contact_designation', 'address', 'status', 'created_by', 'created_date', 'modified_by', 'modified_date', 'stakeholder_name', 'longitude', 'latitude','parent_hospital_id','parent_hospital_name');
    public $pk_id;
    public $warehouse_name;
    public $district_id;
    public $province_id;
    public $stakeholder_id;
    public $tehsil_id;
    public $uc_id;
//    public $city_id;
    public $province_name;
    public $district_name;
    public $uc_name;
    public $tehsil_name;
    public $city_name;
    public $category_id;
    public $category_name;
    public $facility_type_id;
    public $facility_type_name;
    public $stakeholder_name;
    public $facility_code;
    public $contact_person;
    public $contact_designation;
    public $contact_number;
    public $address;
    public $status;
    public $created_by;
    public $created_date;
    public $modified_by;
    public $modified_date;
    public $longitude;
    public $latitude;
    public $parent_hospital_id;
    public $parent_hospital_name;

    public function __construct(){
        parent::__construct();
        $this->stakeholder_id = $this->stk_id;
    }

    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all() {

        $qry = "SELECT
        warehouses.*, stakeholder.stakeholder_name
        FROM
        warehouses INNER JOIN stakeholder ON stakeholder.pk_id = warehouses.stakeholder_id WHERE stakeholder_id = ".$this->stakeholder_id;
        //echo  $qry;
        return $this->query($qry);
    }

    public function find_all_by_fac_type_id($fac_type_id = '') {

        $wrfac = "AND facility_type_id NOT IN (15)";
        if(!empty($fac_type_id)){
            $wrfac = "AND facility_type_id IN ($fac_type_id)";
        }
        $qry = "SELECT
        warehouses.*, stakeholder.stakeholder_name
        FROM
        warehouses INNER JOIN stakeholder ON stakeholder.pk_id = warehouses.stakeholder_id WHERE `status`=1 $wrfac  AND stakeholder_id = ".$this->stakeholder_id;

        return $this->query($qry);
    }

    public function find_field_by_id($id,$field)
    {
        $this->db->select($field);
        $this->db->from(static::$table_name);
        $this->db->where('pk_id', $id );
        $query = $this->db->get();

        if ( $query->num_rows() > 0 )
        {
            $row = $query->row_array();
            return $row[$field];
        }
    }

    public function find_by_id($id = 0) {
        //select query
        $strSql = "SELECT * FROM " . static::$table_name . " WHERE pk_id={$id} LIMIT 1";
        //query result
        return $this->query($strSql);
    }
    public function find_active() {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry.=" WHERE status=1 AND stakeholder_id = ".$this->stk_id;
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function get_combo() {
        $qry = "SELECT pk_id as `key`, warehouse_name as `value` FROM " . static::$table_name;
        return $this->query($qry);
    }

    public function get_combo_by_stk() {

        $qry = "SELECT pk_id as `key`, warehouse_name as `value`
        FROM
        warehouses WHERE facility_type_id IN (16) AND stakeholder_id = ".$this->stk_id;
        return $this->query($qry);
    }

    public function get_combo_by_category($id) {
        $qry = "SELECT pk_id as `key`, warehouse_name as `value` FROM " . static::$table_name ." WHERE facility_type_id={$id} AND stakeholder_id = ".$this->stk_id;
        return $this->query($qry);
    }

    public function get_labs() {
        $qry = "SELECT warehouses.pk_id as `key`, warehouses.warehouse_name as `value` FROM warehouses 
        INNER JOIN warehouse_types ON warehouse_types.pk_id = warehouses.facility_type_id
        WHERE warehouse_types.category_id = 5
        AND warehouses.stakeholder_id = ".$this->stk_id;
        return $this->query($qry);
    }

    public function find_by_category($id = 0) {
        //select query
        $strSql = "SELECT * FROM " . static::$table_name . " WHERE category_id={$id} ";
        //query result
        return $this->query($strSql);
    }

    public function find_by_location_id($id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE location_id =" . $id;
        return $this->query($qry);
    }

    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if ($this->$field != '') {
                    $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    public function deactivate($id, $status) {
        $qry = "UPDATE " . static::$table_name . " SET status=$status where pk_id=$id";
//        print_r($qry);exit;
        $this->query($qry);
    }

    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create()
    {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $this->db->insert(static::$table_name, $attributes);
        return ($this->db->affected_rows() != 1) ? false : $this->db->insert_id();
    }

    /**
     * update
     * @global type $this
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        $this->query($sql);
        return true;
    }

    public function get_count() {
        $sql = "SELECT
        count(warehouses.pk_id) as total
        FROM
        warehouses
        ";
        return $this->query($sql);
    }

    public function find_suppliers() {
        $qry = "SELECT
warehouses.*
FROM
warehouses
WHERE
warehouses.category_id = 7
               ";
        return $this->query($qry);
    } 
}
