<?php
class Common extends Base_model
{
     public function get_districts($province_id,$level){
         $qry = "SELECT * FROM locations";
        $qry .= " WHERE parent_id =$province_id AND location_level=$level";
        return $this->query($qry);
     }
      

   

     
}