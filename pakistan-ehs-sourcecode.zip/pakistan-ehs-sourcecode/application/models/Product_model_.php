<?php
class Product_model extends Base_model {

    protected static $table_name = "product";
    private $conn;
    protected static $db_fields = array('product_name','generic_name_id','generic_name','strength','strength_id','method_type','method_type_id','manufacturer','manufacturer_id','category','category_id','sub_category','sub_category_id','registration_number','barcode','gtin','description','products_in_packet','packet_in_cartons','status');
    public $pk_id;
    public $product_name;
    public $generic_name_id;
    public $generic_name;
    public $strength;
    public $strength_id;
    public $method_type;
    public $method_type_id;
    public $manufacturer;
    public $manufacturer_id;
    public $category;
    public $category_id;
    public $sub_category;
    public $sub_category_id;
    public $registration_number;
    public $barcode;
    public $gtin;
    public $description;
    public $products_in_packet;
    public $packet_in_cartons;
    public $status;


   public function find_all() {
        $qry = "SELECT * FROM " . static::$table_name;  
//        print_r($qry);exit;
        return $this->query($qry);
    }

    

     public function find_active() {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry.=" WHERE status=1";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    public function find_by_id($id) {
        $qry = "SELECT * FROM " . static::$table_name; 
        $qry .= " WHERE pk_id=" . $id;
        return $this->query($qry);
    }
    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if ($this->$field != '') {
                $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }
    
    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create()
    {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $this->db->insert(static::$table_name, $attributes);
        return ($this->db->affected_rows() != 1) ? false : $this->db->insert_id();
    }

    /**
     * update
     * @global type $this
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        $this->query($sql);
        return true;
    }
    public function deactivate($id,$status){
        $qry="UPDATE ". static::$table_name. " SET is_active=$status where pk_id=$id";
        $this->query($qry);
    }
}
