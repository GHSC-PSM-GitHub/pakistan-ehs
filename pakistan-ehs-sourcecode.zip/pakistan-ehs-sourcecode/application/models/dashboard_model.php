<?php

class Dashboard_model extends CI_model {

    function mj_patient() {
        $this->db->select("count(*) AS mj_patients");
        $this->db->from("patients ");
        $this->db->where('patients.stakeholder_id', 2);
        $query = $this->db->get();
        $return_arr = $query->result_array();
//           echo $this->db->last_query(); exit;
        return $return_arr;
    }

    function nkb_patient() {
        $this->db->select("count(*) AS nkb_patients");
        $this->db->from("patients ");
        $this->db->where('patients.stakeholder_id', 3);
        $query = $this->db->get();
        $return_arr = $query->result_array();
//           echo $this->db->last_query(); exit;
        return $return_arr;
    }

     function trans_rcv() {
        $this->db->select("count( stock_detail.pk_id ) AS trans_rcv");
        $this->db->from("stock_detail");
        $this->db->join("stock_master", "stock_detail.stock_master_id = stock_master.pk_id", "INNER");
        $this->db->join("stock_batch", "stock_batch.batch_id = stock_detail.batch_id", "INNER");
        $this->db->join("product", "stock_batch.item_id = product.pk_id ", "INNER");
        $this->db->where('stock_master.transaction_type_id', 1);
        $query = $this->db->get();
        $return_arr = $query->result_array();
//           echo $this->db->last_query(); exit;
        return $return_arr;
    }
    function trans_issue() {
        $this->db->select("count( stock_detail.pk_id ) AS trans_issue");
        $this->db->from("stock_detail");
        $this->db->join("stock_master", "stock_detail.stock_master_id = stock_master.pk_id", "INNER");
        $this->db->join("stock_batch", "stock_batch.batch_id = stock_detail.batch_id", "INNER");
        $this->db->join("product", "stock_batch.item_id = product.pk_id ", "INNER");
        $this->db->where('stock_master.transaction_type_id', 2);
        $query = $this->db->get();
        $return_arr = $query->result_array();
//           echo $this->db->last_query(); exit;
        return $return_arr;
    }
     function quantity_available() {
        $this->db->select("SUM( stock_detail.quantity ) AS quantity_available");
        $this->db->from("stock_detail");
        $this->db->join("stock_master", "stock_detail.stock_master_id = stock_master.pk_id", "INNER");
        $this->db->join("stock_batch", "stock_batch.batch_id = stock_detail.batch_id", "INNER");
        $this->db->join("product", "stock_batch.item_id = product.pk_id ", "INNER");
        $query = $this->db->get();
        $return_arr = $query->result_array();
//           echo $this->db->last_query(); exit;
        return $return_arr; 	
    }
        function quantity_rcv() {
        $this->db->select("SUM( stock_detail.quantity ) AS quantity_rcv");
        $this->db->from("stock_detail");
        $this->db->join("stock_master", "stock_detail.stock_master_id = stock_master.pk_id", "INNER");
        $this->db->join("stock_batch", "stock_batch.batch_id = stock_detail.batch_id", "INNER");
        $this->db->join("product", "stock_batch.item_id = product.pk_id ", "INNER");
        $this->db->where('stock_master.transaction_type_id', 1);
        $query = $this->db->get();
        $return_arr = $query->result_array();
//           echo $this->db->last_query(); exit;
        return $return_arr; 	
    }
        function quantity_consume() {
        $this->db->select("ABS(SUM( stock_detail.quantity )) AS quantity_consume");
        $this->db->from("stock_detail");
        $this->db->join("stock_master", "stock_detail.stock_master_id = stock_master.pk_id", "INNER");
        $this->db->join("stock_batch", "stock_batch.batch_id = stock_detail.batch_id", "INNER");
        $this->db->join("product", "stock_batch.item_id = product.pk_id ", "INNER");
        $this->db->where('stock_master.transaction_type_id', 2);
        $query = $this->db->get();
        $return_arr = $query->result_array();
//           echo $this->db->last_query(); exit;
        return $return_arr; 	
    }
    
    function mj_product() {
        $this->db->select("COUNT( DISTINCT stock_batch.item_id ) mj_product ");
        $this->db->from("stock_detail");
        $this->db->join("stock_batch", "stock_detail.batch_id = stock_batch.batch_id", "INNER");
        $this->db->join("warehouses", "stock_batch.wh_id = warehouses.pk_id ", "INNER");
        $this->db->where('warehouses.stakeholder_id', 2);
        $this->db->group_by("warehouses.stakeholder_id");
        $query = $this->db->get();
        $return_arr = $query->result_array();
//           echo $this->db->last_query(); exit;
        return $return_arr;
    }
     function nkb_product() {
        $this->db->select("COUNT( DISTINCT stock_batch.item_id ) nkb_product ");
        $this->db->from("stock_detail");
        $this->db->join("stock_batch", "stock_detail.batch_id = stock_batch.batch_id", "INNER");
        $this->db->join("warehouses", "stock_batch.wh_id = warehouses.pk_id ", "INNER");
        $this->db->where('warehouses.stakeholder_id', 3);
        $this->db->group_by("warehouses.stakeholder_id");
        $query = $this->db->get();
        $return_arr = $query->result_array();
//           echo $this->db->last_query(); exit;
        return $return_arr;
    }

    function export_app_data() {
        $q = "SELECT
	count(*) AS total
FROM
	patients 
WHERE
	patients.stakeholder_id = '2'
";
        $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

}
