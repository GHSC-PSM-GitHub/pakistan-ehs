<?php

//require_once 'database.php';

/**
 * clsStockMaster
 * @package classes
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Patient_lab_master_model extends Base_model {

    // table name
    protected static $table_name = "patient_lab_master";
    // db connection
    private $conn;
    //db fileds
    protected static $db_fields = array("patient_id","patient_name","province_id","province_name","district_id","district_name","tehsil_id","tehsil_name","uc_id","uc_name","hf_id","hf_name","department_id","department_name","lab_test_master_id","lab_test_master_name","lab_test_master_description","sample_datetime","sample_collection_type_id","sample_collection_type_name","created_date","created_by","updated_date","updated_by","ordered_date","ordered_by");
    public $pk_id;
    public $patient_id;
    public $patient_name;
    public $province_id;
    public $province_name;
    public $district_id;
    public $district_name;
    public $tehsil_id;
    public $tehsil_name;
    public $uc_id;
    public $uc_name;
    public $hf_id;
    public $hf_name;
    public $department_id;
    public $department_name;
    public $lab_test_master_id;
    public $lab_test_master_name;
    public $lab_test_master_description;
    public $sample_datetime;
    public $sample_collection_type_id;
    public $sample_collection_type_name;
    public $created_date;
    public $created_by;
    public $updated_date;
    public $updated_by;
    public $ordered_date;
    public $ordered_by;
    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all_completed() {
        $qry = "SELECT DISTINCT
        patient_lab_master.patient_name,
        lab_test_master.`code`,
        lab_test_master.`name`,
        list_detail.list_value type_name,
        patient_lab_master.sample_datetime,
        lab_test_master.pk_id,
        patient_lab_master.patient_id
    FROM
        ".static::$table_name."
    INNER JOIN lab_test_master ON patient_lab_master.lab_test_master_id = lab_test_master.pk_id
    INNER JOIN list_detail ON patient_lab_master.sample_collection_type_id = list_detail.pk_id
    INNER JOIN patient_lab_detail ON patient_lab_master.pk_id = patient_lab_detail.patient_lab_master_id";
        return $this->query($qry);
    }

    public function find_all_pending() {
        $qry = "SELECT DISTINCT
        patient_lab_master.patient_name,
        lab_test_master.`code`,
        lab_test_master.`name`,
        list_detail.list_value type_name,
        patient_lab_master.sample_datetime,
        lab_test_master.pk_id,
        patient_lab_master.patient_id
    FROM
        patient_lab_master
    INNER JOIN lab_test_master ON patient_lab_master.lab_test_master_id = lab_test_master.pk_id
    INNER JOIN list_detail ON patient_lab_master.sample_collection_type_id = list_detail.pk_id
    WHERE
        patient_lab_master.pk_id NOT IN (
            SELECT DISTINCT
                patient_lab_detail.patient_lab_master_id
            FROM
                patient_lab_detail
        )";
        return $this->query($qry);
    }

    public function get_total_patients(){
        $qry = "SELECT
        COUNT(
            DISTINCT patient_lab_master.patient_id
        ) total
    FROM
        patient_lab_master";
        $data = $this->query($qry);
        $result = $data->result_object();
        return $result[0]->total;
    }

    public function get_assigned_tests(){
        $qry = "SELECT
        COUNT(
            DISTINCT patient_lab_master.lab_test_master_id
        ) AS total
    FROM
        patient_lab_master";
        $data = $this->query($qry);
        $result = $data->result_object();
        return $result[0]->total;
    }

    public function get_pending_tests(){
        $qry = "SELECT
        COUNT(
            DISTINCT patient_lab_master.lab_test_master_id
        ) AS total
    FROM
        patient_lab_master
    WHERE
        patient_lab_master.lab_test_master_id NOT IN (
            SELECT
                patient_lab_detail.lab_test_master_id
            FROM
                patient_lab_detail
        )";
        $data = $this->query($qry);
        $result = $data->result_object();
        return $result[0]->total;
    }

    public function get_completed_tests(){
        $qry = "SELECT
        COUNT(
            DISTINCT patient_lab_detail.lab_test_master_id
        ) total
    FROM
        patient_lab_detail";
        $data = $this->query($qry);
        $result = $data->result_object();
        return $result[0]->total;
    }    

    public function find_by_id(){
        $qry = "SELECT
        patient_lab_master.pk_id,
        patient_lab_master.patient_id,
        lab_test_master.`code`,
        lab_test_master.`name`,
        list_detail.list_value AS type_name,
        patient_lab_master.sample_datetime,
        patient_lab_detail.test_result,
        lab_test_detail.test_name,
        lab_test_detail.unit,
        lab_test_detail.ref_range_min_male,
        lab_test_detail.ref_range_max_male,
        lab_test_detail.ref_range_min_female,
        lab_test_detail.ref_range_max_female,
        lab_test_detail.ref_range_min_general,
        lab_test_detail.ref_range_max_general
    FROM
        patient_lab_master
    INNER JOIN lab_test_master ON patient_lab_master.lab_test_master_id = lab_test_master.pk_id
    INNER JOIN list_detail ON patient_lab_master.sample_collection_type_id = list_detail.pk_id
    LEFT JOIN patient_lab_detail ON patient_lab_master.pk_id = patient_lab_detail.lab_test_master_id
    LEFT JOIN lab_test_detail ON patient_lab_detail.lab_test_detail_id = lab_test_detail.pk_id
    WHERE
        patient_lab_master.patient_id =" . $this->patient_id;

        return $this->query($qry);
    }

    public function get_lab_details($test_id, $patient_id){
        $qry = "SELECT
        lab_test_detail.test_name,
        lab_test_detail.ref_range_min_male,
        lab_test_detail.ref_range_max_male,
        lab_test_detail.ref_range_min_female,
        lab_test_detail.ref_range_max_female,
        lab_test_detail.ref_range_min_general,
        lab_test_detail.ref_range_max_general,
        lab_test_detail.unit,
        patients.full_name,
        patients.mr_no,
        patients.date_of_birth,
        patients.address,
        patients.mobile_no,
        lab_test_master.`name`,
        patient_lab_master.pk_id patient_lab_master_id,
patient_lab_master.patient_id,
lab_test_detail.lab_test_master_id,
lab_test_detail.pk_id lab_test_detail_id
        FROM
        lab_test_master
        LEFT JOIN lab_test_detail ON lab_test_detail.lab_test_master_id = lab_test_master.pk_id
        LEFT JOIN patient_lab_master ON patient_lab_master.lab_test_master_id = lab_test_master.pk_id
        INNER JOIN patients ON patient_lab_master.patient_id = patients.pk_id
    WHERE
        lab_test_master.pk_id = $test_id
    AND patient_lab_master.patient_id = $patient_id";

return $this->query($qry);

    }

    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                $attributes[$field] = $this->$field;
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    public function savealldata() {
        $qry="UPDATE patient_lab_master,
        patients
       SET patient_lab_master.patient_name = patients.full_name,
       patient_lab_master.province_id = patients.province,
       patient_lab_master.district_id = patients.district,
       patient_lab_master.tehsil_id = patients.tehsil,
       patient_lab_master.uc_id = patients.uc
       WHERE
           patient_lab_master.patient_id = " . $this->escape_value($this->patient_id)."
       AND patient_lab_master.pk_id = " . $this->escape_value($this->lab_test_master_id);

        $this->query2($qry);
    }

    public function deactivate($id){
        $qry="UPDATE ". static::$table_name. " SET is_active=0 where wh_id=$id";
        $this->query2($qry);
    }
    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create() 
    {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
        //echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->last_insert_id();
        } else {
            return false;
        }
    }

    /**
     * update
     * @global type $this
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        $this->query2($sql);
        return $this->pk_id;
    }

    public function delete() {
        $sql = "DELETE FROM ".static::$table_name;
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        return $this->query2($sql);
    }

}
