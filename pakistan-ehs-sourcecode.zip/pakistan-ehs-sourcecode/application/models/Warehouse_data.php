<?php

//require_once 'database.php';

/**
 * clsStockMaster
 * @package classes
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Warehouse_data extends Base_model
{

    // table name
    protected static $table_name = "wh_data";
    // db connection
    private $conn;
    //db fileds
    protected static $db_fields = array("report_date", "item_id", "wh_id", "opening", "received", "issued", "closing", "pos_adjustment", "neg_adjustment", "created_by", "created_date");
    public $pk_id;
    public $report_date;
    public $item_id;
    public $wh_id;
    public $opening;
    public $received;
    public $issued;
    public $closing;
    public $pos_adjustment;
    public $neg_adjustment;
    public $created_by;
    public $created_date;

    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all($data)
    {

        $where = array();
        $wr = '';
        if(is_array($data)){

            if(isset($data['product']) && !empty($data['product'])){
                $product = $data['product'];
                $where[] = "wh_data.item_id = ".$product ;
            }

            if(isset($data['from_date']) && !empty($data['from_date']) && isset($data['to_date']) && !empty($data['to_date'])){
                $from_date = $data['from_date'];
                $to_date = $data['to_date'];
                
                $where[] = "wh_data.report_date BETWEEN '".convert_date2($from_date)."' AND '".convert_date2($to_date)."'";
            } else {
                $where[] = "wh_data.report_date BETWEEN '".date('Y-m-01')."' AND '".date('Y-m-d')."'";
            }

            if(count($where) > 0){
                $wr = " WHERE ".implode(" AND ", $where);
            }

        }

        $qry = "SELECT
        warehouses.warehouse_name,
        CONCAT( product_generic_name.generic_name, '-', product.product_name, product.strength) product,
        MIN(wh_data.opening) ob,
        SUM( wh_data.received ) rcv,
        SUM( wh_data.issued ) isd,
        (wh_data.opening+SUM( wh_data.received )-SUM( wh_data.issued )) cb 
    FROM
        wh_data
        INNER JOIN product ON wh_data.item_id = product.pk_id
        INNER JOIN product_generic_name ON product.generic_name_id = product_generic_name.pk_id
        INNER JOIN product_strength ON product.strength_id = product_strength.pk_id
        INNER JOIN warehouses ON wh_data.wh_id = warehouses.pk_id 
        $wr
    GROUP BY
        wh_data.item_id,
        wh_data.wh_id 
    ORDER BY
        warehouses.warehouse_name,
        product.product_name";
        //print_r($qry);exit;
        $result = $this->query($qry);

        if (!empty($result))
            return $result->result_array();
    }
    public function find_active()
    {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE is_active=1";
        //        print_r($qry);exit;
        return $this->query($qry);
    }

    public function get_combo()
    {
        $qry = "SELECT pk_id as `key`, type_name as `value` FROM " . static::$table_name;
        $qry .= " WHERE is_active=1";
        //        print_r($qry);exit;
        return $this->query($qry);
    }

    public function find_by_id($id)
    {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE pk_id=" . $id;
        return $this->query($qry);
    }

    private function instantiate($record)
    {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute)
    {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes()
    {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if ($this->$field != '') {
                    $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes()
    {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save()
    {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create()
    {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $this->db->insert(static::$table_name, $attributes);
        return ($this->db->affected_rows() != 1) ? false : $this->db->insert_id();
    }

    /**
     * update
     * @global type $this
     * @return type
     */
    public function update()
    {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        //print_r($sql);exit;
        $this->query($sql);
        return true;
    }

    public function deactivate($id, $status)
    {
        $qry = "UPDATE " . static::$table_name . " SET is_active=$status where pk_id=$id";
        $this->query($qry);
    }
}
