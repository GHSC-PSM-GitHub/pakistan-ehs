<?php

class Reports_model extends Base_model
{

        private $conn;

        public function fetch_soh()
        {

                $qry = "SELECT
                stock_batch.batch_id,
                stock_batch.batch_number,
                stock_batch.batch_expiry,
                stock_batch.item_id,
                stock_batch.quantity, 
                product.product_name, 
                product_generic_name.generic_name,
                warehouses.warehouse_name
                FROM 
                stock_batch
                INNER JOIN product ON stock_batch.item_id = product.pk_id
                LEFT JOIN product_generic_name ON product.generic_name_id = product_generic_name.pk_id
                LEFT JOIN warehouses ON stock_batch.wh_id = warehouses.pk_id ";
                $qry .= "  WHERE
        warehouses.stakeholder_id = " . $this->session->userdata('stk_id') . " ";
                $qry .= "
               
                ORDER BY
                warehouses.warehouse_name,
                product_generic_name.generic_name ASC,
                stock_batch.batch_number ASC
        ";
                //print_r($qry);exit;
                $result = $this->query($qry);

                if (!empty($result))
                        return $result->result_array();
        }

        public function fetch_batch_history($batch_id)
        {

                $qry = "SELECT
                stock_batch.batch_id,
                stock_batch.batch_number,
                stock_batch.batch_expiry,
                stock_batch.item_id,
                stock_batch.quantity as soh,
                product.product_name,
                product_generic_name.generic_name,
                warehouses.warehouse_name,
                stock_detail.quantity,
                stock_master.pk_id,
                stock_master.transaction_date,
                stock_master.transaction_type_id,
                stock_master.transaction_reference,
                stock_master.warehouse_from,
                stock_master.warehouse_to,
                stock_master.issuance_to,
                transaction_types.trans_type,
                transaction_types.trans_nature,
                w_from.warehouse_name AS wname_from,
                w_to.warehouse_name AS wname_to,
                patients.full_name as patient_name,
                patients.nic_no
                FROM
                stock_batch
                INNER JOIN product ON stock_batch.item_id = product.pk_id
                LEFT JOIN product_generic_name ON product.generic_name_id = product_generic_name.pk_id
                LEFT JOIN warehouses ON stock_batch.wh_id = warehouses.pk_id
                INNER JOIN stock_detail ON stock_batch.batch_id = stock_detail.batch_id
                INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
                INNER JOIN transaction_types ON stock_master.transaction_type_id = transaction_types.trans_id
                LEFT JOIN warehouses AS w_from ON stock_master.warehouse_from = w_from.pk_id
                LEFT JOIN warehouses AS w_to ON stock_master.warehouse_to = w_to.pk_id
                LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
                WHERE
                stock_batch.batch_id = '" . $batch_id . "'
                ORDER BY
                stock_master.transaction_date asc

        ";
                //        print_r($qry);exit;
                $result = $this->query($qry);

                if (!empty($result))
                        return $result->result_array();
        }
        public function stock_ledger($product_id = 4)
        {

                $qry = " SELECT
transaction_types.trans_type,
stock_master.pk_id AS trans_no,
stock_master.transaction_date,
stock_master.transaction_reference,
w_from.warehouse_name AS wh_from,
w_to.warehouse_name AS wh_to,
patients.full_name AS patient_name,
users.username,
product.product_name,
stock_batch.batch_number,
stock_batch.batch_expiry,
stock_detail.quantity,
stock_master.remarks,
stock_master.issuance_to,
stock_master.vials_returned,
stock_master.transaction_type_id,
transaction_types.trans_nature
FROM
stock_master
INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
INNER JOIN transaction_types ON stock_master.transaction_type_id = transaction_types.trans_id
INNER JOIN product ON stock_batch.item_id = product.pk_id
LEFT JOIN warehouses AS w_from ON stock_master.warehouse_from = w_from.pk_id
LEFT JOIN warehouses AS w_to ON stock_master.warehouse_to = w_to.pk_id  
LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
INNER JOIN users ON stock_master.created_by = users.pk_id
WHERE
stock_batch.item_id =  '" . $product_id . "'
ORDER By stock_master.transaction_date ASC
";
//                print_r($qry); exit;
                $result = $this->query($qry);

                if (!empty($result))
                        return $result->result_array();
        }

        public function fetch_transaction_detail($batch_id)
        {

                $qry = " SELECT
transaction_types.trans_type,
stock_master.pk_id AS trans_no,
stock_master.transaction_date,
stock_master.transaction_reference,
w_from.warehouse_name AS wh_from,
w_to.warehouse_name AS wh_to,
patients.full_name AS patient_name,
users.username,
product.product_name,
stock_batch.batch_number,
stock_batch.batch_expiry,
stock_detail.quantity,
stock_master.remarks,
stock_master.issuance_to,
stock_master.vials_returned,
stock_master.transaction_type_id
FROM
stock_master
INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
INNER JOIN transaction_types ON stock_master.transaction_type_id = transaction_types.trans_id
INNER JOIN product ON stock_batch.item_id = product.pk_id
LEFT JOIN warehouses AS w_from ON stock_master.warehouse_from = w_from.pk_id
LEFT JOIN warehouses AS w_to ON stock_master.warehouse_to = w_to.pk_id  
LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
INNER JOIN users ON stock_master.created_by = users.pk_id
WHERE
stock_master.pk_id =  '" . $batch_id . "'";
                //print_r($qry); exit;
                $result = $this->query($qry);

                if (!empty($result))
                        return $result->result_array();
        }

        public function fetch_issuance()
        {
                $qry = "SELECT
                stock_master.pk_id,
                stock_master.transaction_date,
                stock_master.transaction_type_id,
                stock_master.transaction_reference,
                product.product_name,
                stock_batch.batch_number,
                stock_detail.quantity,
                stock_master.issuance_to,
                whf.warehouse_name AS wh_from,
                wht.warehouse_name AS wh_to,
                patients.full_name,
                patients.nic_no,
                stock_master.issuance_to
FROM
stock_master
INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
INNER JOIN product ON stock_batch.item_id = product.pk_id
INNER JOIN warehouses AS whf ON stock_master.warehouse_from = whf.pk_id
LEFT JOIN warehouses AS wht ON stock_master.warehouse_to = wht.pk_id
LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
WHERE
stock_master.transaction_type_id = 2    ";
                if ($this->session->userdata('id') != 1) {
                        $qry .= "  AND
        stock_master.warehouse_from = " . $this->session->userdata('warehouse_id') . " ";
                }
                $qry .= "
ORDER BY
stock_master.pk_id DESC



        ";
                //        print_r($qry);exit;
                $result = $this->query($qry);
                if (!empty($result))
                        return $result->result_array();
        }
        public function fetch_issuance_list()
        {
                $qry = "SELECT
                stock_master.pk_id,
                stock_master.transaction_date,
                stock_master.transaction_type_id,
                stock_master.transaction_reference, 
                stock_master.issuance_to,
                whf.warehouse_name AS wh_from,
                wht.warehouse_name AS wh_to,
                patients.full_name,
                patients.nic_no,
                stock_master.issuance_to
FROM
stock_master  
INNER JOIN warehouses AS whf ON stock_master.warehouse_from = whf.pk_id
LEFT JOIN warehouses AS wht ON stock_master.warehouse_to = wht.pk_id
LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
WHERE
stock_master.transaction_type_id = 2    ";
                if ($this->session->userdata('id') != 1) {
                        $qry .= "  AND
        stock_master.warehouse_from = " . $this->session->userdata('warehouse_id') . " ";
                }
                $qry .= "
ORDER BY
stock_master.pk_id DESC



        ";
                //        print_r($qry);exit;
                $result = $this->query($qry);
                if (!empty($result))
                        return $result->result_array();
        }
        public function fetch_receive()
        {
                $qry = "SELECT
                stock_master.pk_id,
                stock_master.transaction_date,
                stock_master.transaction_type_id,
                stock_master.transaction_reference,
                product.product_name,
                stock_batch.batch_number,
                stock_detail.quantity,
                stock_master.issuance_to,
                whf.warehouse_name AS wh_from,
                wht.warehouse_name AS wh_to,
                patients.full_name,
                patients.nic_no,
                stock_master.issuance_to
FROM
stock_master
INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
INNER JOIN product ON stock_batch.item_id = product.pk_id
INNER JOIN warehouses AS whf ON stock_master.warehouse_from = whf.pk_id
LEFT JOIN warehouses AS wht ON stock_master.warehouse_to = wht.pk_id
LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
WHERE
stock_master.transaction_type_id = 1    ";
                if ($this->session->userdata('id') != 1) {
                        $qry .= "  AND
        stock_master.warehouse_to= " . $this->session->userdata('warehouse_id') . " ";
                }
                $qry .= "
ORDER BY
stock_master.pk_id DESC



        ";
                //        print_r($qry);exit;
                $result = $this->query($qry);
                if (!empty($result))
                        return $result->result_array();
        }

        public function fetch_receive_list()
        {
                $qry = "SELECT
                    stock_master.pk_id,
                    stock_master.transaction_date,
                    stock_master.transaction_type_id,
                    stock_master.transaction_reference,
                    stock_master.issuance_to,
                    whf.warehouse_name AS wh_from,
                    wht.warehouse_name AS wh_to,
                    patients.full_name,
                    patients.nic_no,
                    stock_master.issuance_to,
                    product.product_name,
                    stock_detail.quantity 
            FROM
                    stock_master
                    INNER JOIN warehouses AS whf ON stock_master.warehouse_from = whf.pk_id
                    LEFT JOIN warehouses AS wht ON stock_master.warehouse_to = wht.pk_id
                    LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
                    INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
                    INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
                    INNER JOIN product ON stock_batch.item_id = product.pk_id 
            WHERE
            stock_master.transaction_type_id = 1    ";
                if ($this->session->userdata('id') != 1) {
                        $qry .= "  AND
                    stock_master.warehouse_to = " . $this->session->userdata('warehouse_id') . " ";
                }
                $qry .= "
            ORDER BY
            stock_master.pk_id DESC
        ";
                //        print_r($qry);exit;
                $result = $this->query($qry);
                if (!empty($result))
                        return $result->result_array();
        }

        public function fetch_raw_data_report($formArray)
        {
                $wr = '';

                if (isset($formArray['from_date']) && isset($formArray['to_date'])) {
                        $wr = " WHERE raw_data_report.transaction_date BETWEEN '" . convert_date2($formArray['from_date']) . "' AND '" . convert_date2($formArray['to_date']) . "'";
                }

                $qry = "SELECT
	raw_data_report.batch_number,
	raw_data_report.batch_expiry,
	raw_data_report.product_name,
	raw_data_report.generic_name,
	raw_data_report.strength,
	raw_data_report.method_type,
	raw_data_report.manufacturer,
	raw_data_report.prescribed_quantity,
	raw_data_report.quantity,
	raw_data_report.transaction_date,
	raw_data_report.transaction_reference,
	raw_data_report.trans_type,
	raw_data_report.trans_nature,
	raw_data_report.from_wh,
	raw_data_report.to_wh,
	raw_data_report.cnic,
	raw_data_report.mr_no,
	raw_data_report.remarks,
	raw_data_report.username,
	raw_data_report.designation,
	raw_data_report.email,
	raw_data_report.phone,
	raw_data_report.hospital 
FROM
	raw_data_report
	$wr ORDER BY raw_data_report.pk_id DESC";

                //print_r($qry); exit;
                $result = $this->query($qry);
                if (!empty($result))
                        return $result->result_array();
        }
        public function fetch_all_trans()
        {
                $qry = "SELECT
stock_master.pk_id,
stock_master.transaction_date,
stock_master.transaction_type_id,
stock_master.transaction_reference,
product.product_name,
stock_batch.batch_id,
stock_batch.batch_number,
stock_detail.quantity,
transaction_types.trans_type,
transaction_types.trans_nature,
wfrom.warehouse_name AS wh_from,
wto.warehouse_name AS wh_to,
patients.full_name,
patients.nic_no,
stock_master.issuance_to
FROM
stock_master
INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
INNER JOIN product ON stock_batch.item_id = product.pk_id
LEFT JOIN transaction_types ON stock_master.transaction_type_id = transaction_types.trans_id
INNER JOIN warehouses AS wfrom ON stock_master.warehouse_from = wfrom.pk_id
LEFT JOIN warehouses AS wto ON stock_master.warehouse_to = wto.pk_id
LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
WHERE
    stock_master.warehouse_from =  " . $this->session->userdata('warehouse_id') . " OR 
    stock_master.warehouse_to =  " . $this->session->userdata('warehouse_id') . "
ORDER BY
stock_master.transaction_date DESC



        ";
                //        print_r($qry);exit;
                $result = $this->query($qry);
                if (!empty($result))
                        return $result->result_array();
        }
        
              public function fetch_daily()
        {
                $qry = "SELECT
	DATE_FORMAT(raw_data_report.transaction_date,'%d/%m/%Y') transaction_date,
	raw_data_report.trans_type,
	raw_data_report.hospital,
	raw_data_report.username,
	raw_data_report.designation,
	raw_data_report.email,
	raw_data_report.phone,
	COUNT( DISTINCT raw_data_report.pk_id ) total 
FROM
	raw_data_report
	GROUP BY 
	DATE_FORMAT(raw_data_report.transaction_date,'%d/%m/%Y'),
	raw_data_report.username
	ORDER BY raw_data_report.transaction_date DESC,
        raw_data_report.username
        ";
                //        print_r($qry);exit;
                $result = $this->query($qry);
                if (!empty($result))
                        return $result->result_array();
        }
        
                 public function stock_detail($from_date,$to_date)
        {
          
                $qry = "SELECT
	product.product_name,
	wh_data.item_id, 
	wh_data.opening, 
	wh_data.received, 
	wh_data.issued, 
	wh_data.pos_adjustment, 
	wh_data.neg_adjustment, 
	wh_data.closing
FROM
	wh_data
	INNER JOIN
	warehouses
	ON 
		wh_data.wh_id = warehouses.pk_id
	INNER JOIN
	product
	ON 
		wh_data.item_id = product.pk_id
WHERE
	wh_data.report_date BETWEEN  '" . $from_date . "' AND '" . $to_date . "'
GROUP BY
	wh_data.item_id
        ";
//                        print_r($qry);exit;
                $result = $this->query($qry);
                if (!empty($result))
                        return $result->result_array();
        }
        
                public function batch_report($product_id = 4,$from_date,$to_date)
        {
//echo 'hello'; exit;
                $qry = " SELECT
transaction_types.trans_type,
stock_master.pk_id AS trans_no,
stock_master.transaction_date,
stock_master.transaction_reference,
w_from.warehouse_name AS wh_from,
w_to.warehouse_name AS wh_to,
patients.full_name AS patient_name,
users.username,
product.product_name,
stock_batch.batch_number,
stock_batch.batch_expiry,
stock_detail.quantity,
stock_master.remarks,
stock_master.issuance_to,
stock_master.vials_returned,
stock_master.transaction_type_id,
transaction_types.trans_nature,
SUM(stock_detail.quantity) AS opening 
FROM
stock_master
INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
INNER JOIN transaction_types ON stock_master.transaction_type_id = transaction_types.trans_id
INNER JOIN product ON stock_batch.item_id = product.pk_id
LEFT JOIN warehouses AS w_from ON stock_master.warehouse_from = w_from.pk_id
LEFT JOIN warehouses AS w_to ON stock_master.warehouse_to = w_to.pk_id  
LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
INNER JOIN users ON stock_master.created_by = users.pk_id
WHERE
stock_batch.item_id =  '" . $product_id . "'
    AND stock_master.transaction_date BETWEEN '" . $from_date . "' AND '" . $to_date . "'
ORDER By stock_master.transaction_date ASC
";
//                print_r($qry); exit;
                $result = $this->query($qry);

                if (!empty($result))
                        return $result->result_array();
        }
}
