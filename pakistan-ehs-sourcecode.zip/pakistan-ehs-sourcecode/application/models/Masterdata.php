<?php

//require_once 'database.php';

/**
 * clsStockMaster
 * @package classes
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Masterdata extends Base_model {

    // table name
    protected static $table_name = "master_data";
    // db connection
    private $conn;
    //db fileds
    protected static $db_fields = array("entity_type","entity_pk","external_system_id","external_pk","external_entity_name");
    public $pk_id;
    public $entity_type;
    public $entity_pk;
    public $external_system_id;
    public $external_pk; 
    public $external_entity_name;
    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all() {
        $qry = "SELECT
        master_data.entity_type,
        external_systems.external_system_name,
        warehouses.warehouse_name,
        locations.location_name,
        master_data.external_pk,
        master_data.external_entity_name,
        patients.full_name
        FROM
        master_data
        INNER JOIN warehouses ON master_data.entity_pk = warehouses.pk_id
        INNER JOIN locations ON master_data.entity_pk = locations.pk_id
        INNER JOIN external_systems ON master_data.external_system_id = external_systems.pk_id
        INNER JOIN patients ON master_data.entity_pk = patients.pk_id

        ";  
//        print_r($qry);exit;
        return $this->query($qry);
    }

    public function find_by_id($id) {
        $qry = "SELECT * FROM " . static::$table_name; 
        $qry .= " WHERE pk_id=" . $id;
        return $this->query($qry);
    }
    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if ($this->$field != '') {
                $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }
    
    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create()
    {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $this->db->insert(static::$table_name, $attributes);
        return ($this->db->affected_rows() != 1) ? false : $this->db->insert_id();
    }

    /**
     * update
     * @global type $this
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        $this->query($sql);
        return true;
    }

}
