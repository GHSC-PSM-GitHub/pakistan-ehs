<?php

/**
 * clsStockMaster
 * @package includes/class
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Stock_master_model extends Base_model
{

    // table name
    protected static $table_name = "stock_master";
    //db fileds 
    protected static $db_fields = array('transaction_date', 'transaction_type_id', 'transaction_reference', 'warehouse_from', 'warehouse_to', 'created_by', 'created_on', 'remarks', 'temp', 'linked_transaction', 'issuance_to', 'vials_returned', 'mcc_year', "invoice_no");
    //pk stock id
    public $pk_id;
    //transaction date
    public $transaction_date;
    //transaction type id
    public $transaction_type_id;
    //transaction ref
    public $transaction_reference;
    //from warehouse id
    public $warehouse_from;
    //to warehouse id
    public $warehouse_to;
    //created by
    public $created_by;
    //created on
    public $created_on;
    //Received Remarks
    public $remarks;
    //temp
    public $temp;
    //linked transaction
    public $linked_transaction;
    public $issuance_to;
    public $vials_returned;
    public $mcc_year;
    public $invoice_no;

    // Common Database Methods
    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all()
    {
        return static::find_by_sql("SELECT * FROM " . static::$table_name);
    }

    /**
     * 
     * find_by_id
     * @param type $id
     * @return type
     * 
     * 
     */
    public function find_by_id($id = 0)
    {
        //select query
        $strSql = "SELECT * FROM " . static::$table_name . " WHERE pk_id={$id} LIMIT 1";
        //query result
        return $this->query($strSql);
    }

    public function find_by_user_id($id = 0)
    {
        //select query
        $strSql = "SELECT
        stock_master.transaction_date, 
        stock_master.transaction_type_id, 
        stock_master.transaction_reference, 
        stock_master.warehouse_from, 
        stock_master.warehouse_to, 
        stock_master.created_by, 
        stock_master.created_on, 
        stock_master.remarks, 
        stock_master.temp, 
        stock_master.linked_transaction, 
        stock_master.issuance_to, 
        stock_master.vials_returned, 
        stock_master.mcc_year, 
        stock_master.invoice_no, 
        stock_master.is_received, 
        stock_detail.pk_id, 
        stock_detail.stock_master_id, 
        stock_detail.batch_id, 
        stock_detail.prescribed_quantity, 
        stock_detail.quantity
    FROM
        stock_master
        INNER JOIN
        stock_detail
        ON 
            stock_detail.stock_master_id = stock_master.pk_id
    WHERE
        created_by = $id AND
        stock_master.temp = 1 AND
        transaction_type_id = 2
    GROUP BY
        stock_master.pk_id";
        return $this->query($strSql);
    }

    /**
     * 
     * find_by_sql
     * @param type $sql
     * @return type
     * 
     * 
     */
    public function find_by_sql($sql = "")
    {
        $result_set = mysql_query($sql);
        //query result
        $object_array = array();
        while ($row = mysql_fetch_array($result_set)) {
            $object_array[] = static::instantiate($row);
        }
        return $object_array;
    }

    /**
     * 
     * count_all
     * @global type $this
     * @return type
     * 
     * 
     */
    public function count_all()
    {
        //select query
        $sql = "SELECT COUNT(*) FROM " . static::$table_name;
        //query result
        $result_set = $this->query($sql);
        $row = $this->fetch_array($result_set);
        return array_shift($row);
    }

    /**
     * 
     * instantiate
     * @param type $record
     * @return \self
     * 
     * 
     */
    private function instantiate($record)
    {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute)
    {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes()
    {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if (!empty($this->$field) || $this->$field == 0) {
                    $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $database
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes()
    {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save()
    {
        // A new record won't have an id yet.

        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    /**
     *
     * create
     * @global type $database
     * @return boolean
     * 
     * 
     */
    public function create()
    {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
        if ($this->query2($sql)) {
            return $this->last_insert_id();
        } else {
            return false;
        }
    }
    /**
     * 
     * update
     * @global type $database
     * @return type
     * 
     * 
     */
    public function update()
    {
        //update query
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        //        print_r($attribute_pairs);exit;
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        //echo 'upd:::'.$sql;exit;
        $this->query($sql);
        return true;
    }
    public function link_trans()
    {
        //update query
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= " linked_transaction='" . $this->linked_transaction . "'";
        $sql .= " WHERE pk_id='" . $this->escape_value($this->pk_id) . "'";
        //echo 'upd:::'.$sql;exit;
        $this->query($sql);
        return true;
    }
    public function mark_received()
    {
        //update query
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= " is_received='1' ";
        $sql .= " WHERE pk_id= '" . $this->escape_value($this->pk_id) . "' ";
        //echo 'upd:::'.$sql;exit;
        $this->query($sql);
        return true;
    }

    /**
     * 
     * delete
     * @global type $database
     * @return type
     * 
     * 
     */
    public function delete()
    {
        // Don't forget your SQL syntax and good habits:
        // - DELETE FROM table WHERE condition LIMIT 1
        // - escape all values to prevent SQL injection
        // - use LIMIT 1 
        //delete query
        $sql = "DELETE FROM " . static::$table_name;
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        $sql .= " LIMIT 1";
        $this->query($sql);
        return ($this->affected_rows() == 1) ? true : false;

        // NB: After deleting, the instance of User still
        // exists, even though the database entry does not.
        // This can be useful, as in:
        // but, for example, we can't call $user->update()
        // after calling $user->delete(). 
    }

    function stock_search($type_id)
    {
        $wh_id = $this->session->userdata('warehouse_id');
        if ($type_id == 1) {
            $filter = " AND stock_master.warehouse_to = $wh_id";
        } else if ($type_id == 2) {
            $filter = " AND stock_master.warehouse_from = $wh_id";
        }

        $qry = "SELECT
        stock_master.transaction_date,
        stock_master.transaction_reference,
        stock_batch.batch_number,
        stock_batch.batch_expiry,
        ABS(stock_detail.quantity) as quantity,
        stock_master.issuance_to,
        warehouses.warehouse_name,
        supp.warehouse_name as supplier_name,
        patients.full_name,
        patients.nic_no,
        stock_detail.stock_master_id,
        stock_detail.pk_id,
        stock_detail.batch_id,
        funding_sources.funding_source_name,
        CONCAT( product.product_name, ' - ', product_generic_name.generic_name, ' - ', product_strength.strength ) product_name 
        FROM
        stock_master
        INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
        INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
        INNER JOIN product ON stock_batch.item_id = product.pk_id
	    INNER JOIN product_generic_name ON product.generic_name_id = product_generic_name.pk_id
	    INNER JOIN product_strength ON product.strength_id = product_strength.pk_id
        LEFT JOIN warehouses supp ON stock_master.warehouse_from = supp.pk_id
        LEFT JOIN warehouses ON stock_master.warehouse_to = warehouses.pk_id
        LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
        LEFT JOIN funding_sources ON stock_batch.funding_source = funding_sources.pk_id
        WHERE
        stock_master.transaction_type_id = $type_id $filter AND
        stock_master.temp = 0
        ORDER BY 
        stock_master.pk_id DESC
        ";
                //print_r($qry);exit;
        return $this->query($qry);
    }

    function save_master_temp($stock_master_id)
    {
        $qry = "UPDATE stock_master set temp=0 where pk_id=$stock_master_id";
        $this->query($qry);
        return true;
    }

    function get_temp_master_records($transaction_type, $issuance_type = '')
    {
        $user_id = $_SESSION['id'];
        $filter = '';
        if ($issuance_type != '') {
            $filter = "AND stock_master.issuance_to='$issuance_type'";
        }
        $qry = "SELECT
        stock_batch.batch_number,
        stock_batch.batch_expiry,
        ABS(stock_detail.quantity) as quantity,
        product.product_name,
        product.manufacturer,
        stock_detail.pk_id,
        stock_detail.stock_master_id,
        funding_sources.funding_source_name,
        warehouses.warehouse_name,
        patients.full_name,
        patients.nic_no,
        stock_master.issuance_to,
        stock_master.transaction_reference,
        transaction_types.trans_type,
        stock_master.warehouse_to,
        wfrom.warehouse_name AS wh_from,
        stock_master.warehouse_from,
        stock_detail.batch_id
        FROM
        stock_detail
        INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
        INNER JOIN product ON stock_batch.item_id = product.pk_id
        LEFT JOIN funding_sources ON stock_batch.funding_source = funding_sources.pk_id
        INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
        INNER JOIN warehouses ON stock_master.warehouse_to = warehouses.pk_id
        LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
        LEFT JOIN transaction_types ON stock_master.transaction_type_id = transaction_types.trans_id
        INNER JOIN warehouses AS wfrom ON stock_master.warehouse_from = wfrom.pk_id
        WHERE 
        stock_master.created_by = $user_id
            AND stock_detail.temp=1";
        if ($transaction_type > 2) {
            $qry .= " AND stock_master.transaction_type_id > 2";
        } else {
            $qry .= " AND stock_master.transaction_type_id=$transaction_type";
        }
        $qry .= "
                $filter
        ";
        //       print_r($qry);exit;
        return $this->query($qry);
    }

    function delete_orphan_master_records(){
        $qry = "DELETE
        FROM
            stock_master 
        WHERE
            stock_master.pk_id NOT IN (
            SELECT DISTINCT
                stock_detail.stock_master_id 
        FROM
            stock_detail)";
        return $this->query($qry);
    }

    function get_issued_records()
    {
        //for marking acknowledgement
        $wh_id = $this->session->userdata('warehouse_id');
        $qry = "SELECT 
                    stock_master.transaction_reference,
                    stock_master.transaction_date,
                    stock_master.pk_id,
                    warehouses.warehouse_name,
                    stock_batch.batch_number,
                    stock_detail.quantity
               from
               stock_master
                INNER JOIN warehouses ON stock_master.warehouse_from = warehouses.pk_id
                INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
                INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
                 WHERE 
                stock_master.warehouse_to = $wh_id
                AND   stock_master.warehouse_from <> $wh_id
                AND stock_master.temp=0
                AND stock_master.transaction_type_id=2
                AND stock_master.is_received = 0
        ORDER BY batch_number
               ";
        //        echo $qry;exit;
        return $this->query($qry);
    }

    function fetch_suppliers()
    {
        $qry = "SELECT
warehouses.*
FROM
warehouses
WHERE
warehouses.category_id = 7
               ";
        return $this->query($qry);
    }

    function fetch_manufacturers()
    {
        /*$qry = "SELECT
        'Existing' group_id,
        product_manufacturer.pk_id AS `key`,
        product_manufacturer.manufacturer AS `value` 
    FROM
        product_manufacturer
        INNER JOIN stock_batch ON stock_batch.manufacturer = product_manufacturer.manufacturer 
    WHERE
        stock_batch.item_id = 9 UNION
    SELECT
        'New' group_id,
        pk_id AS `key`,
        manufacturer AS `value` 
    FROM
        product_manufacturer";*/
        $qry = "SELECT
            pk_id as `key`, manufacturer as `value`
            FROM
            product_manufacturer";
        return $this->query($qry);
    }

    function auto_receive_voucher($master_id)
    {
        $qry = "INSERT INTO stock_master (
            stock_master.transaction_date,
            stock_master.transaction_type_id,
            stock_master.transaction_reference,
            stock_master.warehouse_from,
            stock_master.warehouse_to,
            stock_master.created_by,
            stock_master.created_on,
            stock_master.remarks,
            stock_master.temp,
            stock_master.linked_transaction,
            stock_master.issuance_to,
            stock_master.vials_returned,
            stock_master.mcc_year,
            stock_master.is_received 
        ) SELECT
        A.transaction_date,
        1,
        A.transaction_reference,
        A.warehouse_from,
        A.warehouse_to,
        A.created_by,
        A.created_on,
        A.remarks,
        0,
        $master_id,
        A.issuance_to,
        A.vials_returned,
        A.mcc_year,
        A.is_received 
        FROM
            stock_master A WHERE A.pk_id = $master_id AND A.transaction_type_id = 2";

        $this->query($qry);
        $new_master_id = $this->last_insert_id();

        if (!empty($new_master_id)) {
            $qrydetail = "SELECT
            stock_detail.stock_master_id, 
            stock_detail.batch_id, 
            stock_detail.quantity, 
            stock_detail.temp, 
            'TEMPBATCH' batch_number, 
            stock_batch.batch_expiry, 
            stock_batch.item_id,
            stock_batch.wh_id, 
            stock_batch.funding_source, 
            stock_batch.manufacturer, 
            stock_batch.manufacturing_date
        FROM
            stock_detail
            INNER JOIN
            stock_batch
            ON 
                stock_detail.batch_id = stock_batch.batch_id
        WHERE
            stock_detail.stock_master_id = $master_id";

            $res_detail = $this->query($qrydetail);

            if (!empty($res_detail)) {
                $data = $res_detail->result_array();

                foreach ($data as $row) {
                    $this->obj_stock_batch->batch_number = $row['batch_number'];
                    $this->obj_stock_batch->batch_expiry = $row['batch_expiry'];
                    $this->obj_stock_batch->manufacturing_date = $row['manufacturing_date'];
                    $this->obj_stock_batch->item_id = $row['item_id'];
                    $this->obj_stock_batch->wh_id = $_SESSION['wh_to_issue'];
                    $this->obj_stock_batch->quantity = 0;
                    $this->obj_stock_batch->funding_source = $row['funding_source'];
                    $stock_batch_id = $this->obj_stock_batch->save();


                    $this->obj_stock_detail->stock_master_id = $new_master_id;
                    $this->obj_stock_detail->batch_id = $stock_batch_id;
                    $this->obj_stock_detail->quantity = ABS($row['quantity']);
                    $this->obj_stock_detail->temp = 0;
                    $this->obj_stock_detail->save();

                    $this->obj_stock_batch->recalculate_batch_qty($stock_batch_id);
                }
            }
        }
    }
}