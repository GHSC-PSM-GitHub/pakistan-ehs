<?php

//require_once 'database.php';

/**
 * clsStockMaster
 * @package classes
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Patient_prescription_model extends Base_model {

    // table name
    protected static $table_name = "patient_prescriptions";
    // db connection
    private $conn;
    //db fileds
    protected static $db_fields = array("patient_id","patient_name","medicine_id","medicine_name","medicine_type","dose","strength","method","days","created_date","created_by","modified_by","modified_date","schedule","schedule_start_date");
    public $pk_id;
    public $patient_id;
    public $patient_name;
    public $medicine_id;
    public $medicine_name;
    public $medicine_type;
    public $dose;
    public $strength;
    public $method;
    public $days;
    public $created_date;
    public $created_by;
    public $modified_by;
    public $modified_date;
    public $schedule_start_date;
    public $schedule;

    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all() {
        $qry = "SELECT * FROM " . static::$table_name;
        return $this->query($qry);
    }

    public function find_by_id(){
        $qry = "SELECT * FROM " . static::$table_name;
        //$qry .= " INNER JOIN rdt_list ON patient_rdt.rdt_id = rdt_list.pk_id ";
        $qry .= " WHERE patient_id=" . $this->patient_id;
        return $this->query($qry);
    }

    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                $attributes[$field] = $this->$field;
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    public function deactivate($id){
        $qry="UPDATE ". static::$table_name. " SET is_active=0 where wh_id=$id";
        $this->query2($qry);
    }
    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create() {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
        //echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->last_insert_id();
        } else {
            return false;
        }
    } 

    /**
     * update
     * @global type $this
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        $this->query2($sql);
        return $this->pk_id;
    }

    public function delete() {
        $sql = "DELETE FROM ".static::$table_name;
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        return $this->query2($sql);
    }

}
