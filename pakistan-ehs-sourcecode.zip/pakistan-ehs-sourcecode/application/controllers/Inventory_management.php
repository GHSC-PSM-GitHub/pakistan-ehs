<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Inventory_management extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        check_login_user();
        $this->load->model('Product_model');
        $this->load->model('Stock_master_model');
        $this->load->model('Stock_detail_model');
        $this->load->model('Stock_batch_model');
        $this->load->model('Warehouse');
        $this->load->model('Patients_model');
        $this->load->model('lists');
        $this->obj_stock_master = new Stock_master_model();
        $this->obj_stock_detail = new Stock_detail_model();
        $this->obj_stock_batch = new Stock_batch_model();
        $this->obj_product = new Product_model();
        $this->obj_warehouse = new Warehouse();
        $this->obj_patient = new Patients_model();
        $this->obj_lists = new Lists();
    }

    public function stock_receive()
    {

        if (!empty($_POST)) {

            if (isset($_POST['pk_id'])) {
                $this->obj->pk_id = $_POST['pk_id'];
            }
            if (!isset($_POST['stock_master_id'])) {
                $this->obj_stock_master->transaction_date = date('Y-m-d', strtotime($_POST['receiving_time']));
                $this->obj_stock_master->transaction_type_id = 1;
                $this->obj_stock_master->transaction_reference = $this->input->post('refernce_number');
                $this->obj_stock_master->warehouse_from = $this->input->post('received_from');
                $this->obj_stock_master->warehouse_to = $_SESSION['warehouse_id'];
                $this->obj_stock_master->created_by = $_SESSION['id'];
                $this->obj_stock_master->created_on = date("Y-m-d");
                $this->obj_stock_master->temp = 1;
                $this->obj_stock_master->mcc_year = $this->input->post('mcc_year');
                $this->obj_stock_master->remarks = $this->input->post('remarks');
                $this->obj_stock_master->issuance_to = 'centers';
                $this->obj_stock_master->invoice_no = $this->input->post('invoice_no');
                
                //                echo '<pre>';
                //            print_r($_REQUEST);
                //            print_r($this->obj_stock_master);
                //            echo '</pre>';
                //            exit;
                $stock_master_id = $this->obj_stock_master->save();
            } else {
                $stock_master_id = $_POST['stock_master_id'];
            }

            $this->obj_stock_batch->batch_number = $this->input->post('batch_number');
            $this->obj_stock_batch->batch_expiry = date('Y-m-d', strtotime($_POST['expiry_date']));
            $this->obj_stock_batch->manufacturing_date = date('Y-m-d', strtotime($_POST['manufacturing_date']));
            $this->obj_stock_batch->item_id = $this->input->post('product');
            $this->obj_stock_batch->manufacturer = $this->input->post('manufacturer');
            $this->obj_stock_batch->wh_id = $this->session->userdata('warehouse_id');
            $this->obj_stock_batch->quantity = $this->input->post('quantity');
            $this->obj_stock_batch->funding_source = $this->input->post('received_from');
            $stock_batch_id = $this->obj_stock_batch->save();


            $this->obj_stock_detail->stock_master_id = $stock_master_id;
            $this->obj_stock_detail->batch_id = $stock_batch_id;
            $this->obj_stock_detail->quantity = $_POST['quantity'];
            $this->obj_stock_detail->temp = 1;
            $this->obj_stock_detail->save();

            $product_arr = $this->obj_product->find_active();
            if ($product_arr)
                $data['product'] = $product_arr->result_array();

            $suppliers_arr = $this->obj_stock_master->fetch_suppliers();
            if ($suppliers_arr)
                $data['suppliers'] = $suppliers_arr->result_array();

            $data['manufacturers'] = $this->obj_stock_master->fetch_manufacturers();

            $stock_master_record = $this->obj_stock_master->find_by_id($stock_master_id);
            if ($stock_master_record)
                $data['stock_master_records'] = $stock_master_record->result_array();
            $data['temp_records'] = $this->obj_stock_detail->get_temp_records($stock_master_id);

            $data['master_id'] = $stock_master_id;
            $data['page_title'] = 'Stock Receive';

            $data['main_content'] = $this->load->view('inventory_management/stock_receive', $data, TRUE);
            $this->load->view('layout/main', $data);
        } else {
            $data = array();

            $product_arr = $this->obj_product->find_active();
            if ($product_arr)
                $data['product'] = $product_arr->result_array();

            $suppliers_arr = $this->obj_stock_master->fetch_suppliers();
            if ($suppliers_arr)
                $data['suppliers'] = $suppliers_arr->result_array();

            $data['manufacturers'] = $this->obj_stock_master->fetch_manufacturers();

            $data['temp_records'] = $this->obj_stock_master->get_temp_master_records(1);
            $master_id_arr = $this->obj_stock_master->get_temp_master_records(1);
            if (!empty($master_id_arr)) {
                if ($master_id_arr)
                    $master_result = $master_id_arr->result_array();
                foreach ($master_result as $row) {
                    $data['master_id'] = $row['stock_master_id'];
                    $data['tran_reference_number'] = $row['transaction_reference'];
                }
            }
            $data['page_title'] = 'Stock Receive';
            $data['main_content'] = $this->load->view('inventory_management/stock_receive', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function stock_issue()
    {
        if (!empty($_POST)) {
            if (isset($_POST['pk_id'])) {
                $this->obj->pk_id = $_POST['pk_id'];
            }
            if (!isset($_POST['stock_master_id'])) {
                $this->obj_stock_master->transaction_date = date('Y-m-d', strtotime($_POST['receiving_time']));
                $this->obj_stock_master->transaction_type_id = 2;
                $this->obj_stock_master->transaction_reference = $_POST['refernce_number'];
                $this->obj_stock_master->warehouse_from = $_SESSION['warehouse_id'];
                $this->obj_stock_master->warehouse_to = $_POST['center_patient'];
                $this->obj_stock_master->created_by = $_SESSION['id'];
                $this->obj_stock_master->created_on = date("Y-m-d");
                $this->obj_stock_master->temp = 1;
                $this->obj_stock_master->is_received = 1;
                $this->obj_stock_master->remarks = $_POST['remarks'];
                $this->obj_stock_master->issuance_to = 'centers';
                $stock_master_id = $this->obj_stock_master->save();

                $_SESSION['wh_to_issue'] = $_POST['center_patient'];
            } else {
                $stock_master_id = $_POST['stock_master_id'];
            }

            //changed the followign func
            //$stock_batch_id = $this->obj_stock_batch->update_batch_quantity($_POST['batch'], $_POST['quantity']);

            $this->obj_stock_detail->stock_master_id = $stock_master_id;
            $this->obj_stock_detail->batch_id = $_POST['batch'];
            $this->obj_stock_detail->quantity = '-' . $_POST['quantity'];
            $this->obj_stock_detail->temp = 1;
            $this->obj_stock_detail->save();
            $this->obj_stock_batch->recalculate_batch_qty($_POST['batch']);

            $product_arr = $this->obj_product->get_warehouse_products();
            if ($product_arr)
                $data['product'] = $product_arr->result_array();

            $stock_master_record = $this->obj_stock_master->find_by_id($stock_master_id);
            if ($stock_master_record)
                $data['stock_master_records'] = $stock_master_record->result_array();
            $data['temp_records'] = $this->obj_stock_detail->get_temp_records($stock_master_id);
            $data['master_id'] = $stock_master_id;
            $data['page_title'] = 'Stock Issue';

            $data['main_content'] = $this->load->view('inventory_management/stock_issue', $data, TRUE);
            $this->load->view('layout/main', $data);
        } else {
            $data = array();

            $product_arr = $this->obj_product->get_warehouse_products();
            if ($product_arr)
                $data['product'] = $product_arr->result_array();

            $wh_arr = $this->obj_warehouse->find_all_by_fac_type_id();
            if ($wh_arr)
                $data['warehouse'] = $wh_arr->result_array();

            $data['temp_records'] = $this->obj_stock_master->get_temp_master_records(2, "centers");
            $master_id_arr = $this->obj_stock_master->get_temp_master_records(2, "centers");
            if (!empty($master_id_arr)) {
                if ($master_id_arr)
                    $master_result = $master_id_arr->result_array();
                foreach ($master_result as $row) {
                    $data['master_id'] = $row['stock_master_id'];
                    $data['tran_reference_number'] = $row['transaction_reference'];
                    $data['transaction_date'] = $row['transaction_date'];
                }
            }
            $data['page_title'] = 'Stock Issue';
            $data['main_content'] = $this->load->view('inventory_management/stock_issue', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function ajax_del_stock_detail(){
        
        $detail_id = $_REQUEST['d_id'];
        $batch_id = $_REQUEST['b_id'];

        $this->db->where('pk_id', $detail_id);
        $this->db->delete('stock_detail');
        

        $this->obj_stock_batch->recalculate_batch_qty($batch_id);
        $this->obj_stock_master->delete_orphan_master_records();
        echo "true";
    }

    public function admin_transfers()
    {
        if (!empty($_POST)) {
            //            echo '<pre>';
            //            print_r($_POST);
            //            echo '</pre>';
            //            exit;
            if (isset($_POST['pk_id'])) {
                $this->obj->pk_id = $_POST['pk_id'];
            }
            if (!isset($_POST['stock_master_id'])) {
                $this->obj_stock_master->transaction_date = convert_date($_POST['receiving_time']);
                $this->obj_stock_master->transaction_type_id = 2;
                $this->obj_stock_master->transaction_reference = $_POST['refernce_number'];
                $this->obj_stock_master->warehouse_from = $_POST['center_from'];
                $this->obj_stock_master->warehouse_to = $_POST['center_patient'];
                $this->obj_stock_master->created_by = $_SESSION['id'];
                $this->obj_stock_master->created_on = date("Y-m-d");
                $this->obj_stock_master->temp = 1;
                $this->obj_stock_master->remarks = $_POST['remarks'];
                $this->obj_stock_master->issuance_to = 'centers';
                $stock_master_id = $this->obj_stock_master->save();
            } else {
                $stock_master_id = $_POST['stock_master_id'];
            }

            //changed the following func
            //$stock_batch_id = $this->obj_stock_batch->update_batch_quantity($_POST['batch'], $_POST['quantity']);

            $this->obj_stock_detail->stock_master_id = $stock_master_id;
            $this->obj_stock_detail->batch_id = $_POST['batch'];
            $this->obj_stock_detail->quantity = '-' . $_POST['quantity'];
            $this->obj_stock_detail->temp = 1;
            $this->obj_stock_detail->save();
            $this->obj_stock_batch->recalculate_batch_qty($_POST['batch']);


            $product_arr = $this->obj_stock_batch->get_available_prods_of_wh($this->input->post('center_from'));
            if ($product_arr)
                $data['product'] = $product_arr->result_array();



            $stock_master_record = $this->obj_stock_master->find_by_id($stock_master_id);
            if ($stock_master_record)
                $data['stock_master_records'] = $stock_master_record->result_array();
            $data['wh_from'] = $data['stock_master_records'][0]['warehouse_from'];
            $data['temp_records'] = $this->obj_stock_detail->get_temp_records($stock_master_id);
            $data['master_id'] = $stock_master_id;
            $data['page_title'] = 'Stock Issue';
            //            echo '<pre>';
            //            print_r($data);
            //            echo '</pre>';
            //            exit;
            $data['main_content'] = $this->load->view('inventory_management/admin_transfers', $data, TRUE);
            $this->load->view('layout/main', $data);
        } else {
            $data = array();

            $product_arr = $this->obj_stock_batch->get_available_prods_of_wh();
            if ($product_arr)
                if (!empty($product_arr))
                    $data['product'] = $product_arr->result_array();
                else
                    $data['product'] = array();

            $wh_arr = $this->obj_warehouse->find_all();
            if ($wh_arr)
                $data['warehouse'] = $wh_arr->result_array();

            $data['temp_records'] = $this->obj_stock_master->get_temp_master_records(2, "centers");
            $master_id_arr = $this->obj_stock_master->get_temp_master_records(2, "centers");
            if (!empty($master_id_arr)) {
                if ($master_id_arr)
                    $master_result = $master_id_arr->result_array();
                foreach ($master_result as $row) {
                    $data['master_id'] = $row['stock_master_id'];
                    $data['tran_reference_number'] = $row['transaction_reference'];
                }
            }
            $data['page_title'] = 'Stock Issue';
            $data['main_content'] = $this->load->view('inventory_management/admin_transfers', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function stock_adjustment()
    {
        if (!empty($_POST)) {

            if (isset($_POST['pk_id'])) {
                $this->obj->pk_id = $_POST['pk_id'];
            }
            if (!isset($_POST['stock_master_id'])) {
                $this->obj_stock_master->transaction_date = convert_date($_POST['receiving_time']);
                $this->obj_stock_master->transaction_type_id = $this->input->post('tran_type');
                $this->obj_stock_master->warehouse_from = $this->session->userdata('warehouse_id');
                $this->obj_stock_master->warehouse_to = $this->session->userdata('warehouse_id');
                $this->obj_stock_master->created_by = $this->session->userdata('id');
                $this->obj_stock_master->created_on = date("Y-m-d");
                $this->obj_stock_master->temp = 1;
                $this->obj_stock_master->remarks = $this->input->post('remarks');
                $this->obj_stock_master->issuance_to = 'centers';
                $stock_master_id = $this->obj_stock_master->save();
            } else {
                $stock_master_id = $_POST['stock_master_id'];
            }

            //changed the following func.
            //$stock_batch_id = $this->obj_stock_batch->update_batch_quantity($_POST['batch'], $_POST['quantity']);

            $result3 = $this->obj_stock_batch->get_tran_nature($this->input->post('tran_type'));
            $res3 = $result3->result_object();

            $tran_nature = $res3[0]->trans_nature;

            $this->obj_stock_detail->stock_master_id = $stock_master_id;
            $this->obj_stock_detail->batch_id = $this->input->post('batch');
            $this->obj_stock_detail->quantity = (($tran_nature == '-') ? '-' : '') . $this->input->post('quantity');
            $this->obj_stock_detail->temp = 1;
            $this->obj_stock_detail->save();
            $this->obj_stock_batch->recalculate_batch_qty($this->input->post('batch'));


            $product_arr = $this->obj_product->get_warehouse_products();
            $tran_arr = $this->obj_product->get_tran_types();
            if ($product_arr)
                $data['product'] = $product_arr->result_array();
            if ($tran_arr)
                $data['trans'] = $tran_arr->result_array();
            $data['tran'] = $this->input->post('tran_type');



            $stock_master_record = $this->obj_stock_master->find_by_id($stock_master_id);
            if ($stock_master_record)
                $data['stock_master_records'] = $stock_master_record->result_array();
            $data['temp_records'] = $this->obj_stock_detail->get_temp_records($stock_master_id);
            $data['master_id'] = $stock_master_id;
            $data['page_title'] = 'Stock Issue';

            $data['main_content'] = $this->load->view('inventory_management/stock_adj', $data, TRUE);
            $this->load->view('layout/main', $data);
        } else {
            $data = array();

            $product_arr = $this->obj_product->get_warehouse_products();
            if ($product_arr)
                $data['product'] = $product_arr->result_array();
            $tran_arr = $this->obj_product->get_tran_types();
            if ($tran_arr)
                $data['trans'] = $tran_arr->result_array();

            $wh_arr = $this->obj_warehouse->find_all();
            if ($wh_arr)
                $data['warehouse'] = $wh_arr->result_array();

            $data['temp_records'] = $this->obj_stock_master->get_temp_master_records(3, "centers");
            $master_id_arr = $this->obj_stock_master->get_temp_master_records(3, "centers");
            if (!empty($master_id_arr)) {
                if ($master_id_arr)
                    $master_result = $master_id_arr->result_array();
                foreach ($master_result as $row) {
                    $data['master_id'] = $row['stock_master_id'];
                    $data['tran_reference_number'] = $row['transaction_reference'];
                }
            }
            $data['page_title'] = 'Stock Issue';
            $data['main_content'] = $this->load->view('inventory_management/stock_adj', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function stock_issue_patients2()
    {
        if (!empty($_POST)) {
            $this->obj_stock_master->transaction_date = date("Y-m-d");
            $this->obj_stock_master->transaction_type_id = 2;
            $this->obj_stock_master->transaction_reference = $_POST['visit_code'];
            $this->obj_stock_master->warehouse_from = $_SESSION['warehouse_id'];
            $this->obj_stock_master->warehouse_to = $_POST['patient_id'];
            $this->obj_stock_master->created_by = $_SESSION['id'];
            $this->obj_stock_master->created_on = date("Y-m-d");
            $this->obj_stock_master->temp = 0;
            $this->obj_stock_master->remarks = $_POST['remarks'];
            $this->obj_stock_master->issuance_to = 'patients';
            $stock_master_id = $this->obj_stock_master->save();

            //changed the following func
            //$stock_batch_id = $this->obj_stock_batch->update_batch_quantity($_POST['batch'], $_POST['quantity']);

            $this->obj_stock_detail->stock_master_id = $stock_master_id;
            $this->obj_stock_detail->batch_id = $_POST['batch'];
            $this->obj_stock_detail->quantity = '-' . $_POST['quantity'];
            $this->obj_stock_detail->prescribed_quantity = $_POST['pre_quantity'];
            $this->obj_stock_detail->temp = 0;
            $this->obj_stock_detail->save();
            $this->obj_stock_batch->recalculate_batch_qty($_POST['batch']);

            $data['temp_records'] = $this->obj_stock_detail->get_issued_records($_POST['patient_id']);
            $data['master_id'] = $stock_master_id;

            //$data['main_content'] = $this->load->view('inventory_management/stock_issue_patients', $data, TRUE);
            $this->load->view('inventory_management/stock_issue_patients2', $data);
        }
    }

    public function stock_issue_patients()
    {
        if (!empty($_POST)) {
            if (isset($_POST['pk_id'])) {
                $this->obj->pk_id = $_POST['pk_id'];
            }
            if (!isset($_POST['stock_master_id'])) {
                $this->obj_stock_master->transaction_date = convert_date($_POST['receiving_time']);
                $this->obj_stock_master->transaction_type_id = 2;
                $this->obj_stock_master->transaction_reference = "Issuance to patients";
                $this->obj_stock_master->warehouse_from = $_SESSION['warehouse_id'];
                $this->obj_stock_master->warehouse_to = $_POST['center_patient'];
                $this->obj_stock_master->created_by = $_SESSION['id'];
                $this->obj_stock_master->created_on = date("Y-m-d");
                $this->obj_stock_master->temp = 1;
                $this->obj_stock_master->remarks = $_POST['remarks'];
                $this->obj_stock_master->issuance_to = 'patients';
                $stock_master_id = $this->obj_stock_master->save();
            } else {
                $stock_master_id = $_POST['stock_master_id'];
            }

            //changed the following func
            //$stock_batch_id = $this->obj_stock_batch->update_batch_quantity($_POST['batch'], $_POST['quantity']);

            $this->obj_stock_detail->stock_master_id = $stock_master_id;
            $this->obj_stock_detail->batch_id = $_POST['batch'];
            $this->obj_stock_detail->quantity = '-' . $_POST['quantity'];
            $this->obj_stock_detail->temp = 1;
            $this->obj_stock_detail->save();
            $this->obj_stock_batch->recalculate_batch_qty($_POST['batch']);


            $product_arr = $this->obj_product->get_warehouse_products();
            if ($product_arr)
                $data['product'] = $product_arr->result_array();



            $stock_master_record = $this->obj_stock_master->find_by_id($stock_master_id);
            if ($stock_master_record)
                $data['stock_master_records'] = $stock_master_record->result_array();
            //            echo '<pre>';
            //            print_r($data['stock_master_records']);
            //            echo '</pre>';
            //            exit;
            $data['warehouse_to'] = $data['stock_master_records'][0]['warehouse_to'];

            $patient_arr = $this->obj_patient->find_by_id($data['warehouse_to']);
            if ($patient_arr)
                $data['patient'] = $patient_arr->result_array();

            $data['temp_records'] = $this->obj_stock_detail->get_temp_records($stock_master_id);
            $data['master_id'] = $stock_master_id;
            $data['page_title'] = 'Stock Issue';

            $data['main_content'] = $this->load->view('inventory_management/stock_issue_patients', $data, TRUE);
            $this->load->view('layout/main', $data);
        } else {
            $data = array();

            $product_arr = $this->obj_product->get_warehouse_products();
            if ($product_arr)
                $data['product'] = $product_arr->result_array();

            $patient_arr = $this->obj_patient->find_all();
            if ($patient_arr)
                $data['patient'] = $patient_arr->result_array();

            $data['temp_records'] = $this->obj_stock_master->get_temp_master_records(2, "patients");
            $master_id_arr = $data['temp_records'];

            if (!empty($master_id_arr)) {
                if ($master_id_arr)
                    $master_result = $master_id_arr->result_array();
                foreach ($master_result as $row) {
                    $data['master_id'] = $row['stock_master_id'];
                    $data['tran_reference_number'] = $row['transaction_reference'];
                }
            }
            $data['page_title'] = 'Stock Issue';
            $data['main_content'] = $this->load->view('inventory_management/stock_issue_patients', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function recalculate_batch_qty($batch_id)
    {
        echo $this->obj_stock_batch->recalculate_batch_qty($batch_id);
    }

    public function stock_issue_patients_tabular()
    {
        if (!empty($_POST)) {
            //            echo '<pre>';
            //            print_r($_REQUEST);
            //            echo '</pre>';
            //            exit;


            $this->obj_stock_master->transaction_date = date('Y-m-d', strtotime($this->input->post('receiving_time')));
            $this->obj_stock_master->transaction_type_id = 2;
            $this->obj_stock_master->transaction_reference = "Issuance to patients";
            $this->obj_stock_master->warehouse_from = $_SESSION['warehouse_id'];
            $this->obj_stock_master->warehouse_to = $this->input->post('center_patient');
            $this->obj_stock_master->created_by = $_SESSION['id'];
            $this->obj_stock_master->created_on = date("Y-m-d");
            $this->obj_stock_master->temp = 0;
            $this->obj_stock_master->remarks = $this->input->post('remarks');
            $this->obj_stock_master->issuance_to = 'patients';
            $this->obj_stock_master->vials_returned = $this->input->post('vials_returned');
            $stock_master_id = $this->obj_stock_master->save();


            $batches = $this->input->post('batch');
            $quantities = $this->input->post('quantity');
            $next_issuance_date = $this->input->post('next_issuance_date');
            if (!empty($batches) && count($batches) > 0 && $stock_master_id > 0) {
                foreach ($batches as $k => $batch_id) {
                    if (!empty($quantities[$batch_id]) && $quantities[$batch_id] > 0) {
                        $qty = $quantities[$batch_id];

                        $nxt_date = '';
                        if (!empty($next_issuance_date[$batch_id]) && $next_issuance_date[$batch_id] > 0) {
                            $d = str_replace('/', '-', $next_issuance_date[$batch_id]);
                            $nxt_date = date('Y-m-d', strtotime($d));
                        }

                        $this->obj_stock_detail->stock_master_id = $stock_master_id;
                        $this->obj_stock_detail->next_issuance_date = $nxt_date;
                        $this->obj_stock_detail->batch_id = $batch_id;
                        $this->obj_stock_detail->quantity = '-' . $qty;
                        $this->obj_stock_detail->temp = 0;
                        //                        echo '<pre>';
                        //                        print_r($this->obj_stock_detail);
                        //                        print_r($_REQUEST);
                        //                        echo '</pre>';
                        //                        exit;
                        $this->obj_stock_detail->save();


                        $this->obj_stock_batch->recalculate_batch_qty($batch_id);
                    }
                }
            }


            redirect(base_url() . 'patients/history/' . $this->input->post('center_patient'), 'refresh');
        } else {
            $data = array();

            $product_arr = $this->obj_product->get_warehouse_stock();
            if ($product_arr)
                $data['product'] = $product_arr->result_array();

            $this_pat_id = $this->input->get_post('patient_id');
            $patient_arr = $this->obj_patient->find_by_id($this_pat_id);
            if ($patient_arr) {
                $data['patient'] = $patient_arr->result_array();
            }
            //echo '<pre>';
            //print_r($data['patient'][$_REQUEST['patient_id']]);
            //echo '</pre>';
            //exit;

            $data['temp_records'] = $this->obj_stock_master->get_temp_master_records(2, "patients");
            $master_id_arr = $data['temp_records'];

            if (!empty($master_id_arr)) {
                if ($master_id_arr)
                    $master_result = $master_id_arr->result_array();
                foreach ($master_result as $row) {
                    $data['master_id'] = $row['stock_master_id'];
                    $data['tran_reference_number'] = $row['transaction_reference'];
                }
            }

            $data['lists_oral_drugs']     = (array)$this->obj_lists->get_list(1);
            $hist = $this->obj_patient->find_medicine_history($this_pat_id);
            if (!empty($hist)) {
                $data['medicine_history'] = $hist->result_object();
            }
            $tem = $this->obj_patient->find_diabetic_data($this_pat_id);
            @$data['oral_drugs'] = $tem['oral_drugs'];
            @$data['oral_drugs_dose'] = $tem['oral_drugs_dose'];
            //             echo '<pre>';
            ////            print_r($data['medicine_history']);
            //            print_r($data['oral_drugs']);
            //            print_r($data['oral_drugs_dose']);
            ////            print_r($data['lists_oral_drugs']);
            ////            print_r($data['patient']);
            ////            print_r($_REQUEST);
            //            echo '</pre>';
            //            exit;
            $data['page_title'] = 'Stock Issue';
            $data['main_content'] = $this->load->view('inventory_management/stock_issue_patients_tabular', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    function get_product_batches_stock_issue()
    {
        $item_id = $_POST['item_id'];
        $wh_id = $this->session->userdata('warehouse_id');
        $result = $this->obj_stock_batch->get_product_batches($item_id, $wh_id);

        echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row) {
            echo "<option value=" . $row->batch_id . ">" . $row->batch_number . "</option>";
        }
    }

    function get_batches_of_wh()
    {
        $item_id = $this->input->post('item_id');
        $wh_id = $this->input->post('wh_id');
        $result = $this->obj_stock_batch->get_product_batches($item_id, $wh_id);

        //echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row) {
            echo "<option value=" . $row->batch_id . ">" . $row->batch_number . "</option>";
        }
    }

    function get_available_prods_of_wh()
    {
        $id = $this->input->post('wh_id');
        $result = $this->obj_stock_batch->get_available_prods_of_wh($id);


        if (!empty($result)) {
            echo "<option value=\"\" >Select</option>";
            foreach ($result->result_object() as $row) {
                echo "<option value=" . $row->item_id . ">" . $row->product_name . "</option>";
            }
        }
    }

    function get_batch_info()
    {
        $batch_id = $_POST['batch_id'];
        $result = $this->obj_stock_batch->get_batch_info($batch_id);
        $json_array = array();
        foreach ($result->result_object() as $row) {
            $json_array['available_qty'] = $row->Qty;
            $json_array['expiry_date'] = $row->batch_expiry;
        }
        echo json_encode($json_array);
    }

    function get_center_patients()
    {
        $type = $_POST['issue_type'];
        if ($type == 'centers') {
            $result = $this->obj_warehouse->find_all();

            echo "<option value=>Select</option>";
            foreach ($result->result_object() as $row) {
                echo "<option value=" . $row->pk_id . ">" . $row->warehouse_name . "</option>";
            }
        } else if ($type == 'patients') {
            $result = $this->obj_patient->find_all();
            echo "<option value=>Select</option>";
            foreach ($result->result_object() as $row) {
                echo "<option value=" . $row->pk_id . ">" . $row->full_name . "-" . $row->nic_no . "</option>";
            }
        }
    }

    function stock_receive_search()
    {
        $data['result'] = $this->obj_stock_master->stock_search(1);
        $data['page_title'] = 'Stock Receive Search';

        $data['main_content'] = $this->load->view('inventory_management/stock_receive_search', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    function stock_issue_search()
    {
        $data['result'] = $this->obj_stock_master->stock_search(2);
        $data['page_title'] = 'Stock Receive Search';

        $data['main_content'] = $this->load->view('inventory_management/stock_issue_search', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    function save_temporary_records()
    {
        $stock_master_id = $_POST['stock_master_id'];
        $this->obj_stock_master->save_master_temp($stock_master_id);
        $this->obj_stock_detail->save_details_temp($stock_master_id);

        //Auto Save Issue Voucher
        $this->obj_stock_master->auto_receive_voucher($stock_master_id); 
    }

    function acknowledge_records()
    {
        $data['result'] = $this->obj_stock_master->get_issued_records();
        $data['page_title'] = 'Acknowledge Issue';
        $data['main_content'] = $this->load->view('inventory_management/acknowledge_records', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    function del_stock_detail($det_id)
    {
        $d = $this->obj_stock_detail->get_detail_record($det_id);
        $detail_data = $d->result_array();
        $detail_data = $detail_data[0];
        $batch_id = $detail_data['batch_id'];
        //        echo '<pre>';
        //        print_r($detail_data);
        //        echo '</pre>';
        //        exit;
        if ($detail_data['created_by'] == $this->session->userdata('id')) {

            $data['result'] = $this->obj_stock_detail->delete_txn($det_id);
            $this->obj_stock_batch->recalculate_batch_qty($batch_id);
        }
        redirect('inventory_management/stock_issue_search', 'refresh');
    }

    function issue_to_receive()
    {
        //submit data for the Acknowledgement of stock receipt
        $stock_master_array = array_unique($_REQUEST['approved']);
        $stock_master_id = '';
        foreach ($stock_master_array as $key => $value) {
            $result = $this->obj_stock_master->find_by_id($value);
            foreach ($result->result_array() as $row) {

                $this->obj_stock_master->transaction_date = $row['transaction_date'];
                $this->obj_stock_master->transaction_type_id = 1;
                $this->obj_stock_master->transaction_reference = $row['transaction_reference'];
                $this->obj_stock_master->warehouse_from = $row['warehouse_from'];
                $this->obj_stock_master->warehouse_to = $row['warehouse_to'];
                $this->obj_stock_master->created_by = $_SESSION['id'];
                $this->obj_stock_master->created_on = date("Y-m-d");
                $this->obj_stock_master->temp = 0;
                $this->obj_stock_master->issuance_to = 'centers';
                $this->obj_stock_master->remarks = $row['remarks'];
                $this->obj_stock_master->pk_id = NULL;

                $stock_master_id = $this->obj_stock_master->save();
                $wh_to = $row['warehouse_to'];
                //               
                $result_details = $this->obj_stock_detail->find_by_master_id($value);
                //                echo 'A:<pre>';
                //                print_r($stock_master_array);
                //                print_r($this->obj_stock_master);
                //                print_r($result_details->result_array());
                //                echo '</pre>';
                //                exit;
                foreach ($result_details->result_array() as $row_1) {
                    unset($this->obj_stock_batch->batch_id);
                    $res_batch = $this->obj_stock_batch->find_by_id($row_1['batch_id']);

                    $this->obj_stock_batch->batch_number = $res_batch['batch_number'];
                    $this->obj_stock_batch->batch_expiry = date('Y-m-d', strtotime($res_batch['batch_expiry']));
                    $this->obj_stock_batch->manufacturing_date = date('Y-m-d', strtotime($res_batch['manufacturing_date']));
                    $this->obj_stock_batch->item_id = $res_batch['item_id'];
                    $this->obj_stock_batch->wh_id = $wh_to;
                    $this->obj_stock_batch->quantity = (abs($row_1['quantity']));
                    $this->obj_stock_batch->funding_source = $res_batch['funding_source'];
                    $this->obj_stock_batch->manufacturer = $res_batch['manufacturer'];
                    //                    echo 'BC:<pre>';
                    //                    print_r($res_batch);
                    //                    print_r($this->obj_stock_batch);
                    //                    echo '</pre>';
                    //                    exit;
                    $stock_batch_id = $this->obj_stock_batch->save();

                    $this->obj_stock_detail->stock_master_id = $stock_master_id;
                    $this->obj_stock_detail->batch_id = $stock_batch_id;
                    $this->obj_stock_detail->quantity = ltrim($row_1['quantity'], '-');
                    $this->obj_stock_detail->temp = 0;
                    $this->obj_stock_detail->save();
                }
                //                 echo 'A:<pre>';
                //                print_r($stock_master_array);
                //                print_r($this->obj_stock_master);
                //                print_r($result_details->result_array());
                //                echo '</pre>';
                //                exit;
                $this->obj_stock_master->pk_id = $stock_master_id;
                $this->obj_stock_master->linked_transaction = $value;
                $this->obj_stock_master->link_trans();

                $this->obj_stock_master->pk_id = $value;
                $this->obj_stock_master->mark_received();
            }
            //             echo 'D:';print_r($stock_master_id);
        }
        //        echo 'final exit';
        //        exit;
        redirect(base_url() . 'inventory_management/stock_receive_search', 'refresh');
    }

    function get_product_unit()
    {

        $p_id = $_POST['item_id'];

        $this->db->select("strength");
        $this->db->from("product");
        $this->db->where("pk_id", $p_id);
        $result = $this->db->get();

        $row = $result->result_array();

        echo strtok($row[0]['strength'], " ");
    }

    function ajax_del_patient_pres(){

		$batch_id = $_POST['b_id'];

        $this->db->from("stock_detail");
        $this->db->where("pk_id", $_POST['d_id']);
        $this->db->delete();

        $this->db->from("stock_master");
        $this->db->where("pk_id", $_POST['m_id']);
        $this->db->delete();

		$this->obj_stock_batch->recalculate_batch_qty($batch_id);

		$data['temp_records'] = $this->obj_stock_detail->get_issued_records($_POST['p_id']);
		$this->load->view('inventory_management/stock_issue_patients2', $data);
	}
}
