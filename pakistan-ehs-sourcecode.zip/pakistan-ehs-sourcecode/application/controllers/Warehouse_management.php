<?php

class Warehouse_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('warehouse');
        $this->load->model('locations');
        $this->load->model('stakeholder');
        $this->load->model('warehouse_categories');
        $this->load->model('warehouse_types');
        $this->load->model('cities');
        $this->load->library("pagination");
        $this->obj = new Warehouse();
        $this->obj_location = new Locations();
        $this->obj_stakeholder = new Stakeholder();
        $this->obj_wh_categories = new Warehouse_categories();
        $this->obj_wh_types = new Warehouse_types();
//        $this->obj_cities = new Cities();
    }

    public function index() {
        $data = array();
        $data['result'] = $this->obj->find_all(); 
        $data['page_title'] = 'Warehouses';
        $data['main_content'] = $this->load->view('warehouse_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    public function view_funding_source() {
        $data = array();
        $data['result'] = $this->obj->find_suppliers();
        $data['page_title'] = 'Warehouses';
        $data['main_content'] = $this->load->view('warehouse_management/view_funding_source', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add_wh() {

        if (isset($_POST) && !empty($_POST)) {
            if (isset($_POST['wh_id'])) {
                $this->obj->pk_id = $_POST['wh_id'];
            }
            $this->obj->warehouse_name = $_POST['hf_name'];
            $this->obj->district_id = $_SESSION['district_id'];
            $this->obj->province_id = $_SESSION['province_id'];
            $this->obj->tehsil_id = $_SESSION['district_id'];
            $this->obj->uc_id = $_SESSION['district_id'];
            //$this->obj->city_id = $_POST['city'];
            $this->obj->province_name = "";
            $this->obj->district_name = "";
            $this->obj->uc_name = "";
            $this->obj->tehsil_name = "";
            $this->obj->city_name = $_POST['city_name'];
            $this->obj->category_id = $_POST['category'];
            $this->obj->category_name = $_POST['category_name'];
            $this->obj->facility_type_id = $_POST['type'];
            $this->obj->facility_type_name = $_POST['facility_type_name'];
            $this->obj->stakeholder_name = $_POST['stakeholder_name'];
            $this->obj->facility_code = $_POST['hf_code'];
            $this->obj->contact_person = $_POST['contact_person'];
            $this->obj->contact_designation = $_POST['designation'];
            $this->obj->contact_number = $_POST['contact_number'];
            $this->obj->address = $_POST['address'];
            $this->obj->longitude = $_POST['longitude'];
            $this->obj->latitude = $_POST['latitude'];
            if (isset($_POST['parent_hospital'])) {
                $this->obj->parent_hospital_id = $_POST['parent_hospital'];
                $this->obj->parent_hospital_name = $_POST['parent_hospital_name'];
            }
            $this->obj->status = 1;
            $this->obj->created_by = $_SESSION['id'];
            $this->obj->created_date = date("Y-m-d h:i:sa");
            $this->obj->modified_by = $_SESSION['id'];
            $this->obj->modified_date = date("Y-m-d h:i:sa");



            $this->obj->save();
//            exit;
            redirect(base_url() . 'warehouse_management/index', 'refresh');
        }
        $stk_arr = $this->obj_stakeholder->find_all();
        $data['stakeholders'] = $stk_arr->result_array();

        $categories_arr = $this->obj_wh_categories->find_active();
        $data['categories'] = $categories_arr->result_array();

        $types_arr = $this->obj_wh_types->find_active();
        $data['types'] = $types_arr->result_array();

        $data['districts'] = $this->obj_location->district_dropdown();

        $data['page_title'] = 'Add Facilities';
        $data['main_content'] = $this->load->view('warehouse_management/add_warehouse', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add_funding_source() {

        if (isset($_POST) && !empty($_POST)) {
//            echo '<pre>';
//            print_r($_REQUEST);
//            echo '</pre>';
//            exit;
            if (isset($_POST['wh_id'])) {
                $this->obj->pk_id = $_POST['wh_id'];
            }
            $this->obj->warehouse_name = $_POST['hf_name'];
            $this->obj->category_id = $_POST['category'];
            $this->obj->facility_type_id = $_POST['type'];
            $this->obj->status = 1;
            $this->obj->created_by = $_SESSION['id'];
            $this->obj->created_date = date("Y-m-d h:i:sa");
            $this->obj->modified_by = $_SESSION['id'];
            $this->obj->modified_date = date("Y-m-d h:i:sa");



            $this->obj->save();
//            exit;
            redirect(base_url() . 'warehouse_management/view_funding_source', 'refresh');
        }

        $data['page_title'] = 'Add Funding Source';
        $data['main_content'] = $this->load->view('warehouse_management/add_funding_source', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit_wh() {
        
        $res = $this->obj->find_by_id($_REQUEST['id']);
        $data['result'] = $res->result_array();
        $prov   = $data['result'][0]['province_id'];
        $dist   = $data['result'][0]['district_id'];
        $teh    = $data['result'][0]['tehsil_id'];
//        echo '<pre>';
//        print_r($_REQUEST);
//        print_r($data['result']);
//        echo '</pre>';
//        exit;
//        $districts = $this->obj_location->district_dropdown();
        $districts = $this->obj_location->find_by_parent_id($prov,4);
        $data['districts'] = $districts->result_array();

        $stk_arr = $this->obj_stakeholder->find_all();
        $data['stakeholders'] = $stk_arr->result_array();

        $categories_arr = $this->obj_wh_categories->find_all();
        $data['categories'] = $categories_arr->result_array();

        $types_arr = $this->obj_wh_types->find_all();
        $data['types'] = $types_arr->result_array();

//        $data['cities'] = $this->obj_cities->find_all();

//        $tehsils = $this->obj_location->find_by_location_level(5);
        //$tehsils = $this->obj_location->find_by_parent_id($dist,5);
        
        //$data['tehsils'] = $tehsils->result_array();

//        $ucs = $this->obj_location->find_by_location_level(6);
        ///if(!empty($teh))
       // {
        //    $ucs = $this->obj_location->find_by_parent_id($teh,6);
        //    $data['ucs'] = $ucs->result_array();
       // } else {
            $data['ucs'] = array();
        //}
        $data['js'] = array("warehouse_management/add_wh");
        $data['page_title'] = 'Edit Facilities';
        $data['main_content'] = $this->load->view('warehouse_management/add_warehouse', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    public function edit_funding_source() {
        
        $res = $this->obj->find_by_id($_REQUEST['id']);
        $data['result'] = $res->result_array();

        $data['js'] = array("warehouse_management/add_wh");
        $data['page_title'] = 'Edit funding source';
        $data['main_content'] = $this->load->view('warehouse_management/add_funding_source', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate_wh() {
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'warehouse_management/index', 'refresh');
    }

}
