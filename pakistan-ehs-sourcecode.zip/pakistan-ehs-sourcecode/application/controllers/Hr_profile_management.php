<?php

class Hr_profile_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('hr_profile');
        $this->load->model('user');
        $this->load->model('warehouse');
        $this->load->model('hr_types');
        $this->obj=new Hr_profile();
        $this->obj_user=new User();
        $this->obj_warehouse = new Warehouse();
        
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "HR Profile";
        $data['main_content'] = $this->load->view('hr_profile_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $hr_types = new Hr_types();
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if(isset($_POST['id'])){
                $this->obj->pk_id = $_POST['id'];
            }
             
            $this->obj->full_name = $_POST['full_name'];
            $this->obj->designation = $_POST['designation'];
            $this->obj->cnic_number = $_POST['cnic_number'];
            $this->obj->pmdc_number = $_POST['pmdc_number'];
            $this->obj->link_user = $_POST['link_user'];
            $this->obj->warehouse_id = $_POST['hf'];
            $this->obj->hr_type_id = $_POST['hr_type'];
            $this->obj->hr_type = $hr_types->find_field_by_id($_POST['hr_type'],'name');
            $this->obj->is_active = 1;
            $this->obj->hr_status_id = $_POST['hr_status'];

            $this->obj->department = $_POST['department'];
            $this->obj->reg_number = $_POST['reg_number'];
            $this->obj->pmc_expiry = convert_date($_POST['pmc_expiry']);
            $this->obj->pmc_category = $_POST['pmc_category'];
            $this->obj->blood_group = $_POST['blood_group'];
            $this->obj->doj = convert_date($_POST['doj']);
            $this->obj->job_band = $_POST['job_band'];
            $this->obj->address = $_POST['address'];
            $this->obj->pcn = $_POST['pcn'];
            $this->obj->email = $_POST['email'];
            $this->obj->em_contact = $_POST['em_contact'];
            $this->obj->em_contact_no = $_POST['em_contact_no'];
            $this->obj->experience = $_POST['experience'];
            $this->obj->education = $_POST['education'];
            $this->obj->dob = convert_date($_POST['dob']);
            $this->obj->gender = $_POST['gender'];
            $this->obj->stakeholder_id = $_SESSION['stk_id'];
            
            $this->obj->save();
            redirect(base_url() . 'hr_profile_management/index', 'refresh');
        }
        $user_arr = $this->obj_user->find_all();
        $data['users'] = $user_arr->result_array();
        $data['hr_types'] = $hr_types->get_combo();
        $hf_arr = $this->obj_warehouse->find_active();
        $data['hf'] = $hf_arr->result_array();
//        exit;
        $data['page_title'] = "HR Profile";
        $data['main_content'] = $this->load->view('hr_profile_management/add_hr', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $hr_types = new Hr_types();
        $data = array(); 
        $user_arr = $this->obj_user->find_all();
        $data['users'] = $user_arr->result_array();
        $data['hr_types'] = $hr_types->get_combo();
        $hf_arr = $this->obj_warehouse->find_active();
        $data['hf'] = $hf_arr->result_array();
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('hr_profile_management/add_hr', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'hr_profile_management/index', 'refresh');
    }

}
