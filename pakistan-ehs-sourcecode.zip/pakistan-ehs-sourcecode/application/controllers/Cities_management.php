<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cities_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('cities');
        $this->obj = new Cities();
    }

    public function index() {
         
        $data = array();
        $data['result_all'] = $this->obj->find_all();
        
        //--------Cols to display in View -----------
        $cols_to_display=array();   //key is Display text, value is the actual field name in db
        $cols_to_display['City Name']='city_name';
        //$cols_to_display['Province']='prov_name';
        $data['cols_to_display']=$cols_to_display;

        $data['result']=array();
        foreach($data['result_all'] as $k=>$arr_val){
            $data['result'][$k]['pk_id']=$arr_val['pk_id'];
            foreach ($arr_val as $key => $val) {
                if(in_array($key, $cols_to_display)){
                $data['result'][$k][$key]=$val;
                }
            }
        } 
        //--------Cols to display in View -----END------

        $data['page_title'] = 'Manage Cities';
        $data['main_content'] = $this->load->view('cities_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
 
//        print_r($_POST);exit;
        if ( !empty($_POST)) {
             
            $this->obj->city_name = $_POST['city_name'];   
            $file = $this->obj->save();
            redirect(base_url() . 'cities_management/index', 'refresh');
        } else {  
            $data['page_title'] = 'Add New'; 
            $data['main_content'] = $this->load->view('cities_management/add', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function edit() {  
        $edit_id = $_REQUEST['id'];
        $file = $this->obj->find_by_id($edit_id);  
        $data['result'] = $file->result_array();
        $data['edit_id'] = $edit_id; 
        $data['page_title'] = 'Edit City';
        $data['main_content'] = $this->load->view('cities_management/edit', $data,TRUE);
        $this->load->view('layout/main', $data);
    }

    public function change_status() {
 
        $this->obj->pk_id = $_REQUEST['id'];
        $this->obj->is_active = $_REQUEST['status'];
        $file = $this->obj->is_active();
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = 'Manage Users';
        $data['main_content'] = $this->load->view('cities_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

}
