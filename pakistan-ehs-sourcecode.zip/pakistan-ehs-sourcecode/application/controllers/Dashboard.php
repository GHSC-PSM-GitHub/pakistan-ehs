<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        check_login_user();
        //$this->load->model('user');
        $this->load->model('Patients_model');
        $this->load->model('dashboard_model');
    }

    public function index_old() {
        $data = array();
        $data['page_title'] = 'Dashboard';
        $data['main_content'] = $this->load->view('dashboard/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function index() {
        $data = array();
        $data['page_title'] = 'Dashboard';
        $data['mj_patient'] = $this->dashboard_model->mj_patient();
        $data['nkb_patient'] = $this->dashboard_model->nkb_patient();
        $data['trans_rcv'] = $this->dashboard_model->trans_rcv();
        $data['trans_issue'] = $this->dashboard_model->trans_issue();
        $data['mj_product'] = $this->dashboard_model->mj_product();
        $data['nkb_product'] = $this->dashboard_model->nkb_product();
        $data['quantity_available'] = $this->dashboard_model->quantity_available();
        $data['quantity_rcv'] = $this->dashboard_model->quantity_rcv();
        $data['quantity_consume'] = $this->dashboard_model->quantity_consume();
//        print_r($data['nkb_product']);
//        exit;
        $data['main_content'] = $this->load->view('dashboard/new_dashboard', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function lab_supervisor() {
        $data = array();
        $data['page_title'] = 'Dashboard';
        $data['main_content'] = $this->load->view('dashboard/lab_supervisor', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function lab_worker() {
        $patient = new Patients_model();
        $data = array();
        $data['page_title'] = 'Dashboard';
        $data['patient'] = $patient->find_by_id(18);
        $data['main_content'] = $this->load->view('dashboard/lab_worker', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

}
