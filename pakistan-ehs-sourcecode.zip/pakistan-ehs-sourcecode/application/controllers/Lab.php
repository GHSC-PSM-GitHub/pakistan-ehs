<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lab extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('patient_lab_master_model');
		$this->load->model('patient_lab_detail_model');
        //$this->load->model('locations');
	}
	
	public function test_supervisor()
	{
		$data = array();
		$data['page_title'] = 'Lab Supervisor';

		$lab_master = new patient_lab_master_model();
		$data['data'] = $lab_master->find_all();

        $data['main_content'] = $this->load->view('lab/test_supervisor', $data, TRUE);
        $this->load->view('layout/main', $data);
	}

	public function lab_worker_dataentry()
	{
		if(isset($_POST) and !empty($_POST)){
			$formdata = $_POST['pval'];
			foreach($formdata as $patient_id=>$patient_lab){
				foreach($patient_lab as $patient_lab_master_id=>$lab_tests){
					foreach($lab_tests as $lab_test_master_id=>$lab_tests_detail){
						foreach($lab_tests_detail as $lab_tests_detail_id=>$val){
							$patient = new Patient_lab_detail_model();
							$patient->patient_lab_master_id = $patient_lab_master_id;
							$patient->lab_test_detail_id = $lab_tests_detail_id;
							$patient->lab_test_master_id = $lab_test_master_id;
							$patient->test_result = $val;
							$patient->patient_id = $patient_id;
							$patient->created_date = date("Y-m-d");
							$patient->created_by = 5;
							$patient->updated_date = date("Y-m-d");
							$patient->updated_by = 5;
							$patient->verified_date = date("Y-m-d");
							$patient->verified_by = 5;
							$patient->comments = $_POST['comments'][$patient_id][$patient_lab_master_id][$lab_test_master_id][$lab_tests_detail_id];
							$pk_id = $patient->save();
						}
					}
				}
			}
		}

		$data = array();
		$data['page_title'] = 'Lab Supervisor';

		$lab_master = new patient_lab_master_model();
		$data['completed'] = $lab_master->find_all_completed();
		$data['pending'] = $lab_master->find_all_pending();

        $data['main_content'] = $this->load->view('lab/lab_worker_dataentry', $data, TRUE);
        $this->load->view('layout/main', $data);
	}

	public function lab_worker()
	{
		$data = array();
		$data['page_title'] = 'Lab Worker';

		$lab_master = new patient_lab_master_model();
		$data['data'] = $lab_master->find_all();

        $data['main_content'] = $this->load->view('lab/lab_worker', $data, TRUE);
        $this->load->view('layout/main', $data);
	}

	public function ajax_lab_worker()
	{
		echo create_combo("lab_worker",array("Lab Worker 1", "Lab Worker 2"));
		echo '<br><div class="alert alert-success" role="alert" style="display:none">
		<span id="success_msg"></span>
		</div>';
		echo "";
	}

	public function ajax_patient_lab_details(){
		$lab_master = new patient_lab_master_model();
		$data['data'] = $lab_master->get_lab_details($_POST['pk_id'],$_POST['p_id']);

		$this->load->view('lab/ajax_patient_lab_details', $data);
	}

}
