<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('login_model');
        $this->load->model('mobile_detect');
        $this->load->library('session');
    }

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function index()
    {
        $data = array();
        $data['breadcrumb'] = 'Login';
        $data['page_title'] = 'Login';
        /* $data['main_content'] = $this->load->view('auth/index', $data, TRUE); */
        $this->load->view('login', $data);
    }

    //    public function login() {
    //        $data = array();
    //        $data['breadcrumb'] = 'Login';
    //        $data['page_title'] = 'Login';
    //        $this->load->view('login', $data);
    //    }

    /*     * **************Function login**********************************
     * @type            : Function
     * @function name   : log
     * @description     : Authenticatte when uset try lo login. 
     *                    if autheticated redirected to logged in user dashboard.
     *                    Also set some session date for logged in user.   
     * @param           : null 
     * @return          : null 
     * ********************************************************** */

    public function login()
    {

        if ($_POST) {
            $query = $this->login_model->validate_user();

            //-- if valid
            if ($query) {
                $data = array();
                foreach ($query as $row) {
                    $data = array(
                        'id' => $row->pk_id,
                        'name' => $row->username,
                        'email' => $row->email,
                        'role' => $row->role_id,
                        'province_id' => $row->province_id,
                        'district_id' => $row->district_id,
                        'warehouse_id' => $row->warehouse_id,
                        'is_login' => TRUE,
                        'stk_name' => (isset($_POST['stk_name']) ? $_POST['stk_name'] : 'mj'),
                        'stk_id' => $row->stakeholder_id
                    );
                    $this->session->set_userdata($data);
                    $role_id = $row->role_id;
                }

                if ($this->mobile_detect->isMobile()) {
                    $url = base_url('dataentry/summary_form_m');
                }

                switch ($role_id) {
                    case 0:
                        $url = base_url('hospital_management/index');
                        break;
                    case 2:
                        $url = base_url('patients/search');
                        break;
                    case 3:
                        $url = base_url('patients/search');
                        break;
                    case 4:
                        $url = base_url('patients/search');
                        break;
                    case 5:
                        $url = base_url('dashboard/lab_worker');
                        break;
                    case 6:
                        $url = base_url('reports/soh');
                        break;
                    case 7:
                        $url = base_url('hr_profile_management/index');
                        break;
                    default:
                        $url = base_url('dashboard/index');
                        break;
                }

                redirect($url, 'refresh');
            } else {
                redirect(base_url() . '/', 'refresh');
            }
        } else {
            redirect(base_url() . '/', 'refresh');
        }
        //exit;
    }

    /*     * ***************Function logout**********************************
     * @type            : Function
     * @function name   : logout
     * @description     : Log Out the logged in user and redirected to Login page  
     * @param           : null 
     * @return          : null 
     * ********************************************************** */

    function logout()
    {
        $system = (isset($_SESSION['stk_name']) ? $_SESSION['stk_name'] : 'mj');
        $this->session->sess_destroy();
        $data = array();
        $data['breadcrumb'] = 'Login';
        $data['page_title'] = 'Login';
        /* $data['main_content'] = $this->load->view('auth/index', $data, TRUE); */
        $this->load->view('login', $data);
        redirect(base_url($system));
    }
}
