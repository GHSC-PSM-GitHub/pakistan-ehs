<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    
    public function index()
    {
        
        $data = array(); 
        $data['page_title'] = 'Sample';
        $data['main_content'] = $this->load->view('empty_format', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
	
	public function view($page = '')
	{
		$this->db->where('code', $page);
		$this->db->where('is_active', 1);
		$result = $this->db->get("stakeholder");
		$row = $result->result_array();
		if(count($row) > 0){
			$data['title'] = $row[0]['stakeholder_name'];
			$data['code'] = $row[0]['code'];
			$data['id'] = $row[0]['pk_id'];
			$data['logo'] = $row[0]['logo'];
			$data['css'] = $row[0]['extra_css'];
			$data['background_image'] = $row[0]['background_image'];

			$this->load->view("login", $data);
		} else if (file_exists(APPPATH.'views/'.$page.'.php')) {
			$data['title'] = ucfirst($page);  // Capitalize the first letter
			$this->load->view($page, $data);
		} else {
			$data['title'] = ucfirst($page);  // Capitalize the first letter
			$this->load->view("login2", $data);
		}
	}

}
