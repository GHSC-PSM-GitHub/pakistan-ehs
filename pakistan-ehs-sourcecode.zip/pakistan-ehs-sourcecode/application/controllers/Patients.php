<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Patients extends CI_Controller
{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		check_login_user();
		$this->load->model('patients_model');
		$this->load->model('locations');
		$this->load->model('date_time');
		$this->load->model('rdt_list_model');
		$this->load->model('patient_rdt_model');
		$this->load->model('patient_lab_master_model');
		$this->load->model('patient_lab_detail_model');
		$this->load->model('lab_test_master_model');
		$this->load->model('sample_collection_types_model');
		$this->load->model('patient_preliminary_examination_model');
		$this->load->model('patient_clinical_notes_model');
		$this->load->model('patient_prescription_model');
		$this->load->model('patient_ipd_model');
		$this->load->model('hr_profile');
		$this->load->model('warehouse');
		$this->load->model('patient_status_model');
		$this->load->model('patient_allocation_model');
		$this->load->model('vitals_model');
		$this->load->model('product_model');
		$this->load->model('cities_model');
		$this->load->model('warehouse_categories');
		$this->load->model('warehouse_types');
		$this->load->model('Stock_detail_model');
		$this->load->model('patient_other_products_model');
	}

	public function index()
	{
		$this->load->view("patients/index", "");
	}

	public function search()
	{
		$patients = new patients_model();

		if (isset($_POST) && !empty($_POST)) {
			$data['search_result'] = $patients->find_by_mrno($_POST['search_by'], $_POST['search_text']);
			$data['form'] = $_POST;
		} else {
			switch ($_SESSION['role']) {
				case 2:
					$data['search_result'] = $patients->find_by_user();
					break;
				case 3:
					$data['search_result'] = $patients->find_by_facility();
					break;
				case 4:
					$data['search_result'] = $patients->find_by_facility();
					break;
				case 5:
					$url = base_url('dashboard/lab_worker');
					break;
				case 6:
					$url = base_url('dashboard/lab_worker');
					break;
				default:
					$data['search_result'] = $patients->find_by_user();
					break;
			}
		}

		$data['page_title'] = 'Search Patient';
		$data['main_content'] = $this->load->view('patients/search', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	public function report()
	{
		$patients = new patients_model();

		if (isset($_POST) && !empty($_POST)) {
			$data['search_result'] = $patients->find_by_all($_POST);


			$data['form'] = $_POST;
		} else {
			$data['search_result'] = $patients->find_by_all('', '');
		}

		$wh = new Warehouse();
		$data['rooms'] = $wh->get_combo();
		$data['page_title'] = 'Patient Details';
		$data['main_content'] = $this->load->view('patients/report', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	public function summary_report()
	{
		$patients = new patients_model();

		if (isset($_POST) && !empty($_POST)) {
			$data['search_result'] = $patients->find_by_all($_POST);


			$data['form'] = $_POST;
		} else {
			$data['search_result'] = $patients->find_by_all('', '');
		}

		$wh = new Warehouse();
		$data['rooms'] = $wh->get_combo();
		$data['page_title'] = 'Patient Details';
		$data['main_content'] = $this->load->view('patients/summary_report', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	public function merge()
	{
		$patients = new patients_model();

		if (isset($_POST) && !empty($_POST)) {
			$data['primary_emr'] = $patients->find_by_mrno("mr_no", $_POST['primary_emr']);
			$data['secondary_emr'] = $patients->find_by_mrno("mr_no", $_POST['secondary_emr']);
			$data['form'] = $_POST;
		}

		$data['page_title'] = 'Merge Patient\'s EMR';
		$data['main_content'] = $this->load->view('patients/merge', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	public function merge_patients()
	{
		$patients = new patients_model();

		if (isset($_POST) && !empty($_POST)) {
			$primary_id = $_POST['mergeoption'];
			$secondary_ids = $_POST['patient_ids'];

			foreach ($secondary_ids as $id) {
				if ($id != $primary_id) {
					$merge_id = $id;
				}
			}

			$this->db->set('patient_id', $primary_id);
			$this->db->where('patient_id', $merge_id);
			$this->db->update('patient_prescriptions');

			$this->db->set('patient_id', $primary_id);
			$this->db->where('patient_id', $merge_id);
			$this->db->update('patient_ipd');

			$this->db->set('patient_id', $primary_id);
			$this->db->where('patient_id', $merge_id);
			$this->db->update('patient_lab_master');

			$this->db->set('status', '0');
			$this->db->where('pk_id', $merge_id);
			$this->db->update('patients');
		}
	}

	public function update_qty() {
		$patients = new patients_model();
		echo $data['batch_id'] = $this->input->post('batch_id');die;
		$data['quantity'] = $this->input->post('quantity');
		$patient_id = $this->input->post('patient_id');
		if($data['batch_id']){
			echo $patients->update_quantity($data);
		}
		redirect(base_url().'patients/register?id='.$patient_id);
	}

	public function register()
	{
		
		$batch_id = $this->input->post('batch_id');
		$quantity = $this->input->post('quantity');
		if(!empty($batch_id) && !empty($quantity)){
			
		}
		//echo $quantity; die;
		$data = array();
		$data['form'] = array();
		$data['pk_id'] = '';

		$patients = new patients_model();
		$rdt_list = new rdt_list_model();
		$lab_test_master = new lab_test_master_model();
		$patient_rdt_list = new patient_rdt_model();
		$location = new locations();
		$sample_collection = new sample_collection_types_model();
		$hr = new Hr_profile();
		$wh = new Warehouse();
		$ps = new Patient_status_model();
		$ba = new Patient_allocation_model();
		$vmodel = new Vitals_model();
		$medcines = new Product_model();
		$prescription = new Patient_prescription_model();
		$city = new Cities_model();
		$obj_wh_types = new Warehouse_types();
		$obj_stock_detail = new Stock_detail_model();
		$other_products = new Patient_other_products_model();

		// Users Default Value
		$data['form'] = array(
			'province' => 8,
			'district' => 78,
			'payment_method' => 1,
			'vaccination_status' => 1,
			'vaccine_name' => 1,
			'covid_status' => 1,
			'oxygen_status' => 1
		);

		$data['districts'] = $location->find_by_parent_id($data['form']['province'], 4);
		$data['tehsils'] = $location->find_by_parent_id($data['form']['district'], 5);

		if (isset($_GET['id']) && !empty($_GET['id']) && empty($_POST)) {
//                    echo 'hello'; exit;
			$id = $_GET['id'];
			$result = $patients->find_by_id($id);
//                       echo'<pre>'; print_r($patients); exit;

			foreach ($result->result_object() as $row) {
				$_POST['pk_id'] = $row->pk_id;
				$_POST['prefix'] = $row->prefix;
				$_POST['full_name'] = $row->full_name;
				$_POST['mrno'] = $row->mr_no;
				list($_POST['dob'][2], $_POST['dob'][1], $_POST['dob'][0]) = explode("-", $row->date_of_birth);
				$_POST['gender'] = $row->gender;
				$_POST['address'] = $row->address;
				$_POST['city'] = $row->city;
				$_POST['mobile_phone'] = $row->mobile_no;
				//$_POST['reg_fees'] = $row->payment;
				//$_POST['payment_method'] = $row->payment_method;
				$_POST['cnic'] = $row->nic_no;
				//$_POST['vaccination_status'] = $row->vaccination_status;
				//$_POST['last_dose_date'] = convert_date($row->last_dose_date,"toview");
				//$_POST['vaccine_name'] = $row->vaccine_name;
				//$_POST['covid_status'] = $row->covid_status;
				//$_POST['oxygen_status'] = $row->oxygen_status;
				$_POST['landline'] = $row->landline;
                                @$_POST['country'] = $row->country;
                                @$_POST['passport_no'] = $row->passport_no;
			}
		}

		if (isset($_POST) && !empty($_POST)) {
//                    echo 'ello'; exit;

			if (isset($_POST['pk_id']) && !empty($_POST['pk_id'])) {
				$patients->pk_id = $_POST['pk_id'];
			}
			$patients->prefix = $_POST['prefix'];
			$patients->full_name = $_POST['full_name'];
			$patients->mr_no = date("y") . "-" . get_mr_no_count();
			$patients->date_of_birth = $_POST['dob']['2'] . "-" . $_POST['dob']['1'] . "-" . $_POST['dob']['0'];
			//$patients->marital_status = $_POST['marital'];
			$patients->gender = $_POST['gender'];
			$rand_cnic = '14301-' . rand(1000000, 9999999) . '-' . ($_POST['gender'] === 'Male' ? '1' : '2');
			$patients->nic_no = (!empty($_POST['cnic']) ? $_POST['cnic'] : $rand_cnic);
			$patients->address = $_POST['address'];
			//$patients->city = $_POST['city'];
			$patients->province = 8;
			$patients->district = 78;
			// $patients->tehsil = $_POST['tehsil'];
			// $patients->uc = $_POST['uc'];
			// $patients->father_guardian_name = $_POST['father_guardian_name'];
			$patients->mobile_no = $_POST['mobile_phone'];
			$patients->is_nadra_verified = '1';
			//$patients->payment = $_POST['reg_fees'];
			//$patients->payment_method = $_POST['payment_method'];
			//$patients->vaccination_status = $_POST['vaccination_status'];
			//$patients->last_dose_date = convert_date($_POST['last_dose_date']);
			//$patients->vaccine_name = $_POST['vaccine_name'];
			//$patients->covid_status = $_POST['covid_status'];
			//$patients->oxygen_status = $_POST['oxygen_status'];
			$patients->status = 1;
			$patients->landline = $_POST['landline'];
			$patients->created_by = $_SESSION['id'];
			$patients->stakeholder_id = $_SESSION['stk_id'];
                        $patients->country = $_POST['country'];
                        $patients->passport_no = $_POST['passport_no'];

			//if($this->ignore_duplication()){
				$pk_id = $patients->save();
			//} else {
			//	echo "<script>alert('Duplicate entry found. Please use existing record!')</script>";
			//	redirect(base_url() . 'patients/register', 'refresh');
			//}
			

			$data['form'] = $_POST;
			$data['pk_id'] = $pk_id;

			//$data['districts'] = $location->find_by_parent_id($_POST['province'], 4);
			//$data['tehsils'] = $location->find_by_parent_id($_POST['district'], 5);
			//$data['ucs'] = $location->find_by_parent_id($_POST['tehsil'], 6);

			$data['rdt_list'] = $rdt_list->get_combo();
			//$data['lab_test'] = $lab_test_master->get_combo();
			$data['sample_type_list'] = $sample_collection->get_combo();

			$patient_rdt_list->patient_id = $pk_id;
			$data['patient_rdt'] = $patient_rdt_list->find_by_id();

			$ps->patient_id = $pk_id;
			$data['patient_status'] = $ps->find_by_id();
		}

		switch ($_SESSION['role']) {
			case 1:
				$viewpage = 'patients/register';
				break;
			case 2:
			case 8:
				$viewpage = 'patients/register_fd';
				break;
			case 3:
			case 5:
				$viewpage = 'patients/register_opd';
				break;
			case 4:
				$viewpage = 'patients/register_ipd';

				break;
			default:
				$viewpage = 'patients/register';
				break;
		}

		$data['consultant'] = $data['rooms'] = array();
		$data['page_title'] = 'Summary Form';
		$data['facilities'] = $wh->get_combo_by_stk();
		$data['types'] = $obj_wh_types->get_combo();
		$data['consultant'] = $hr->get_combo(159);
		$data['doctors'] = $hr->get_combo();
		$data['rooms'] = $wh->get_combo();
		$data['vitals_indicators'] = $vmodel->find_all();
		$data['lab_list'] = $wh->get_labs();
		$data['medicines'] = $medcines->get_warehouse_products();
		$data['nurses'] = $hr->get_combo1();
		$data['beds'] = $ba->get_combo();



		if (!empty($pk_id)) {
			$ba->patient_id = $pk_id;
			$data['patient_ba'] = $ba->find_by_id();

			$prescription->patient_id = $pk_id;
			$data['patient_prescription'] = $prescription->find_by_id();

			$lab_master = new patient_lab_master_model();
			$lab_master->patient_id = $pk_id;
			$data['patient_labtest'] = $lab_master->find_by_id();

			$ps->patient_id = $pk_id;
			$data['visit_codes'] = $ps->get_patient_visit_codes();

			$data['temp_records'] = $obj_stock_detail->get_issued_records($pk_id);

			$other_products->patient_id = $pk_id;
			$data['patient_op'] = $other_products->find_by_id();

			$pre_exam = new patient_preliminary_examination_model();
			$pre_exam->patient_id = $pk_id;
			$data['patient_preexam'] = $pre_exam->find_by_id();

			$cnotes = new Patient_clinical_notes_model();
			$cnotes->patient_id = $pk_id;
			$data['patient_cnote'] = $cnotes->find_by_id();
		}

		$data['cities'] = $city->get_combo();
		$wh_cat = new Warehouse_categories();
		$data['wh_category'] = $wh_cat->get_combo();
		$data['main_content'] = $this->load->view($viewpage, $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	public function check_duplicate()
	{

		$data = array();
		$text = $_POST['text'];
		$id = $_POST['id'];

		switch ($id) {
			case 'cnic':
				$id = 'nic_no';
				break;
			case 'mobile_phone':
				$id = 'mobile_no';
				break;
		}

		if (!empty($text)) {
			$this->db->select('*');
			$this->db->from('patients');
			$this->db->where($id, $text);
			//$this->db->where('created_by', $_SESSION['id']);
			$query = $this->db->get();
			//echo $this->db->last_query();
			//exit;
			if ($query->num_rows()) {
				$data = $query->result_array();
			}
		}

		$data['searched_data'] = $data;
		$this->load->view('patients/check_duplicate', $data);
	}

	public function ignore_duplication()
	{

		$data = array();
		$name = $_POST['name'];
		$cnic = $_POST['cnic'];

		if (!empty($text)) {
			$this->db->select('*');
			$this->db->from('patients');
			$this->db->where("full_name", $name);
			$this->db->where("nic_no", $cnic);
			$query = $this->db->get();
			//echo $this->db->last_query();
			//exit;
			if ($query->num_rows()) {
				return true;
			} else {
				return false;
			}
		}

		$data['searched_data'] = $data;
		$this->load->view('patients/ignore_duplication', $data);
	}

	public function import()
	{

		if (isset($_GET['id']) && !empty($_GET['id'])) {
			$id = $_GET['id'];
			$mrno = date("y") . "-" . get_mr_no_count();
			$qry = "INSERT INTO patients SELECT
				'',
				patients.prefix, 
				patients.full_name, 
				'" . $mrno . "',
				patients.date_of_birth, 
				patients.marital_status, 
				patients.gender, 
				patients.nic_no, 
				patients.address, 
				patients.city, 
				patients.province, 
				patients.district, 
				patients.tehsil, 
				patients.uc, 
				patients.father_guardian_name, 
				patients.mobile_no, 
				patients.payment, 
				patients.payment_method, 
				patients.`status`, 
				patients.is_nadra_verified, 
				NOW(), 
				" . $_SESSION['id'] . ",
				patients.vaccination_status, 
				patients.last_dose_date, 
				patients.vaccine_name, 
				patients.covid_status, 
				patients.oxygen_status, 
				patients.date_of_discharge, 
				patients.discharge_reason, 
				patients.discharge_notes
			FROM
				patients
				WHERE patients.pk_id = " . $id;
			$this->db->query($qry);
		}

		redirect(base_url() . 'patients/search', 'refresh');
	}

	public function ajax_add_rdt()
	{
		$rdt_list = new patient_rdt_model();
		$rdt_list->patient_id = $_POST['patient_id'];
		$rdt_list->rdt_id = $_POST['testname'];
		$rdt_list->result = $_POST['result'];
		$rdt_list->test_date = convert_date($_POST['test_date']);
		$rdt_list->result_date = convert_date($_POST['test_date']);
		$pk_id = $rdt_list->save();

		$data['data'] = $rdt_list->find_by_id();
		$this->load->view('patients/patient_rdt_table', $data);
	}

	public function ajax_del_rdt()
	{
		$rdt_list = new patient_rdt_model();
		$rdt_list->pk_id = $_POST['pk_id'];
		$pk_id = $rdt_list->delete();

		$rdt_list->patient_id = $_POST['p_id'];
		$data['data'] = $rdt_list->find_by_id();
		$this->load->view('patients/patient_rdt_table', $data);
	}

	public function ajax_add_otherproduct()
	{
		$rdt_list = new patient_other_products_model();
		$rdt_list->patient_id = $_POST['patient_id'];
		$rdt_list->visit_code = $_POST['visit_code'];
		$rdt_list->product_name = $_POST['product_name'];
		$rdt_list->quantity = $_POST['pres_qty'];
		$rdt_list->created_date = date("Y-m-d h:i:s");
		$rdt_list->created_by = $_SESSION['id'];
		$rdt_list->modified_date = date("Y-m-d h:i:s");
		$rdt_list->modified_by = $_SESSION['id'];
		$pk_id = $rdt_list->save();

		$data['patient_op'] = $rdt_list->find_by_id();
		$this->load->view('patients/patient_op_table', $data);
	}

	public function ajax_del_otherproduct()
	{
		$rdt_list = new patient_other_products_model();
		$rdt_list->pk_id = $_POST['pk_id'];
		$pk_id = $rdt_list->delete();

		$rdt_list->patient_id = $_POST['p_id'];
		$data['patient_op'] = $rdt_list->find_by_id();
		$this->load->view('patients/patient_op_table', $data);
	}

	public function ajax_add_preexam()
	{
		foreach ($_POST['vitals'] as $key => $value) {
			$pre_exam = new patient_preliminary_examination_model();
			$pre_exam->patient_id = $_POST['patient_id'];
			$pre_exam->examination_date = $_POST['visit_date'];
			$pre_exam->indicator_id = $key;
			$pre_exam->indicator_value = $value;
			$pre_exam->created_date = date("Y-m-d H:i:s");
			$pre_exam->created_by = $_SESSION['id'];
			$pre_exam->modified_date = date("Y-m-d H:i:s");
			$pre_exam->modified_by = $_SESSION['id'];
			$pk_id = $pre_exam->save();
		}

		$data['patient_preexam'] = $pre_exam->find_by_id();
		$this->load->view('patients/preexam_table', $data);
	}

	public function ajax_del_preexam()
	{
		$pre_exam = new patient_preliminary_examination_model();
		$pre_exam->pk_id = $_POST['pk_id'];
		$pk_id = $pre_exam->delete();

		$pre_exam->patient_id = $_POST['p_id'];
		$data['patient_preexam'] = $pre_exam->find_by_id();
		$this->load->view('patients/preexam_table', $data);
	}


	public function ajax_add_labtest()
	{
		$lab_master = new patient_lab_master_model();
		$patient = new Patients_model();
		$lab_master->patient_id = $_POST['patient_id'];
		$lab_master->patient_name = $patient->find_name_by_id($_POST['patient_id']);
		$lab_master->lab_test_master_id = $_POST['lab_test'];
		$lab_master->hf_id = $_POST['lab_list'];
		$lab_master->sample_collection_type_id = $_POST['sample_type'];
		$lab_master->sample_datetime = convert_date($_POST['sample_date']);
		$pk_id = $lab_master->save();

		//$lab_master->savealldata();

		$data['patient_labtest'] = $lab_master->find_by_id();
		$this->load->view('patients/lab_test_table', $data);
	}

	public function ajax_del_labtest()
	{
		$lab_master = new patient_lab_master_model();
		$lab_master->pk_id = $_POST['pk_id'];
		$pk_id = $lab_master->delete();

		$lab_master->patient_id = $_POST['p_id'];
		$data['patient_labtest'] = $lab_master->find_by_id();
		$this->load->view('patients/lab_test_table', $data);
	}

	public function patients_list()
	{
		$patient = new Patients_model();
		$data = array();
		$data['patients'] = $patient->find_all();
		$data['page_title'] = 'Add Products';
		$data['main_content'] = $this->load->view('patients/patients_list', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	public function ajax_add_cnote()
	{
		$cnotes = new patient_clinical_notes_model();
		$cnotes->patient_id = $_POST['patient_id'];
		$cnotes->checkup_date = $_POST['disease_date'];
		//$cnotes->hr_type_id = $_POST['hr_type_id'];
		$cnotes->hr_id = $_POST['hr_id'];
		$cnotes->notes = $_POST['notes'];
		$cnotes->diagnosis = $_POST['diagnosis'];
		$cnotes->created_date = date("Y-m-d H:i:s");
		$cnotes->created_by = 1;
		$cnotes->modified_date = date("Y-m-d H:i:s");
		$cnotes->modified_by = 1;
		$pk_id = $cnotes->save();

		$data['patient_cnote'] = $cnotes->find_by_id();
		$this->load->view('patients/patient_cnote_table', $data);
	}

	public function ajax_del_cnote()
	{
		$cnotes = new patient_clinical_notes_model();
		$cnotes->pk_id = $_POST['pk_id'];
		$pk_id = $cnotes->delete();

		$cnotes->patient_id = $_POST['p_id'];
		$data['patient_cnote'] = $cnotes->find_by_id();
		$this->load->view('patients/patient_cnote_table', $data);
	}

	public function ajax_add_prescription()
	{
		$prescription = new patient_prescription_model();
		$product = new Product_model();
		$prescription->patient_id = $_POST['patient_id'];
		$prescription->medicine_id = $_POST['medicine'];
		$prescription->medicine_name = $product->find_name_by_id($_POST['medicine']);
		$prescription->dose = $_POST['dose'];
		$prescription->strength = $_POST['strength'];
		$prescription->method = $_POST['method'];
		$prescription->days = $_POST['days'];
		$prescription->schedule = "Every " . $_POST['schedule_value'] . " " . $_POST['schedule_type'];
		$prescription->schedule_start_date = convert_date($_POST['start_date']);
		$prescription->created_date = date("Y-m-d H:i:s");
		$prescription->created_by = 1;
		$prescription->modified_by = 1;
		$prescription->modified_date = date("Y-m-d H:i:s");

		$pk_id = $prescription->save();

		$data['patient_prescription'] = $prescription->find_by_id();
		$this->load->view('patients/patient_prescription_table', $data);
	}

	public function ajax_del_prescription()
	{
		$prescription = new patient_prescription_model();
		$prescription->pk_id = $_POST['pk_id'];
		$pk_id = $prescription->delete();

		$prescription->patient_id = $_POST['p_id'];
		$data['patient_prescription'] = $prescription->find_by_id();
		$this->load->view('patients/patient_prescription_table', $data);
	}

	public function ajax_add_ipd()
	{
		$ipd = new patient_ipd_model();
		$ipd->patient_id = $_POST['patient_id'];
		$ipd->admission_date = convert_date($_POST['disease_date']);
		$ipd->ward_name = $_POST['ward'];
		$ipd->patient_condition = $_POST['pcondition'];
		$ipd->notes = $_POST['add_notes'];
		$ipd->created_date = date("Y-m-d H:i:s");
		$ipd->created_by = 1;
		$ipd->modified_date = date("Y-m-d H:i:s");
		$ipd->modified_by = 1;
		$pk_id = $ipd->save();

		$data['patient_ipd'] = $ipd->find_by_id();
		$this->load->view('patients/patient_ipd_table', $data);
	}

	public function ajax_add_ps()
	{
		$ipd = new patient_status_model();
		$hf = new Warehouse();
		$hr = new Hr_profile();
		$ipd->patient_id = $_POST['patient_id'];
		$ipd->visit_date = $_POST['visit_date'];
		$ipd->wh_id = $_POST['facility'];
		$ipd->wh_name = $hf->find_field_by_id($_POST['facility'], 'warehouse_name');
		//$ipd->consultant_id = $_POST['consultant'];
		//$ipd->consultant_name = $hr->find_field_by_id($_POST['consultant'], 'full_name');
		//$ipd->diagnosis = $_POST['diagnosis'];
		//$ipd->visit_fees = $_POST['visit_fees'];
		//$ipd->payment_method = $_POST['payment_method'];
		$ipd->notes = get_visit_no_count();
		$ipd->created_date = date("Y-m-d H:i:s");
		$ipd->created_by = $_SESSION['id'];
		$ipd->modified_date = date("Y-m-d H:i:s");
		$ipd->modified_by = $_SESSION['id'];
//                print_r($patient_id); exit;
//                $data['alp'] = $this->patients_model->check_appointment($ipd['patient_id'],$ipd['visit_date'],$ipd['wh_id']);
		$pk_id = $ipd->save();

		$data['patient_status'] = $ipd->find_by_id();
		$this->load->view('patients/patient_status_table_kp', $data);
	}

	public function ajax_add_discharge()
	{
		$pm = new Patients_model();
		$pm->pk_id = $_POST['patient_id'];
		$pm->date_of_discharge = convert_date($_POST['discharge_date']);
		$pm->discharge_reason = $_POST['discharge_id'];
		$pm->discharge_notes = $_POST['notes'];
		$pk_id = $pm->update_discharge();
		//$data['patient_status'] = $ipd->find_by_id();
		//$this->load->view('patients/patient_status_table', $data);
	}

	public function ajax_del_ps()
	{
		$ipd = new patient_status_model();
		$ipd->pk_id = $_POST['pk_id'];
		$pk_id = $ipd->delete();

		$ipd->patient_id = $_POST['p_id'];
		$data['patient_ipd'] = $ipd->find_by_id();
		$this->load->view('patients/patient_status_table', $data);
	}

	public function ajax_add_ba()
	{
		$ipd = new patient_allocation_model();
		$hf = new Warehouse();
		$hr = new Hr_profile();
		$ipd->patient_id = $_POST['patient_id'];
		$ipd->date = convert_date($_POST['disease_date']);
		$ipd->wh_id = $_SESSION['warehouse_id'];
		$ipd->wh_name = $hf->find_field_by_id($_SESSION['warehouse_id'], 'warehouse_name');
		$ipd->consultant_id = !empty($_POST['consultant']) ? $_POST['consultant'] : $_POST['consultant_id'];
		$ipd->consultant_name = $hr->find_field_by_id(!empty($_POST['consultant']) ? $_POST['consultant'] : $_POST['consultant_id'], 'full_name');
		$ipd->patient_condition = $_POST['pcondition'];
		$ipd->notes = $_POST['add_notes'];
		$ipd->created_date = date("Y-m-d H:i:s");
		$ipd->created_by = $_SESSION['id'];
		$ipd->modified_date = date("Y-m-d H:i:s");
		$ipd->modified_by = $_SESSION['id'];
		$ipd->nurse_id = $_POST['nurse_id'];
		$ipd->nurse_name = $hr->find_field_by_id($_POST['nurse_id'], 'full_name');
		$ipd->bed_no_allocated = $_POST['available_beds'];
		$pk_id = $ipd->save();

		$data['patient_ba'] = $ipd->find_by_id();
		$this->load->view('patients/patient_ba_table', $data);
	}

	public function ajax_del_ba()
	{

		$ipd = new patient_allocation_model();
		$ipd->pk_id = $_POST['pk_id'];
		$pk_id = $ipd->delete();

		$ipd->patient_id = $_POST['p_id'];
		$data['patient_ba'] = $ipd->find_by_id();
		$this->load->view('patients/patient_ba_table', $data);
	}

	public function ajax_del_ipd()
	{
		$ipd = new patient_ipd_model();
		$ipd->pk_id = $_POST['pk_id'];
		$pk_id = $ipd->delete();

		$ipd->patient_id = $_POST['p_id'];
		$data['patient_ipd'] = $ipd->find_by_id();
		$this->load->view('patients/patient_ipd_table', $data);
	}

	public function history()
	{
		$patient = new Patients_model();
		$rdt_list = new patient_rdt_model();
		$lab_master = new patient_lab_master_model();
		$pre_exam = new patient_preliminary_examination_model();
		$cnotes = new patient_clinical_notes_model();
		$prescription = new patient_prescription_model();

		$data = array();
		$patient_id = $_GET['p_id'];

		$rdt_list->patient_id = $patient_id;
		$data['data'] = $rdt_list->find_by_id();

		$lab_master->patient_id = $patient_id;
		$data['patient_labtest'] = $lab_master->find_by_id();

		$pre_exam->patient_id = $patient_id;
		$data['patient_preexam'] = $pre_exam->find_by_id();

		$cnotes->patient_id = $patient_id;
		$data['patient_cnote'] = $cnotes->find_by_id();

		$prescription->patient_id = $patient_id;
		$data['patient_prescription'] = $prescription->find_by_id();

		$data['patient'] = $patient->find_by_id($patient_id);

		$data['page_title'] = 'Patient History';
		$data['main_content'] = $this->load->view('patients/history', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	public function ajax_gen_token()
	{
		$dctr = $_POST['d_id'];
		switch ($dctr) {
			case 'Doctor1':
				$token = 6;
				$name = "Shamim Akhtar";
				break;
			case 'Doctor3':
				$token = 11;
				$name = "Ghulam Mustafa";
				break;
			default:
				$token = 1;
				$name = "Azhar Iqbal";
				break;
		}
		echo "<span style='font-size: 24px; font-weight: bold'>Token# $token with Dr. $name</span>";
	}

	public function ajax_get_hr()
	{
		$hr = new Hr_profile();
		$id = $_POST['id'];
		$data = $hr->get_combo1($id);

		echo create_combo('hr_id', $data);
	}

	public function ajax_get_labs()
	{
		$data = $this->db->query("SELECT facility_type_id FROM warehouses WHERE pk_id = " . $_POST['id']);
		$row = $data->result_array();
		$lab_test_master = new lab_test_master_model();
		$lab_test_master->department_id = $row[0]['facility_type_id'];
		$data = $lab_test_master->get_combo();

		echo create_combo("lab_test", $data);
	}

	public function fetch_combo()
	{
		$wh = new Warehouse();
		$id = $_POST['id'];
		$data = $wh->get_combo_by_category($id);

		echo create_combo('facility', $data);
	}
}
