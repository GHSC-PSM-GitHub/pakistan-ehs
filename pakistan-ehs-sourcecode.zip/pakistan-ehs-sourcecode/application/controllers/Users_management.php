<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Users_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('user');
        $this->load->model('locations');
        $this->load->model('warehouse');
        $this->obj = new User();
        $this->obj_location = new Locations();
        $this->obj_warehouse = new Warehouse();
    }

    public function index() {
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = 'Manage Users';
        $data['main_content'] = $this->load->view('users_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {

//        print_r($_POST);exit;
        if (!empty($_POST)) {
            if (isset($_POST['user_id'])) {
                $this->obj->pk_id = $_POST['user_id'];
            }
            $this->obj->username = $_POST['username'];
            $this->obj->designation = $_POST['designation'];
            $this->obj->login_id = $_POST['login_id'];
            if (isset($_POST['password']) && !empty($_POST['password'])) {
                $this->obj->password = md5($_POST['password']);
            }
            $this->obj->email = $_POST['email'];
            $this->obj->phone = $_POST['phone'];
            $this->obj->province_id = 8;
            $this->obj->district_id = 15;
            $this->obj->role_id = $_POST['role_id'];
            $this->obj->warehouse_id = $_POST['hf'];
            $this->obj->is_active = $_POST['status'];
            $this->obj->stakeholder_id = $_SESSION['stk_id'];
            $file = $this->obj->save();

            redirect(base_url() . 'users_management/index', 'refresh');
        } else {
            $province_id = 1;
            $lvl = 4;
            $result = $this->obj_location->find_by_parent_id($province_id, $lvl);
            $hf_arr = $this->obj_warehouse->find_active();
            $data['hf'] = !empty($hf_arr) ? $hf_arr->result_array() : array();
            $data['page_title'] = 'Add Users';
            $data['districts'] = $result;
            $data['main_content'] = $this->load->view('users_management/add_user', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function edit() {
        $user_id = $_REQUEST['userid'];
        $file = $this->obj->find_by_id($user_id);
        $districts = $this->obj_location->district_dropdown();
        $data['districts'] = $districts->result_array();
        $hf_arr = $this->obj_warehouse->find_active();
        $data['hf'] = $hf_arr->result_array();
        $data['result'] = $file->result_array();
        $data['user_id'] = $user_id;
        $data['page_title'] = 'Edit User';
        $data['main_content'] = $this->load->view('users_management/add_user', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function change_status() {

        $this->obj->pk_id = $_REQUEST['id'];
        $this->obj->is_active = $_REQUEST['status'];
        $file = $this->obj->is_active();
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = 'Manage Users';
        $data['main_content'] = $this->load->view('users_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function change_pass() {
        $user_id = $this->session->id;
        $file = $this->obj->find_by_id($user_id);
        $data['result'] = $file->result_array();
        $data['user_id'] = $user_id;
        $data['page_title'] = 'Edit User';
//        echo '<pre>';
//        print_r($data['result']);
//        echo '</pre>';
//        exit;
        $data['main_content'] = $this->load->view('users_management/change_pass', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function update_pass() {

//            print_r($_POST);exit;
        if (!empty($_POST)) {
            $user_id = $this->session->id;
            $file = $this->obj->find_by_id($user_id);
            $data['result'] = $file->result_array();

            if (md5($this->input->post('old_password')) == $data['result'][0]['password']){
                if (isset($_POST['user_id'])) {
                    $this->obj->pk_id = $_POST['user_id'];
                }
                if (isset($_POST['password']) && !empty($_POST['password']) && isset($_POST['password1']) && !empty($_POST['password1']) ) {
                    if ($_POST['password'] == $_POST['password1']) {
                        $this->obj->password = md5($_POST['password']);
                        $file = $this->obj->save();
                    }
                }
                else{
                    redirect(base_url() . 'users_management/change_pass', 'refresh');
                }
                redirect(base_url() . 'dashboard/index', 'refresh');
            }
            else{
                redirect(base_url() . 'users_management/change_pass', 'refresh');
            }
        }
    }

//    public function validate_old_password(){
//        $old_password = $this->input->post('old_password');
//
//        //user data
//        $user_id = $this->session->id;
//        $file = $this->obj->find_by_id($user_id);
//        $data['result'] = $file->result_array();
//
//        if (md5($old_password) == $data['result'][0]['password']){
//            echo 1;
//        }
//        else{
//            echo 0;
//        }
//    }
}
