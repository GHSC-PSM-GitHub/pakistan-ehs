<?php

class Vitals extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('vitals_model');
        $this->obj=new vitals_model();
        
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "Manage Vitals";
        $data['main_content'] = $this->load->view('vitals/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
 
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if (isset($_POST['id'])) {
                $this->obj->pk_id = $_POST['id'];
            }
            $this->obj->name = $_POST['name'];
            $this->obj->is_active = 1;
            $this->obj->save();
            redirect(base_url() . 'vitals/index', 'refresh');
        } 
        //$categories_arr = $this->obj_wh_categories->find_active();
        //$data['categories'] = $categories_arr->result_array();
        $data['page_title'] = "HF Categories";
        $data['main_content'] = $this->load->view('vitals/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        //$categories_arr = $this->obj_wh_categories->find_active();
        //$data['categories'] = $categories_arr->result_array();
        
        $data['result'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('vitals/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'vitals/index', 'refresh');
    }

}
