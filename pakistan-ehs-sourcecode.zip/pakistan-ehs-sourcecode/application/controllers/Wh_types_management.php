<?php

class Wh_types_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('warehouse_types');
        $this->load->model('warehouse_categories');
        $this->obj=new Warehouse_types();
        $this->obj_wh_categories=new Warehouse_categories();
        
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "HF Types";
        $data['main_content'] = $this->load->view('wh_types_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
 
        //pr($_POST);

        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if (isset($_POST['id'])) {
                $this->obj->pk_id = $_POST['id'];
            }
            $this->obj->type_name = $_POST['type_name'];
            $this->obj->category_id = $_POST['category'];
            $this->obj->category_name = $_POST['category_name'];
            $this->obj->is_active = 1;
            $this->obj->save();
            redirect(base_url() . 'wh_types_management/index', 'refresh');
        } 
        $categories_arr = $this->obj_wh_categories->find_active();
        $data['categories'] = $categories_arr->result_array();
        $data['page_title'] = "HF Categories";
        $data['main_content'] = $this->load->view('wh_types_management/add_wh_types', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit_wh_type() { 
        $data = array(); 
        $categories_arr = $this->obj_wh_categories->find_active();
        $data['categories'] = $categories_arr->result_array();
        
        $data['result'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('wh_types_management/add_wh_types', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate_wh_type() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'wh_types_management/index', 'refresh');
    }

}
