<?php

class Masterdata_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('externalsystems');
        $this->load->model('masterdata');
        $this->obj=new Masterdata();
        $this->obj_ext_systems=new Externalsystems();
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "MDM";
        $data['main_content'] = $this->load->view('masterdata_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add_mdm() { 
        $data = array();
        if (isset($_POST) && !empty($_POST)) { 
            $this->obj->external_system_id = $_POST['ext_system'];
            $this->obj->entity_type = $_POST['type'];
            $this->obj->entity_pk = $_POST['id'];
            $this->obj->external_pk = $_POST['external_pk']; 
            $this->obj->external_entity_name = $_POST['external_name']; 
            $this->obj->save(); 
            redirect(base_url() . 'masterdata_management/index', 'refresh');
        } 
        $data['ext_systems']=$this->obj_ext_systems->find_active();
        $data['page_title'] = "Add MDM";
        $data['main_content'] = $this->load->view('masterdata_management/add_mdm', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
 

}
