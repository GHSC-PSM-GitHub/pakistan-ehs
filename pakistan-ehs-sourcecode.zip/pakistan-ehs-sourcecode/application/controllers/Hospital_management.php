<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hospital_management extends CI_Controller {

	public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('hospital_management_model');
        $this->load->model('user');
        $this->load->model('warehouse');
        $this->load->model('hr_types');
        $this->obj=new Hospital_management_model();
        $this->obj_user=new User();
        $this->obj_warehouse = new Warehouse();
        
    }
    
    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "Hospital Management";
        $data['main_content'] = $this->load->view('hospital_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if(isset($_POST['id'])){
                $this->obj->pk_id = $_POST['id'];
            }

            if(!empty($_FILES["logo"]["name"])){
                $logo_name = $this->fileupload($_FILES["logo"]);
                $this->obj->logo = $logo_name;
            }
            if(!empty($_FILES["background_image"]["name"])){
                $background_image_name = $this->fileupload($_FILES["background_image"]);
                $this->obj->background_image = $background_image_name;
            }
             
            $this->obj->stakeholder_name = $_POST['stakeholder_name'];
            $this->obj->extra_css = $_POST['extra_css'];
            $this->obj->code = $_POST['code'];
            $this->obj->url = $_POST['code'];
            $this->obj->is_active = 1;            
            $insert_id = $this->obj->save();

            if(empty($_POST['id'])) {
                $insert_user = array(
                    "username" => "Administrator",
                    "designation" => "Administrator",
                    "login_id" => $_POST['code']."_admin",
                    "password" => MD5($_POST['code']."123"),
                    "email" => "support@lmis.gov.pk",
                    "phone" => "03339652360",
                    "landing_page" => 1,
                    "role_id" => 1,
                    "is_active" => 1,
                    "district_id" => "",
                    "province_id" => "",
                    "warehouse_id" => "",
                    "stakeholder_id" => $insert_id,
                    "created_by" => 1,
                    "modified_by" => 1
                );
                $this->db->insert("users", $insert_user);
            }

            redirect(base_url() . 'hospital_management/index', 'refresh');
        }
        //$user_arr = $this->obj_user->find_all();
        //$data['users'] = $user_arr->result_array();
        //$data['hr_types'] = $hr_types->get_combo();
        //$hf_arr = $this->obj_warehouse->find_active();
        //$data['hf'] = $hf_arr->result_array();
//        exit;
        $data['page_title'] = "Hospital Management";
        $data['main_content'] = $this->load->view('hospital_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function fileupload($file){
        $target_dir = "assets/images/";
        $target_file = $target_dir . basename($file["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        // Check if image file is a actual image or fake image
        $check = getimagesize($file["tmp_name"]);
        if($check !== false) {
            //echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }

        // Check if file already exists
        if (file_exists($target_file)) {
        //echo "Sorry, file already exists.";
        $uploadOk = 0;
        }

        // Check file size
        if ($file["size"] > 500000) {
        //echo "Sorry, your file is too large.";
        $uploadOk = 0;
        }

        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
        //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        //if ($uploadOk == 0) {
       // echo "Sorry, your file was not uploaded.";
        //return false;
        // if everything is ok, try to upload file
        //} else {
        if (move_uploaded_file($file["tmp_name"], $target_file)) {
           // echo "The file ". htmlspecialchars( basename( $file["name"])). " has been uploaded.";
            return $file["name"];
        } else {
            //echo "Sorry, there was an error uploading your file.";
            return false;
        }
       // }
    }

    public function edit() { 
        $hr_types = new Hr_types();
        $data = array(); 
        $user_arr = $this->obj_user->find_all();
        $data['users'] = $user_arr->result_array();
        $data['hr_types'] = $hr_types->get_combo();
        $hf_arr = $this->obj_warehouse->find_active();
        $data['hf'] = $hf_arr->result_array();
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('hospital_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'hospital_management/index', 'refresh');
    }

}
