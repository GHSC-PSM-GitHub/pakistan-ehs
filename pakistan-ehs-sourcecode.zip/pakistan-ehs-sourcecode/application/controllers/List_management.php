<?php

class List_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('list_detail');
        $this->load->model('warehouse');
        $this->obj=new List_detail();
    }

    public function index() {
        $data = array();
        $master_id = $this->uri->segment(3);
        $data['result'] = $this->obj->find_all($master_id);
        $data['master_id'] = $master_id;
        $data['page_title'] = $this->obj->find_master_name_by_id($master_id);
        $data['main_content'] = $this->load->view('list_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $master_id = $this->uri->segment(3);

        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if(isset($_POST['id'])){
                $this->obj->pk_id = $_POST['id'];
                $this->obj->created_by = $_SESSION['id'];
            } else {
                $this->obj->modified_by = $_SESSION['id'];
            }
             
            $this->obj->list_value = $_POST['list_value'];
            $this->obj->description = $_POST['list_value'];
            $this->obj->rank = $_POST['rank'];
            if(isset($_POST['parent_id']) && !empty($_POST['parent_id'])){
                $this->obj->parent_id = $_POST['parent_id'];
            }
            $this->obj->is_active = 1;         
            $this->obj->list_master_id = $master_id;
            
            
            $this->obj->save();
            redirect(base_url() . 'list_management/index/'.$master_id, 'refresh');
        }

        $wh = new Warehouse();
        $data['lab_list'] = $wh->get_labs();
        $data['page_title'] = "Add ".$this->obj->find_master_name_by_id($master_id);
        $data['master_id'] = $master_id;
        $data['main_content'] = $this->load->view('list_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() {
        $master_id = $this->uri->segment(3);
        $id = $this->uri->segment(4);
        $data = array(); 
        $data['page_title'] = "Edit ". $this->obj->find_master_name_by_id($master_id);
        $data['master_id'] = $master_id;
        $data['id'] = $id;
        $data['result_edit'] = $this->obj->find_by_id($id);
        $data['main_content'] = $this->load->view('list_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $master_id = $this->uri->segment(3);
        $id = $this->uri->segment(4);
        $status = $this->uri->segment(5);
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'list_management/index/'.$master_id , 'refresh');
    }

}
