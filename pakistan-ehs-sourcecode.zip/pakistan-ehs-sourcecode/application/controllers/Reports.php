<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Reports extends CI_Controller
{

        public function __construct()
        {
                parent::__construct();
                check_login_user();
                $this->load->model('Reports_model');
                $this->load->model('Product_model');
                $this->load->model("Warehouse_data");
                $this->load->model('Stock_detail_model');
                $this->load->model('Stock_master_model');
                $this->obj = new Reports_model();
                $this->obj_product = new Product_model();
                $this->obj_stock_master = new Stock_master_model();
                $this->obj_stock_detail = new Stock_detail_model();
                // $this->obj_warehouse = new Warehouse();
                // $this->obj_patient = new Patients_model();
                // $this->obj_lists = new Lists();
        }


        public function index()
        {
                $this->load->view("reports/index", "");
        }

        public function issuance()
        {
                $result = $this->obj->fetch_issuance();
                if (!empty($result)) {
                        $data['list'] = $result;
                }
                $data['page_title'] = 'Report Title';
                $data['main_content'] = $this->load->view('reports/issuance', $data, TRUE);
                $this->load->view('layout/main', $data);
        }
        public function issuance_list()
        {
                $result = $this->obj->fetch_issuance_list();
                if (!empty($result)) {
                        $data['list'] = $result;
                }
                $product_arr = $this->obj_product->get_warehouse_products();
                if ($product_arr) {
                        $data['product'] = $product_arr->result_array();
                }
                $data['page_title'] = 'Report Title';
                $data['main_content'] = $this->load->view('reports/issuance_list', $data, TRUE);
                $this->load->view('layout/main', $data);
        }
        public function receive()
        {
                $result = $this->obj->fetch_receive();
                if (!empty($result)) {
                        $data['list'] = $result;
                }
                $data['page_title'] = 'Report Title';
                $data['main_content'] = $this->load->view('reports/receive', $data, TRUE);
                $this->load->view('layout/main', $data);
        }

        public function receive_list()
        {
                $result = $this->obj->fetch_receive_list();
                if (!empty($result)) {
                        $data['list'] = $result;
                }
                $product_arr = $this->obj_product->get_warehouse_products();
                if ($product_arr) {
                        $data['product'] = $product_arr->result_array();
                }

                $data['page_title'] = 'Report Title';
                $data['main_content'] = $this->load->view('reports/receive_list', $data, TRUE);
                $this->load->view('layout/main', $data);
        }
        public function raw_data_report()
        {
                //ware house pk_id
                //trans_id trans_id
                //from date
                //to date
                //$formArray['received_from'] = $this->input->post('received_from');
                //$formArray['tran_type'] = $this->input->post('tran_type');

                if (!empty($this->input->post('from_date'))) {
                        $from_date = $this->input->post('from_date');
                } else {
                        $from_date = date("01/01/2021");
                }

                if (!empty($this->input->post('to_date'))) {
                        $to_date = $this->input->post('to_date');
                } else {
                        $to_date = date("m/t/Y");
                }

                //echo $from_date;
                //echo $to_date;

                $formArray['from_date'] =  $from_date;
                $formArray['to_date'] =  $to_date;
                $result = $this->obj->fetch_raw_data_report($formArray);
                if (!empty($result)) {
                        $data['list'] = $result;
                        array_unshift($data['list'],array("batch_number","batch_expiry","product_name","generic_name","strength","method_type","manufacturer","prescribed_quantity","quantity","transaction_date","transaction_reference","trans_type","trans_nature","from_wh","to_wh","cnic","mr_no","remarks","username","designation","email","phone","hospital"));
                }                

                $product_arr = $this->obj_product->get_warehouse_products();

                if ($product_arr) {
                        $data['product'] = $product_arr->result_array();
                }
                $suppliers_arr = $this->obj_stock_master->fetch_suppliers();

                if ($suppliers_arr)
                        $data['suppliers'] = $suppliers_arr->result_array();

                $tran_arr = $this->obj_product->get_all_tran_types();
                if ($product_arr)
                        $data['product'] = $product_arr->result_array();
                if ($tran_arr)
                        $data['trans'] = $tran_arr->result_array();
                $data['tran'] = $this->input->post('tran_type');
                $data['params'] = $formArray;
                $data['page_title'] = 'Report Title';
                $this->load->view('reports/raw_data_report', $data);
                //$this->load->view('layout/main', $data);
        }

        public function trans_list()
        {
                $result = $this->obj->fetch_all_trans();
                if (!empty($result)) {
                        $data['list'] = $result;
                }
                $data['page_title'] = 'Transactions List';
                $data['main_content'] = $this->load->view('reports/trans_list', $data, TRUE);
                $this->load->view('layout/main', $data);
        }
        public function soh()
        {
                //            echo '<pre>';
                //            print_r($_SESSION);
                //            echo '</pre>';
                //            exit; 
                $result = $this->obj->fetch_soh();
                if (!empty($result)) {
                        $data['list'] = $result;
                }
                $product_arr = $this->obj_product->get_warehouse_products();
                if ($product_arr) {
                        $data['product'] = $product_arr->result_array();
                }

                $data['page_title'] = 'Report Title';
                $data['main_content'] = $this->load->view('reports/soh', $data, TRUE);
                $this->load->view('layout/main', $data);
        }

        public function soh2()
        {
                //            echo '<pre>';
                //            print_r($_SESSION);
                //            echo '</pre>';
                //            exit; 
                $result = $this->obj->fetch_soh();
                if (!empty($result)) {
                        $data['list'] = $result;
                }
                $product_arr = $this->obj_product->get_warehouse_products();
                if ($product_arr) {
                        $data['product'] = $product_arr->result_array();
                }

                $data['page_title'] = 'Report Title';
                $data['main_content'] = $this->load->view('reports/soh', $data, TRUE);
                $this->load->view('layout/main', $data);
        }

        public function batch_history($batch_id)
        {

                $result = $this->obj->fetch_batch_history($batch_id);
                if (!empty($result)) {
                        $data['list'] = $result;
                }
                $data['page_title'] = 'Batch Details';
                $data['main_content'] = $this->load->view('reports/batch_history', $data, TRUE);
                $this->load->view('layout/main', $data);
        }
        public function transaction_detail($id)
        {

                $result = $this->obj->fetch_transaction_detail($id);
                if (!empty($result)) {
                        $data['list'] = $result;
                }
                $data['page_title'] = 'Transaction= Details';
                $data['main_content'] = $this->load->view('reports/transaction_detail', $data, TRUE);
                $this->load->view('layout/main', $data);
        }

        public function stock_ledger()
        {

                if (isset($_POST['product']) && !empty($_POST['product'])) {
                        $product_id = $_POST['product'];
                } else {
                        $product_id = 4;
                }
                $result = $this->obj->stock_ledger($product_id);
                if (!empty($result)) {
                        $data['list'] = $result;
                }

                $product_arr = $this->obj_product->get_warehouse_products();
                if ($product_arr) {
                        $data['product'] = $product_arr->result_array();
                }

                /*$tran_arr = $this->obj_product->get_tran_types();
                if ($tran_arr)
                        $data['trans'] = $tran_arr->result_array();
                $data['tran'] = $this->input->post('tran_type');*/

                $data['page_title'] = 'Stock Ledger';
                $data['main_content'] = $this->load->view('reports/stock_ledger', $data, TRUE);
                $this->load->view('layout/main', $data);
        }

        public function pivot()
        {
                $data['page_title'] = 'Pivot';
                $data['main_content'] = $this->load->view('reports/pivot', $data, TRUE);
                $this->load->view('layout/main', $data);
        }

        public function explorer()
        {


                $product_arr = $this->obj_product->get_all_products();
                if ($product_arr) {
                        $data['product'] = $product_arr->result_array();
                }

                $wh = new Warehouse_data();
                $result = $wh->find_all($_POST);
                if (!empty($result)) {
                        $data['list'] = $result;
                }



                $data['page_title'] = 'LMIS Explorer';
                $data['main_content'] = $this->load->view('reports/explorer', $data, TRUE);
                $this->load->view('layout/main', $data);
        }
        
          public function entry_report() {
              
              $data['report'] = $this->Reports_model->fetch_daily(); 
                       
//               echo '<pre>';
//               print_r($data['report']);
//               exit;
                
                $data['page_title'] = 'Daily Entry Report';
                $data['main_content'] = $this->load->view('reports/entry_report', $data, TRUE);
                $this->load->view('layout/main', $data);
        }
        
            public function stock_detail() {
                
        if (!empty($this->input->post('from_date'))) {
            $from_date = $this->input->post('from_date');
        } else {
            $from_date = date("Y-m-d", strtotime('-2 month'));
        }
        if (!empty($this->input->post('to_date'))) {
            $to_date = $this->input->post('to_date');
        } else {
            $to_date = date("Y-m-d");
        }  
        $data['from_date'] = $from_date;
        $data['to_date'] = $to_date;
        $data['detail'] = $this->Reports_model->stock_detail($from_date,$to_date);
        $product_arr = $this->obj_product->get_warehouse_products();
        if ($product_arr) {
            $data['product'] = $product_arr->result_array();
        }             
        $data['page_title'] = 'Stock Report';
        $data['main_content'] = $this->load->view('reports/stock_detail', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function batch_report() {
        if (isset($_POST['product']) && !empty($_POST['product'])) {
            $product_id = $_POST['product'];
        } else {
            $product_id = 4;
        }
        if (!empty($this->input->post('from_date'))) {
            $from_date = $this->input->post('from_date');
        } else {
            $from_date = date("Y-m-d", strtotime('-2 month'));
        }
        if (!empty($this->input->post('to_date'))) {
            $to_date = $this->input->post('to_date');
        } else {
            $to_date = date("Y-m-d");
        }
        $data['from_date'] = $from_date;
        $data['to_date'] = $to_date;
//        echo $from_date; exit;
        $result = $this->obj->batch_report($product_id,$from_date,$to_date);
        if (!empty($result)) {
            $data['list'] = $result;
        }
        $product_arr = $this->obj_product->get_warehouse_products();
        if ($product_arr) {
            $data['product'] = $product_arr->result_array();
        }
        $data['page_title'] = 'Batch Report';
        $data['main_content'] = $this->load->view('reports/batch_report', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

}
