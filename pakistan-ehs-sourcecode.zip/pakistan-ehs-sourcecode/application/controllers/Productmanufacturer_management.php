<?php

class Productmanufacturer_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('product_manufacturer');
        $this->obj=new Product_manufacturer();
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "Manufacturer";
        $data['main_content'] = $this->load->view('productmanufacturer_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if(isset($_POST['id'])){
                $this->obj->pk_id = $_POST['id'];
            }
             
            $this->obj->manufacturer = $_POST['manufacturer'];
            $this->obj->is_active = 1;
            $this->obj->save(); 
            redirect(base_url() . 'productmanufacturer_management/index', 'refresh');
        }
//        exit;
        $data['page_title'] = "Manufacturer";
        $data['main_content'] = $this->load->view('productmanufacturer_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('productmanufacturer_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'productmanufacturer_management/index', 'refresh');
    }

}
