<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Lab_tests_management extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        check_login_user();
        $this->load->model('lab_test_master_model');
        $this->load->model('lab_test_detail_model');
        $this->load->model('locations');
        $this->load->model('lab_types_model');
        //$this->load->model('warehouse');
    }

    public function index()
    {
        $doc = new Lab_test_master_model();
        $data = array();
        $data['result_all'] = $doc->find_all();

        //--------Cols to display in View -----------
        $cols_to_display = array();   //key is Display text, value is the actual field name in db
        $cols_to_display['Test Code'] = 'code';
        $cols_to_display['Test Name'] = 'name';
        $cols_to_display['Description'] = 'description';
        $data['cols_to_display'] = $cols_to_display;

        $data['result'] = array();
        foreach ($data['result_all'] as $k => $arr_val) {
            $data['result'][$k]['pk_id'] = $arr_val['pk_id'];
            foreach ($arr_val as $key => $val) {
                if (in_array($key, $cols_to_display)) {
                    $data['result'][$k][$key] = $val;
                }
            }
        }
        //--------Cols to display in View -----END------

        $data['page_title'] = 'Manage Lab Tests';
        $data['main_content'] = $this->load->view('lab_tests_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add()
    {

        $obj = new Lab_test_master_model();
        $obj_lab_type = new Lab_types_model();
        
        // print_r($_POST);exit;
        $province_id = 1;
        $lvl = 4;
        $districts = new Locations();

        $result = $districts->find_by_parent_id($province_id, $lvl);
        $data['page_title'] = 'Add New';
        $data['districts'] = $result;
        
        //$data['lab_types'] = $obj_lab_type->get_combo();
        $data['main_content'] = $this->load->view('lab_tests_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function create_master()
    {

        $obj = new Lab_test_master_model();
        //print_r($_POST);exit;
        if (!empty($_POST)) {

            $obj->code = $_POST['code'];
            $obj->name = $_POST['name'];
            $obj->description = $_POST['description'];
            $obj->comments = $_POST['comments'];
            $obj->department_id = $_POST['lab_type_id'];
            if ($_POST['update'] == 'yes' && $_POST['update']) {
                $obj->pk_id = $_POST['master_id'];
                $new_id = $obj->update();
            } else {
                $new_id = $obj->save();
            }

            redirect(base_url() . 'lab_tests_management/edit/' . $new_id, 'refresh');
        } else {
            echo 'No Data To Save';
        }
    }

    public function create_list_item()
    {

        $obj = new Lab_test_detail_model();
        //        print_r($_POST);exit;
        if (!empty($_POST)) {

            $obj->lab_test_master_id = $_POST['master_id'];
            $obj->test_name         = $_POST['test_name'];
            $obj->unit              = $_POST['unit'];
            $obj->sample_type_id    = $_POST['sample_type_id'];

            $obj->ref_range_min_general = $_POST['ref_g_min'];
            $obj->ref_range_max_general = $_POST['ref_g_max'];

            $obj->ref_range_min_male = $_POST['ref_m_min'];
            $obj->ref_range_max_male = $_POST['ref_m_max'];

            $obj->ref_range_min_female = $_POST['ref_f_min'];
            $obj->ref_range_max_female = $_POST['ref_f_max'];

            if ($_POST['update'] == 'yes' && $_POST['update']) {

                $obj->pk_id = $_POST['detail_id'];
                $new_id = $obj->update();
            } else {
                $new_id = $obj->save();
            }

            redirect(base_url() . 'lab_tests_management/edit/' . $_POST['master_id'], 'refresh');
        } else {
            echo 'No Data To Save';
        }
    }

    public function edit($master_id, $detail_id = '')
    {
        $obj        = new Lab_test_master_model();
        $obj_detail = new Lab_test_detail_model();
        $obj_lab_type = new Lab_types_model();

        $this_data  = $obj->find_by_id($master_id);
        $data['result']     = $this_data->result_array()[0];

        if (!empty($detail_id)) {
            $this_detail_data        = $obj_detail->find_by_id($detail_id);
            $data['detail_data']     = $this_detail_data->result_array()[0];
        }


        $list_items             = $obj_detail->get_items_of($master_id);
        if ($list_items != FALSE) {
            $data['list_items']     = $list_items->result_array();
        }
        //        echo '<pre>';
        //        print_r($data['list_items']);
        //        print_r($data['detail_data']);
        //        echo '</pre>';
        //        exit;
        $data['lab_types'] = $obj_lab_type->get_combo();
        $data['page_title'] = 'Edit User';
        $data['main_content']   = $this->load->view('lab_tests_management/edit', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function change_status()
    {

        $obj = new Lab_test_master_model();
        $obj->pk_id = $_REQUEST['id'];
        $obj->is_active = $_REQUEST['status'];
        $file = $obj->is_active();
        $data = array();
        $data['result'] = $obj->find_all();
        $data['page_title'] = 'Manage Users';
        $data['main_content'] = $this->load->view('lab_tests_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
}
