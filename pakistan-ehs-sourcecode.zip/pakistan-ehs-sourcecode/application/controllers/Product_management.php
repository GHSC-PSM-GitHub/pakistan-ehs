<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Product_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('Product_model');
        $this->load->model('Product_category');
        $this->load->model('Product_subcategory');
        $this->load->model('Product_generic');
        $this->load->model('Product_manufacturer');
        $this->load->model('Product_methodtype');
        $this->load->model('Product_strength');
        $this->load->model('Product_contradicts');
        $this->obj = new Product_model();
        $this->obj_category = new Product_category();
        $this->obj_subcategory = new Product_subcategory();
        $this->obj_manufacturer = new Product_manufacturer();
        $this->obj_methodtype = new Product_methodtype();
        $this->obj_strength = new Product_strength();
        $this->obj_generic = new Product_generic();
        $this->obj_contradict = new Product_contradicts();
    }

    public function index() { 

        $data = array();
        $data['result'] = $this->obj->find_by_stk();


        $data['page_title'] = 'Manage Items';
        $data['main_content'] = $this->load->view('product_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function brand() { 

        $data = array();
        $data['result'] = $this->obj->find_by_stk();


        $data['page_title'] = 'Manage Items';
        $data['main_content'] = $this->load->view('product_management/brand', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function addbrand() {


        if (!empty($_POST)) {
//             print_r($_POST);exit;
            if (isset($_POST['pk_id'])) {
                $this->obj->pk_id = $_POST['pk_id'];
            }
            $this->obj->product_name = $_POST['product_name'];
            $this->obj->generic_name = $_POST['generic_name'];
            $this->obj->generic_name_id = $_POST['generic_name_id'];
            $this->obj->strength = $_POST['strength'];
            $this->obj->strength_id = $_POST['strength_id'];
            $this->obj->method_type = $_POST['method_type'];
            $this->obj->method_type_id = $_POST['method_type_id'];
            $this->obj->manufacturer = $_POST['manufacturer'];
            $this->obj->manufacturer_id = $_POST['manufacturer_id'];
            $this->obj->category = $_POST['category'];
            $this->obj->category_id = $_POST['category_id'];
            $this->obj->sub_category = $_POST['sub_category'];
            $this->obj->sub_category_id = $_POST['sub_category_id'];
            $this->obj->registration_number = $_POST['registration_number'];
            $this->obj->barcode = $_POST['barcode'];
            $this->obj->gtin = $_POST['gtin'];
            $this->obj->description = $_POST['description'];
            $this->obj->products_in_packet = $_POST['products_packet'];
            $this->obj->packet_in_cartons = $_POST['packets_carton'];
            $this->obj->status = 1;
            $this->obj->save();

            redirect(base_url() . 'product_management/brand', 'refresh');
        } else {
            $cat_arr = $this->obj_category->find_active();
            $data['category'] = (!empty($cat_arr) ? $cat_arr->result_array() : array());

            $subcat_arr = $this->obj_subcategory->find_active();
            $data['sub_category'] = (!empty($subcat_arr) ? $subcat_arr->result_array() : array());

            $generic_arr = $this->obj_generic->find_active();
            $data['generic_combo'] = $this->obj_generic->get_combo();
            $data['generic'] = (!empty($generic_arr) ? $generic_arr->result_array() : array());

            $manuf_arr = $this->obj_manufacturer->find_active();
            $data['manufacturer'] = (!empty($manuf_arr) ? $manuf_arr->result_array() : array());

            $strength_arr = $this->obj_strength->find_active();
            $data['strength'] = (!empty($strength_arr) ? $strength_arr->result_array() : array());

            $methodtype_arr = $this->obj_methodtype->find_active();
            $data['method_type'] = (!empty($methodtype_arr) ? $methodtype_arr->result_array() : array());

            $data['page_title'] = 'Add New';
            $data['main_content'] = $this->load->view('product_management/addbrand', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function add() {


        if (!empty($_POST)) {
//             print_r($_POST);exit;
            if (isset($_POST['pk_id'])) {
                $this->obj->pk_id = $_POST['pk_id'];
            }
            $this->obj->product_name = $_POST['product_name'];
            $this->obj->generic_name = $_POST['generic_name'];
            $this->obj->generic_name_id = $_POST['generic_name_id'];
            $this->obj->strength = $_POST['strength'];
            $this->obj->strength_id = $_POST['strength_id'];
            $this->obj->method_type = $_POST['method_type'];
            $this->obj->method_type_id = $_POST['method_type_id'];
            $this->obj->manufacturer = $_POST['manufacturer'];
            $this->obj->manufacturer_id = $_POST['manufacturer_id'];
            $this->obj->category = $_POST['category'];
            $this->obj->category_id = $_POST['category_id'];
            $this->obj->sub_category = $_POST['sub_category'];
            $this->obj->sub_category_id = $_POST['sub_category_id'];
            $this->obj->registration_number = $_POST['registration_number'];
            $this->obj->barcode = $_POST['barcode'];
            $this->obj->gtin = $_POST['gtin'];
            $this->obj->description = $_POST['description'];
            $this->obj->products_in_packet = $_POST['products_packet'];
            $this->obj->packet_in_cartons = $_POST['packets_carton'];
            $this->obj->status = 1;
            $this->obj->save();

            redirect(base_url() . 'product_management/index', 'refresh');
        } else {
            $cat_arr = $this->obj_category->find_active();
            $data['category'] = (!empty($cat_arr) ? $cat_arr->result_array() : array());

            $subcat_arr = $this->obj_subcategory->find_active();
            $data['sub_category'] = (!empty($subcat_arr) ? $subcat_arr->result_array() : array());

            $generic_arr = $this->obj_generic->find_active();
            $data['generic_combo'] = $this->obj_generic->get_combo();
            $data['generic'] = (!empty($generic_arr) ? $generic_arr->result_array() : array());

            $manuf_arr = $this->obj_manufacturer->find_active();
            $data['manufacturer'] = (!empty($manuf_arr) ? $manuf_arr->result_array() : array());

            $strength_arr = $this->obj_strength->find_active();
            $data['strength'] = (!empty($strength_arr) ? $strength_arr->result_array() : array());

            $methodtype_arr = $this->obj_methodtype->find_active();
            $data['method_type'] = (!empty($methodtype_arr) ? $methodtype_arr->result_array() : array());

            $data['page_title'] = 'Add New';
            $data['main_content'] = $this->load->view('product_management/add_product', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function edit() {
        $data = array();
        $cat_arr = $this->obj_category->find_active();
            $data['category'] = (!empty($cat_arr) ? $cat_arr->result_array() : array());

            $subcat_arr = $this->obj_subcategory->find_active();
            $data['sub_category'] = (!empty($subcat_arr) ? $subcat_arr->result_array() : array());

            $generic_arr = $this->obj_generic->find_active();
            $data['generic_combo'] = $this->obj_generic->get_combo();
            $data['generic'] = (!empty($generic_arr) ? $generic_arr->result_array() : array());

            $manuf_arr = $this->obj_manufacturer->find_active();
            $data['manufacturer'] = (!empty($manuf_arr) ? $manuf_arr->result_array() : array());

            $strength_arr = $this->obj_strength->find_active();
            $data['strength'] = (!empty($strength_arr) ? $strength_arr->result_array() : array());

            $methodtype_arr = $this->obj_methodtype->find_active();
            $data['method_type'] = (!empty($methodtype_arr) ? $methodtype_arr->result_array() : array());
            
        $data['js'] = array("product_management/add");
        $data['page_title'] = 'Edit';
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('product_management/addbrand', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() {
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'product_management/index', 'refresh');
    }

    public function assign(){

        if (isset($_POST) && !empty($_POST)) {
            $products = $_POST['products'];
            if(count($products) > 0){
                $this->db->delete('stakeholder_products', array('stakeholder_id'=> $_SESSION['stk_id']));
                foreach($products as $id=>$name){
                    $data = array(
                        'product_id' => $id,
                        'stakeholder_id' => $_SESSION['stk_id'],
                        'created_by' => $_SESSION['id'],
                        'created_date' => date("Y-m-d"),
                        'modified_by' => $_SESSION['id']
                    );
                    try {
                        $this->db->insert('stakeholder_products',$data);
                    } catch (\Throwable $th) {
                        continue;
                    }
                    
                }
            }
            
        }
        $data = array();
        $data['page_title'] = 'Assign Products';
        $data['result'] = $this->obj->find_all();
        $data['selected'] = $this->obj->find_by_stk();
        $data['main_content'] = $this->load->view('product_management/assign', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function unassign(){
        $p_id = $_GET['id'];

        $data = array(
            'product_id' => $p_id,
            'stakeholder_id' => $_SESSION['stk_id']
        );
        $this->db->delete('stakeholder_products', $data);
        
        redirect(base_url() . 'product_management/index', 'refresh');
    }

    public function contradictory_products() {

        if (isset($_POST) && !empty($_POST)) {
//            print_r($_POST);exit;
            foreach ($_POST['generic_contradictory_id'] as $key => $value) {
                $this->obj_contradict->generic_name = $_POST['generic_name'];
                $this->obj_contradict->generic_name_id = $_POST['generic_name_id'];
                $this->obj_contradict->contrast_product_id = $value;
                $this->obj_contradict->save();
                redirect(base_url() . 'product_management/list_contradicts', 'refresh');
            }
        }
        $data = array();
        $generic_arr = $this->obj_generic->find_active();
        $data['generic'] = $generic_arr->result_array(); 
        $data['page_title'] = 'Contradictory';
         $data['js'] = array("product_management/add");
        $data['main_content'] = $this->load->view('product_management/contradictory_products', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    public function list_contradicts() { 
        $data = array();
        $data['result'] = $this->obj_contradict->find_all();
        $data['page_title'] = 'Contradictory';
        $data['main_content'] = $this->load->view('product_management/list_contradictory_products', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
}
