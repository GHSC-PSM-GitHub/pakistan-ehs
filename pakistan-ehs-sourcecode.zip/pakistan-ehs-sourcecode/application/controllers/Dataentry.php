<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dataentry extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('data_master');
        $this->load->model('date_time');
	}
	
	public function index()
	{
		$this->load->view("dataentry/index","");
    }
    
    public function summary_form()
	{
		$data_master = new data_master();
		$dt = new date_time();

		if(isset($_POST) && !empty($_POST)){
			/* if (isset($_REQUEST['fileid']) && !empty($_REQUEST['fileid'])) {
				$data_master->pk_id = $_REQUEST['fileid'];
			}
	
			$data_master->title = $_POST['title'];
			$data_master->training_date = $dt->dbformat($_POST['training_date']);
			$data_master->is_active = 1;
	
			$data_master->save();
			redirect(base_url() .'training_records/index', 'refresh'); */
			$data = array();
			$data['page_title'] = 'Saved';
			$data['main_content'] = $this->load->view('dataentry/saved', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();
			$data['page_title'] = 'Summary Form';
			$data['main_content'] = $this->load->view('dataentry/summary_form', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
		
	}

	public function summary_form_m()
	{
		$data_master = new data_master();
		$dt = new date_time();

		if(isset($_POST) && !empty($_POST)){
			/* if (isset($_REQUEST['fileid']) && !empty($_REQUEST['fileid'])) {
				$data_master->pk_id = $_REQUEST['fileid'];
			}
	
			$data_master->title = $_POST['title'];
			$data_master->training_date = $dt->dbformat($_POST['training_date']);
			$data_master->is_active = 1;
	
			$data_master->save();
			redirect(base_url() .'training_records/index', 'refresh'); */
			$data = array();
			$data['page_title'] = 'Saved';
			$data['main_content'] = $this->load->view('dataentry/saved', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();
			$data['page_title'] = 'Summary Form';
			$data['main_content'] = $this->load->view('dataentry/summary_form_m', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
		
	}
}
