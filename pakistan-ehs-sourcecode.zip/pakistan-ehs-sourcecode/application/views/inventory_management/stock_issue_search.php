<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Stock Issue Search</h3>
                         
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                     <div class="innerLR">
                        <br>
                        <?php
                        if ( !empty($result)) {
                            ?>

                            <div id="divToPrint">
                                <table class="table table-striped table-bordered table-condensed dt-responsive nowrap" id="datatable-buttons">
                                    <thead>
                                        <tr>
                                            <th style="width: 1%;" class="center">No.</th>
                                            <th>Transaction Number</th>
<!--                                            <th>Reference Number</th>-->
                                            <th>Issued To</th>
                                            <th>Issuance Date</th>
<!--                                            <th>Funding Source</th>-->
                                            <th>Product Name</th>   
                                            <th>Batch Number</th>
<!--                                            <th>Expiry Date</th> -->
                                            <th>Quantity</th> 
                                            <th>Action</th> 
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Table row -->
                                        <?php
                                        $count = 1; 
                                        foreach ($result->result_array() as $row) {
//                                            echo '<pre>';
//                                            print_r($row);
//                                            echo '</pre>';
//                                            exit;
                                            ?>
                                            <tr>
                                                <td class="center"><?php echo $count; ?></td>
                                                <td class="important"><?php echo "I-".sprintf('%04d', $row['stock_master_id']); ?></td>
<!--                                                <td class="important"><?php echo $row['transaction_reference']; ?></td>-->
                                                <td class="important"><?php if($row['issuance_to']=='centers')echo ($row['warehouse_name']); else echo $row['full_name']."-".$row['nic_no']; ?></td>
                                                <td class="important"><?php echo $row['transaction_date']; ?></td> 
<!--                                                <td class="important"><?php echo $row['funding_source_name']; ?></td>-->
                                                <td><?php echo $row['product_name']; ?></td>  
                                                <td class="important"><?php echo $row['batch_number']; ?></td>
<!--                                                <td class="important"><?php echo $row['batch_expiry']; ?></td> -->
                                                <td class="important"><?php echo $row['quantity']; ?></td> 
                                                <td>
                                                <?php
                                                
                                                    if($this->session->userdata('id')==$row['created_by']){
                                                        echo '<a class="btn btn-secondary btn-sm" href="'.base_url('inventory_management/del_stock_detail/'.$row['pk_id']).'"  onclick="return confirm(\'This action will delete data of this transaction. Deletion is not reversible.\')"> Delete</a>';
                                                    }
                                                ?>
                                                </td>
                                              
                                            </tr>
                                            <?php
                                            $count++;
                                        }
                                        ?>
                                        <!-- // Table row END -->
                                        <!-- Table row -->

                                        <!-- // Table row END -->
                                    </tbody>
                                </table> 
                            </div>

                            <!-- // Table END -->
                            <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>