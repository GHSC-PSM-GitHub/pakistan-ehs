<?php
//print_r($tran_reference_number);exit;
if (isset($stock_master_records)) {
    $row = $stock_master_records[0];
    $refernce_number = $row['transaction_reference'];
    $warehouse_from = $row['warehouse_from'];
} else if (isset($tran_reference_number)) {
    // hello this is tests code

    $refernce_number = $tran_reference_number;
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12">
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Stock Receive</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="stock_receive" name="stock_receive" action="<?php echo base_url("inventory_management/stock_receive"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row">
                                            <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="invoice_no" required>Invoice# <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="invoice_no" id="invoice_no" placeholder="Invoice Number" class="form-control" required <?php if (isset($invoice_no)) echo 'readonly="true"' ?> <?php
                                                                                                                                                                                                                    if (isset($invoice_no)) {
                                                                                                                                                                                                                        echo 'value="' . $invoice_no . '"';
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    ?> required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Reference Number <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="refernce_number" id="reference_number" placeholder="Reference/PO Number" class="form-control" required <?php if (isset($master_id)) echo 'readonly="true"' ?> <?php
                                                                                                                                                                                                                    if (isset($refernce_number)) {
                                                                                                                                                                                                                        echo 'value="' . $refernce_number . '"';
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    ?> required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Receiving Date <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="receiving_time" id="receiving_time" required value="<?php echo date("m/d/Y"); ?>" <?php if (isset($master_id)) echo 'readonly="true"' ?>>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3" style="">
                                                    <label class="example-text-input" for="strength" required>Funding Source<span style="color: red">*</span> <?= (empty($temp_records)) ? '<a class="btn btn-sm btn-primary" href="../warehouse_management/add_funding_source">Add New</a>' : '' ?></label>
                                                    <div class="controls">
                                                        <?php

                                                        if (empty($temp_records)) {

                                                        ?>
                                                            <select class="select2me input-medium" name="received_from" id="received_from" required style="width:100%;padding:10%;">
                                                                <?php
                                                                foreach ($suppliers as $row) {
                                                                ?>
                                                                    <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($warehouse_from) && $warehouse_from == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['warehouse_name'] ?></option>
                                                                <?php
                                                                }
                                                                ?>

                                                            </select>
                                                        <?php
                                                        } else {
                                                            foreach ($suppliers as $row) {
                                                                if (isset($warehouse_from) && $warehouse_from == $row['pk_id']) echo  '<input class="form-control" disabled value="' . $row['warehouse_name'] . '">';
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                

                                            </div>
                                            <div class="form-group row">

                                            <div class="col-md-3">
                                                    <label class="example-text-input" required>Product<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="product" id="product" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($product as $row) {
                                                            ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($product_id) && $product_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['product_name'] ?></option>
                                                            <?php
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="registration_number" required>Batch Number<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="batch_number" id="batch_number" class="form-control" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Manufacturing Date <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" name="manufacturing_date" id="manufacturing_date" class="form-control" required value="<?php echo date("m/d/Y"); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Expiry Date <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" name="expiry_date" id="expiry_date" class="form-control" required value="<?php echo date("m/d/Y"); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                

                                            </div>
                                            <div class="form-group row">
                                            <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Manufactured by <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <?php echo create_combo('manufacturer', $manufacturers); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="quantity" id="quantity" class="form-control" min="0" onchange="calc()" required>
                                                            <span id="prod_unit"></span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Unit Price (PKR) <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="unit_price" id="unit_price" onchange="calc()" class="form-control" min="0" required>
                                                        </div>
                                                    </div>
                                                </div>                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Amount (PKR) <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="amount" id="amount" onchange="calc()" class="form-control" min="0" required value="">
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                            <div class="form-group row m-b-0" id="msg_shelf">
                                                <div class="alert alert-danger alert-dismissiblex fade show" role="alert">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <!--                                                        <span aria-hidden="true">×</span>-->
                                                    </button> <span id="msg_shelf_text">Attention: The Batch must have shelf life of at least 85% , as per instructions from DRAP.</span>
                                                </div>
                                            </div>
                                            <div class="form-group row">

                                                <div class="col-md-6">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Remarks</label>
                                                        <div class="controls">
                                                            <textarea name="remarks" id="remarks" class="form-control"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light"> Add Receiving</button>
                                                </div>
                                                <?php if (isset($temp_records) && (!empty($temp_records))) {
                                                ?>
                                                    <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>">
                                                <?php }
                                                ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <br>
                            <?php
                            if (isset($temp_records) && (!empty($temp_records))) {
                            ?>

                                <div id="divToPrint">
                                    <table class="table table-striped table-bordered table-condensed dt-responsive ">
                                        <thead>
                                            <tr>
                                                <th style="width: 1%;" class="center">No.</th>
                                                <th>Supplier</th>
                                                <th>Product Name</th>
                                                <th>Batch Number</th>
                                                <th>Expiry Date</th>
                                                <th>Quantity</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Table row -->
                                            <?php
                                            $count = 1;
                                            foreach ($temp_records->result_array() as $row) {
                                            ?>
                                                <tr>
                                                    <td class="center"><?php echo $count; ?></td>
                                                    <td class="important"><?php echo $row['wh_from']; ?></td>
                                                    <td><?php echo $row['product_name']; ?></td>
                                                    <td class="important"><?php echo $row['batch_number']; ?></td>
                                                    <td class="important"><?php echo $row['batch_expiry']; ?></td>
                                                    <td class="important"><?php echo $row['quantity']; ?></td>

                                                    <td><button class="btn btn-danger btn-sm" type="button" id="<?php echo $row['batch_id'] . "_" . $row['pk_id']; ?>-deleterv">
                    <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
                </button></td>
                                                </tr>
                                            <?php
                                                $count++;
                                            }
                                            ?>
                                            <!-- // Table row END -->
                                            <!-- Table row -->

                                            <!-- // Table row END -->
                                        </tbody>
                                    </table>
                                </div>
                                <button type="button" id="save_temp_receive" name="save_temp_receive" class="btn btn-primary waves-effect waves-light" style="margin-left:90%;">Save</button>

                                <!-- // Table END -->
                            <?php
                            }
                            ?>
                        </form>
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>