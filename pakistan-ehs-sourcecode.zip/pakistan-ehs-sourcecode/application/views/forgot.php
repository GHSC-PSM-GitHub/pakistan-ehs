<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title><?php echo $title; ?></title>
        <meta content="Responsive admin theme build on top of Bootstrap 4" name="description" />
        <meta content="Themesdesign" name="author" />
        <!-- <link rel="shortcut icon" href="assets/images/favicon.ico"> -->

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
        <style>
       .card {
    background: #CBD7E3;
border: 3px solid #020003;
margin-bottom: 0px;
}
.form-control {
    background-color: whitesmoke;
}
.text-muted {
    color: #354558 !important;
}
.btn-info {
    background-color: #00184C;
    border: 1px solid #020003;
}

.btn-info:hover {
    background-color: #015E32;
    border: 1px solid #020003;
}
.wrapper-page {
    margin: 3% auto;
    width: 460px;
    position: relative;
    padding-top: 4%;
}

.accountbg {
    background: url("assets/images/default-bg.png");
}

<?php echo $css; ?>
        </style>
    </head>

    <body>

        <!-- Begin page -->
        <div class="accountbg"></div>
        <!-- <div class="home-btn d-none d-sm-block">
                <a href="<?php echo base_url("/"); ?>" class="text-white"><i class="fas fa-home h2"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="<?php echo base_url("/"); ?>" class="text-white"><i class="fas fa-hospital h2"></i></a>
            </div> -->
        <div class="wrapper-page">
                <div class="card card-pages shadow-none">
    
                    <div class="card-body">
                        <div class="text-center m-t-0 m-b-15">
                                <a href="<?php echo base_url("/"); ?>" class="logo logo-admin"></a>
                        </div>
                        <h5 class="font-18 text-center">Reset Password</h5>
    
                        <form class="form-horizontal m-t-30" action="index.html">

                               <div class="col-12">
                                    <div class="alert alert-danger alert-dismissible">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                            Enter your <b>Email</b> and instructions will be sent to you!
                                        </div>
                               </div>

                                <div class="form-group">
                                        <div class="col-12">
                                                <label>Email</label>
                                            <input class="form-control" type="text" required="" placeholder="Email">
                                        </div>
                                    </div>
    
                            <div class="form-group text-center m-t-20">
                                <div class="col-12">
                                    <button class="btn btn-info btn-block btn-lg waves-effect waves-light" type="submit">Send Email</button>
                                </div>
                            </div>
                        </form>
                    </div>
    
                </div>
            </div>
        <!-- END wrapper -->

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metismenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
        
    </body>

</html>