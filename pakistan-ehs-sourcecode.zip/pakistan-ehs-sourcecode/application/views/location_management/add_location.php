<?php
if(isset($result))
{
   
    $row=$result->result_array();
     $row=$row[0]; 
     $level=$row['location_level'];
     $province_id=$row['parent_id']; 
     $name=$row['location_name'];
     $longitude=$row['longitude'];
     $latitude=$row['latitude'];
     if($level==5){
         if(isset($district)){
             $dist_arr=$district->result_array();
             foreach ($dist_arr as $row_1) {
                 $district_id=$row_1['pk_id'];
                 $province_id=$row_1['parent_id'];
             }
         }
     }
     else if($level==6)
     {
//         print_r($district);exit;
         $tehsil_id=$tehsil_id;
         if(isset($district)){
             $dist_arr=$district->result_array();
             foreach ($dist_arr as $row_1) {
                 $district_id=$row_1['pk_id'];
                 $province_id=$row_1['parent_id'];
                 
             }
         }
     }
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Add Locations</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="addlocation" name="addlocation" action="<?php echo base_url("Location_management/add_location");?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row"> 
                                                <div class="col-md-3">
                                                    <label for="example-text-input" class="example-text-input">Location Level<span style="color: red">*</span></label>
                                                    <div class="controls">
                                                    <select class="form-control" id="location_level" name="location_level" required>
                                                        <option value="">Select</option>
                                                         <option value="4" <?php if (isset($level) && $level == 4) echo "selected='selected'"; ?>>District</option>
                                                        <option value="5" <?php if (isset($level) && $level == 5) echo "selected='selected'"; ?>>Tehsil</option>
                                                        <option value="6" <?php if (isset($level) && $level == 6) echo "selected='selected'"; ?>>Uniion Coucil</option>
                                                    </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  <?php if (!isset($level)) {?> style="display:none;"<?php } ?> id="province_div">
                                                    <label class="example-text-input" for="province" required >Province <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="province" id="province" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            if(isset($provinces))
                                                            {
                                                                $province_arr=$provinces->result_array();
                                                                foreach ($province_arr as $row) {
                                                                    ?>
                                                            <option value="<?php echo $row['pk_id']?>" <?php if(isset($province_id)&&$province_id==$row['pk_id']) echo 'selected="selected"'?>><?php echo $row['location_name']?></option>
                                                                        <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div> 
                                                <div class="col-md-3" <?php if(!isset($district_id)){?>style="display:none;"<?php }?> id="district_div">
                                                    <label class="example-text-input" for="district" required >District <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="district" id="district" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            if(isset($districts))
                                                            {
                                                                $dist_arr=$districts->result_array();
                                                                foreach ($dist_arr as $row) {
                                                                    ?>
                                                            <option value="<?php echo $row['pk_id']?>" <?php if(isset($district_id)&&$district_id==$row['pk_id']) echo 'selected="selected"'?>><?php echo $row['location_name']?></option>
                                                                        <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div> 
                                                <div class="col-md-3" <?php if(!isset($tehsil_id)){ ?> style="display:none;"<?php }?> id="tehsil_div">
                                                    <label class="example-text-input" for="tehsil" required >Tehsil <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="tehsil" id="tehsil" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                             <?php
                                                            if(isset($tehsils))
                                                            {
                                                                $tehsil_arr=$tehsils->result_array();
                                                                foreach ($tehsil_arr as $row) {
                                                                    ?>
                                                            <option value="<?php echo $row['pk_id']?>" <?php if(isset($tehsil_id)&&$tehsil_id==$row['pk_id']) echo 'selected="selected"'?>><?php echo $row['location_name']?></option>
                                                                        <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div> 
                                                 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="location_name" required >Location Name <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="location_name" id="location_name" class="form-control" required=""
                                                            <?php
                                                            if (isset($result)) { 
                                                                    echo 'value="' . $name . '"'; 
                                                            }
                                                            ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>  
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="longitude" >Longitude </label>
                                                        <div class="controls">
                                                            <input type="text" name="longitude" id="longitude" class="form-control"
                                                            <?php
                                                            if (isset($result)) { 
                                                                    echo 'value="' . $longitude . '"'; 
                                                            }
                                                            ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="latitude" >Latitude  </label>
                                                        <div class="controls">
                                                            <input type="text" name="latitude" id="latitude" class="form-control"
                                                            <?php
                                                            if (isset($result)) { 
                                                                    echo 'value="' . $latitude . '"'; 
                                                            }
                                                            ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                </div>
                                            <div class="form-group row">
                                                 
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="location_btn" name="location_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                    if (isset($result))
                                                        echo 'value="edit"';
                                                    ?>>
                                                        <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                    Reset
                                                </button>
                                                </div> 
                                                <?php if (isset($result)) {
                                                    ?>
                                                <input type="hidden" id="pk_id" name="pk_id" value="<?php if (isset($result)) echo $_REQUEST['id'] ?>">
                                                <?php } ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />
                                            
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>