<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12">
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Locations</h3>
                        <div class="buttons pull-right">
                            <a href="<?php echo base_url("location_management/add_location"); ?>" class="btn btn-primary btn-icon glyphicons circle_plus"><i></i>Add</a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <!-- // Heading END -->

                    <div class="innerLR">
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <br>
                                        <?php
                                        if (isset($result) && !empty($result)) {
                                        ?>

                                            <div id="divToPrint">
                                                <table id="datatable-buttons" class="table table-striped table-bordered table-condensed dt-responsive nowrap">
                                                    <thead>
                                                        <tr>
                                                            <th class="center">No.</th>
                                                            <th>Location Name</th>
                                                            <th>Location Type</th>
                                                            <th>Action</th>
                                                            <th></th>
                                                            <th></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <!-- Table row -->
                                                        <?php
                                                        $count = 1;
                                                        //        echo '<pre>';
                                                        //        print_r($result->result_array());
                                                        //        exit;
                                                        foreach ($result->result_array() as $row) {
                                                        ?>
                                                            <tr>
                                                                <td class="center"><?php echo $count; ?></td>
                                                                <td><?php echo $row['location_name']; ?></td>
                                                                <td class="important">
                                                                    <?php
                                                                    if ($row['location_level'] == 1) {
                                                                        echo 'National';
                                                                    } else if ($row['location_level'] == 2 && $row['location_type'] == 2) {
                                                                        echo 'Province';
                                                                    } else if ($row['location_level'] == 2 && $row['location_type'] == 3) {
                                                                        echo 'Federal Territory';
                                                                    } else if ($row['location_level'] == 3) {
                                                                        echo 'Division';
                                                                    } else if ($row['location_level'] == 4) {
                                                                        echo 'District';
                                                                    } else if ($row['location_level'] == 5) {
                                                                        echo 'Tehsil';
                                                                    } else if ($row['location_level'] == 6) {
                                                                        echo 'Union Council';
                                                                    }
                                                                    ?></td>
                                                                <td>
                                                                    <?php if ($row['location_level'] != 1 && $row['location_level'] != 2 && $row['location_level'] != 3) { ?>
                                                                        <a href="<?php echo base_url("location_management/edit_location?id=") . $row['pk_id']; ?> " class="btn btn-danger" title="edit">Edit</a>
                                                                    <?php
                                                                    }
                                                                    ?>
                                                                </td>
                                                                <td>
                                                                    <?php if ($row['location_level'] != 1 && $row['location_level'] != 2 && $row['location_level'] != 3) { ?>

                                                                        <a onclick="return confirm('Are you sure you want to delete?');" href="<?php echo base_url("location_management/deactivate_location?id=") . $row['pk_id']; ?>" class="btn btn-warning" id="<?php echo $row['pk_id'] . "de_btn" ?>" name="de_btn" data-id="<?php echo $row['pk_id'] ?>">Delete</a>
                                                                    <?php
                                                                    }
                                                                    ?>
                                                                </td>
                                                                <td>
                                                                    <a href="<?php echo base_url("masterdata_management/add_mdm?id=") . $row['pk_id']; ?>&type=location" class="btn btn-success" title="add_ext">MDM</a>
                                                                </td>
                                                            </tr>
                                                        <?php
                                                            $count++;
                                                        }
                                                        ?>
                                                        <!-- // Table row END -->
                                                        <!-- Table row -->

                                                        <!-- // Table row END -->
                                                    </tbody>
                                                </table>
                                            </div>

                                            <!-- // Table END -->
                                        <?php
                                        } else {
                                            echo "<hr><h5>No data found!</h5>";
                                        }
                                        ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>