<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12">
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Users</h3>
                        <div class="buttons pull-right">
                            <a href="<?php echo base_url("Users_management/add"); ?>" class="btn btn-primary btn-icon glyphicons circle_plus"><i class="fas fa-user-plus"></i> Add</a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <!-- // Heading END -->

                    <div class="innerLR">
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <?php
                                        //        require_once 'classes/user.php';
                                        //        require_once 'classes/datetime.php';
                                        //
                                        //        $doc = new user();
                                        //
                                        //        $result = $doc->find_all();
                                        //        if ($result) {
                                        if (isset($result) && !empty($result)) {
                                            $data = $result->result_array();
                                        ?>
                                            <!-- Table -->

                                            <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap">
                                                <thead>
                                                    <tr>
                                                        <th style="width: 1%;" class="center">No.</th>
                                                        <th>User Name</th>
                                                        <th>Login Id</th>
                                                        <th>E-mail</th>
                                                        <th>Phone No</th>
                                                        <th>District</th>
                                                        <th>Facility</th>
                                                        <th>User Role</th>
                                                        <th>Status</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <!-- Table row -->
                                                    <?php
                                                    $count = 1;
                                                    foreach ($data as $row) {

                                                        $class = "gradeX";
                                                        if ($count % 2 == 0) {
                                                            $class = "gradeC";
                                                        }
                                                        //$attchment = new attachments();
                                                        //$att_count = $attchment->count_all($row['pk_id']);
                                                    ?>
                                                        <tr class="<?php echo $class; ?>">
                                                            <td class="center"><?php echo $count; ?></td>
                                                            <td><?php echo $row['username']; ?></td>
                                                            <td class="important"><?php echo $row['login_id']; ?></td>
                                                            <td class="important"><?php echo $row['email']; ?></td>
                                                            <td class="important"><?php echo $row['phone']; ?></td>
                                                            <td class="important"> <?php echo $row['location_name']; ?></td>
                                                            <td class="important"> <?php echo $row['warehouse_name']; ?></td>
                                                            <td class="important"><?php echo $row['role_name']; ?></td>
                                                            <td class="center">

                                                                <?php
                                                                if ($row['is_active'] == 0) {
                                                                ?>
                                                                    <span class="badge badge-pill badge-danger"><i class="fas fa-times "></i> Disabled</span>

                                                                <?php
                                                                } else {
                                                                ?>
                                                                    <span class="badge badge-pill badge-success"><i class="fas fa-check "></i> Active</span>

                                                                <?php
                                                                }
                                                                ?>
                                                            </td>
                                                            <td class="center">
                                                                <a href="<?php echo base_url("Users_management/edit?userid=" . $row['pk_id']); ?>" data-id="<?php echo $row['pk_id']; ?>" class="btn btn-sm btn-light glyphicons pen" title="edit"><i class="far fa-edit"></i> Edit</a>

                                                                <?php
                                                                if ($row['is_active'] == 0) {
                                                                ?>
                                                                    <a onclick="return confirm('Are you sure you want to Activate?');" href="change_status?id=<?php echo $row['pk_id'];   ?>&status=1" class="btn btn-sm btn-light glyphicons bin"><i class="fas fa-check success"></i> Activate It</a>

                                                                <?php
                                                                } else {
                                                                ?>
                                                                    <a onclick="return confirm('Are you sure you want to Disable?');" href="change_status?id=<?php echo $row['pk_id'];   ?>&status=0" class="btn btn-sm btn-light glyphicons bin"><i class="fas fa-times red"></i> De-active It</a>

                                                                <?php
                                                                }
                                                                ?>
                                                            </td>
                                                        </tr>
                                                    <?php
                                                        $count++;
                                                    }
                                                    ?>
                                                    <!-- // Table row END -->
                                                    <!-- Table row -->

                                                    <!-- // Table row END -->
                                                </tbody>
                                            </table>
                                            <!-- // Table END -->
                                        <?php
                                        } else {
                                            echo "<hr><h5> No records found!</h5>";
                                        }
                                        ?>



                                    </div>

                                </div>

                            </div>
                        </div>
                        <!-- end row -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>