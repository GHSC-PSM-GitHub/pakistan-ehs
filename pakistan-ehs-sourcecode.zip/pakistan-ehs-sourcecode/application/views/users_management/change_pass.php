<?php
// print_r($result);exit;
if (isset($result)) {
    $result = $result[0];
    $user_name = $result['username'];
    $login_id = $result['login_id'];
    $email_id = $result['email'];
    $status = $result['is_active'];
}
?>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12">
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Change Password</h3>

                    </div>

                    <?php
                    if( $result['pk_id']!=$this->session->id  ){
                        ?>

                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">

                                        You are not allowed to modify password of this user

                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }else{

                        ?>
                        <form method="post" id="add_user_form" name="add_user_form" action="<?php echo base_url("Users_management/update_pass"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row">
                                                <div class="col-md-4">
                                                    <label for="example-text-input" class="col-form-label">Full Name</label>
                                                    <div class="controls">
                                                        <input class="form-control" readonly id="username" name="username" value="<?php if (isset($user_name)) echo $user_name; ?>" type="text" required="true"/>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <label for="example-text-input" class="col-form-label">Login ID</label>

                                                    <div class="controls">
                                                        <input class="form-control" id="login_id" name="login_id" value="<?php if (isset($login_id)) echo $login_id; ?>" <?php if (isset($login_id)) echo 'readonly'; ?> type="text" required="true"/></div>
                                                </div>
                                            </div>
                                            <div class="form-group row">

                                                <div class="col-md-4">
                                                    <label for="example-text-input" class="col-form-label" id="old_password_label"> Old Password </label>
                                                    <div class="controls">
                                                        <input class="form-control" id="old_password" name="old_password" value="" type="password" placeholder="Enter old password" required="true" oninput="validate_old_password()"/>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <label for="example-text-input" class="col-form-label">New Password</label>
                                                    <div class="controls">
                                                        <input class="form-control" id="password" name="password" value="" type="password" placeholder="Enter new password" required="true"/>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="example-text-input" class="col-form-label"> Confirm New Password </label>
                                                    <div class="controls">
                                                        <input class="form-control" id="password1" name="password1" value="" type="password" placeholder="Confirm new password" required="true"/>
                                                    </div>
                                                </div>


                                                <input type="hidden" id="user_id" name="user_id"
                                                       value="<?php echo $result['pk_id'] ?>">

                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-10"></div>
                                                <div class="col-md-2" style="margin-top:3%;">
                                                    <button type="submit" class="btn btn-primary waves-effect waves-light" id="submit_btn">
                                                        Submit
                                                    </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    //function validate_old_password(){
    //    $.ajax({
    //        type: "post",
    //        url: "<?php //echo base_url('users_management/validate_old_password'); ?>//",
    //        data: {
    //            old_password: $('#old_password').val()
    //        },
    //        dataType: 'json',
    //        success: function (data) {
    //            if (data == '1'){
    //                $('#submit_btn').prop('disabled', false);
    //                $('#old_password_label').html(' Old Password <span class="text-success"> (Password Matched) </span>');
    //            }
    //            else {
    //                $('#submit_btn').prop('disabled', true);
    //                $('#old_password_label').html(' Old Password <span class="text-danger"> (Incorrect Password) </span>');
    //            }
    //        }
    //    });
    //}
</script>