<?php
// print_r($result);exit;
if (isset($result)) {
    $result = $result[0];
    $user_name = $result['username'];
    $designation = $result['designation'];
    $login_id = $result['login_id'];
    $email_id = $result['email'];
    $contact_number = $result['phone'];
    $district_id = $result['district_id'];
    $province_id = $result['province_id'];
    $role_id = $result['role_id'];
    $status = $result['is_active'];
}
?>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Add users</h3>

                    </div> 
                    <form method="post" id="add_user_form" name="add_user_form" action="<?php echo base_url("Users_management/add"); ?>">
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="form-group row"> 
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Username <span style="color: red">*</span></label>
                                                <div class="controls">
                                                    <input class="form-control" id="username" name="username" value="<?php if (isset($user_name)) echo $user_name; ?>" type="text" required="true"/>
                                                </div> 
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Designation</label> 
                                                <div class="controls">
                                                    <input class="form-control" id="designation" name="designation" value="<?php if (isset($designation)) echo $designation; ?>" type="text" /></div>                                                
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Login ID <span style="color: red">*</span></label>

                                                <div class="controls">
                                                    <input class="form-control" id="login_id" name="login_id" value="<?php if (isset($login_id)) echo $login_id; ?>" type="text" required="true"/></div>
                                            </div> 
                                        </div> 
                                        <div class="form-group row"> 
                                            <?php
                                            if (!isset($result)) {
                                                ?>
                                                <div class="col-md-4">
                                                    <label for="example-text-input" class="col-form-label">Password <span style="color: red">*</span></label>

                                                    <div class="controls"><input class="form-control" id="password" name="password" value="" type="password" placeholder="Enter password" required="true"/>
                                                    </div>
                                                </div>  
                                                <div class="col-md-4">
                                                    <label for="example-text-input" class="col-form-label">Confirm Password <span style="color: red">*</span></label>

                                                    <div class="controls">
                                                        <input class="form-control" id="confirm_password" name="confirm_password" value="" type="password" placeholder="Confirm password" required="true"/>
                                                    </div>
                                                </div>
                                            <?php }
                                            ?>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Email <span style="color: red">*</span></label>

                                                <div class="controls"><input class="form-control" id="email" name="email" value="<?php if (isset($email_id)) echo $email_id; ?>" type="email" required="true"/></div>
                                            </div>


                                        </div>
                                        <div class="form-group row"> 
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Contact No. <span style="color: red">*</span></label>

                                                <div class="controls"><input class="form-control" id="phone" name="phone" value="<?php if (isset($contact_number)) echo $contact_number; ?>" type="number" required="true"/></div>
                                            </div>
                                            <!--<div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Province</label>
                                                <select class="form-control hidden" id="province" name="province" >
                                                    <option value="8" <?php if (isset($province_id) && $province_id == 8) echo "selected='selected'"; ?>>Islamabad</option>
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">District:</label>

                                                <select class="form-control hidden" id="district" name="district">
                                                <option value="78">Islamabad</option>
                                                </select>
                                            </div> -->

                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-4"> 
                                                <label for="example-text-input" class="col-form-label">Role <span style="color: red">*</span></label>

                                                <div class="controls">
                                                    <select class="form-control" id="role_id" name="role_id" required="true">
                                                        <option value="8"  <?php if (isset($role_id) && $role_id == 8) echo "selected='selected'"; ?>>Front Desk</option>
                                                        <option value="4"  <?php if (isset($role_id) && $role_id == 4) echo "selected='selected'"; ?>>Data Enry Operator</option>
                                                        <option value="9"  <?php if (isset($role_id) && $role_id == 9) echo "selected='selected'"; ?>>Main IM Store</option> 
                                                        <option value="10"  <?php if (isset($role_id) && $role_id == 10) echo "selected='selected'"; ?>>Readonly</option> 
                                                        <option value="11"  <?php if (isset($role_id) && $role_id == 11) echo "selected='selected'"; ?>>Analytics</option>                             
                                                    </select>
                                                </div>
                                            </div> 
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Status <span style="color: red">*</span></label>

                                                <div class="controls">
                                                    <select class="form-control" id="status" name="status" required="true">
                                                        <option value="1"  <?php if (isset($status) && $status == 1) echo "selected='selected'"; ?>>Active</option>
                                                        <option value="0"  <?php if (isset($status) && $status == 0) echo "selected='selected'"; ?>>Inactive</option>                                
                                                    </select>
                                                </div>
                                            </div> 
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Health Facility <span style="color: red">*</span></label>

                                                <div class="controls">
                                                    <select class="select2me input-medium" id="hf" name="hf" required="true" style="width:100%;padding:10%;">
                                                        <option value="">Select</option>
                                                        <?php
                                                        foreach ($hf as $row) {
                                                            ?>
                                                            <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($district_id) && $district_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['warehouse_name'] ?></option>
                                                            <?php
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <?php if (isset($result)) { ?>
                                                    <input type="hidden" id="user_id" name="user_id" value="<?php echo $result['pk_id'] ?>">
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-10"></div>
                                            <div class="col-md-2" style="margin-top:3%;">
                                                <button type="submit" class="btn btn-primary waves-effect waves-light">
                                                    Submit
                                                </button>
                                                <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                    Reset
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div> 
        </div>
    </div>