<head>
    <link rel="stylesheet" href="../plugins/chartist/css/chartist.min.css">
</head> 
<body>
    <?php
    $from_date = date('Y-m-01', strtotime('-2 month'));
    $to_date = date('Y-m-d');
    ?>
    <div class="wrapper">
        <div class="container-fluid">
            <!-- Page-Title -->
            <br>
            <form method="post" id="form1" name="form1">
                <div class="row row-sm">
                    <div class=" d-flex ">
                        <div >
                            From Date : <input type="date" id ="from_month" name="from_month" class="form-control  " value="<?php echo $from_date ?>" >
                        </div>
                        <div>
                            To Date : <input type="date" id ="to_month" name="to_month" class="form-control  " value="<?php echo $to_date ?>" >
                        </div>

                        <div>
                            <input class="btn btn-success " class="form-control" type="button" id="save_btn1" value="Go">
                        </div>
                    </div>
                </div>
            </form>
            <br>
            <div class="row">
                <div class="col-xl-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <h4 class="mt-0 header-title">Patients Week Wise</h4>
                            <canvas id="bar" height="300"></canvas>

                        </div>
                    </div>
                </div> <!-- end col -->

                <div class="col-xl-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <h4 class="mt-0 header-title">Patients Trend</h4>
                            <canvas id="lineChart" height="300"></canvas>

                        </div>
                    </div>
                </div> <!-- end col -->

            </div> <!-- end row -->


            <div class="row">
                <div class="col-xl-6">
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Employee</h4>
                            <canvas id="pie" height="260"></canvas>

                        </div>
                    </div>
                </div> <!-- end col -->



                <div class="col-xl-6">
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Stock Sufficiency</h4>
                            <div id="simple-line-chart" class="ct-chart ct-golden-section"></div>
                        </div>
                    </div>
                </div> 

            </div> <!-- end row -->

            <div class="col-xl-6" hidden>
                <div class="card m-b-30">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">Doughnut Chart (Extra)</h4>
                        <canvas id="doughnut" height="300"></canvas>

                    </div>
                </div>
            </div>  

        </div>
        <!-- end container-fluid -->
    </div>
    <!-- end wrapper -->

      <!-- jQuery  -->
    <script src="../assets/js/jquery.min.js"></script>

    <!-- chartjs js -->
    <script src="../plugins/chartjs/chart.min.js"></script> 

    <!-- App js -->
    <script src="../assets/js/app.js"></script>

    <script src="../plugins/chartist/js/chartist.min.js"></script>
    <script src="../plugins/chartist/js/chartist-plugin-tooltip.min.js"></script>
    <script src="../ihitc/assets/pages/chartist.init.js"></script>  

</body>
<script>
    !function ($) {
        "use strict";

        //Simple line chart
        new Chartist.Line('#simple-line-chart', {
            labels: ['May', 'Jun', 'Jul', 'Aug', 'Sep'],
            series: [   [10, 5, 17, 11, 13]
              ]
        }, {
            fullWidth: true,
            chartPadding: {
                right: 40
            },
            plugins: [
                Chartist.plugins.tooltip()
            ]
        });

        var ChartJs = function () {};

        ChartJs.prototype.respChart = function (selector, type, data, options) {
            // get selector by context
            var ctx = selector.get(0).getContext("2d");
            // pointing parent container to make chart js inherit its width
            var container = $(selector).parent();

            // enable resizing matter
            $(window).resize(generateChart);

            // this function produce the responsive Chart JS
            function generateChart() {
                // make chart width fit with its container
                var ww = selector.attr('width', $(container).width());
                switch (type) {
                    case 'Line':
                        new Chart(ctx, {type: 'line', data: data, options: options});
                        break;
                    case 'Doughnut':
                        new Chart(ctx, {type: 'doughnut', data: data, options: options});
                        break;
                    case 'Pie':
                        new Chart(ctx, {type: 'pie', data: data, options: options});
                        break;
                    case 'Bar':
                        new Chart(ctx, {type: 'bar', data: data, options: options});
                        break;
                    case 'Radar':
                        new Chart(ctx, {type: 'radar', data: data, options: options});
                        break;
                    case 'PolarArea':
                        new Chart(ctx, {data: data, type: 'polarArea', options: options});
                        break;
                }
                // Initiate new chart or Redraw

            }
            ;
            // run function - render chart at first load
            generateChart();
        },
                //init
                ChartJs.prototype.init = function () {
                    //creating lineChart
                    var lineChart = {
                        labels: ["01-10-2021", "02-10-2021", "03-10-2021", "04-10-2021", "05-10-2021", "06-10-2021", "07-10-2021"],
                        datasets: [
                            {
                                label: "Number of Patient",
                                fill: true,
                                lineTension: 0.5,
                                backgroundColor: "rgba(48, 65, 155, 0.2)",
                                borderColor: "#30419b",
                                borderCapStyle: 'butt',
                                borderDash: [],
                                borderDashOffset: 0.0,
                                borderJoinStyle: 'miter',
                                pointBorderColor: "#30419b",
                                pointBackgroundColor: "#fff",
                                pointBorderWidth: 1,
                                pointHoverRadius: 5,
                                pointHoverBackgroundColor: "#30419b",
                                pointHoverBorderColor: "#30419b",
                                pointHoverBorderWidth: 2,
                                pointRadius: 1,
                                pointHitRadius: 10,
                                data: [80, 59, 80, 81, 56, 55, 40]
                            }
                           
                        ]
                    };

                    var lineOpts = {
                        scales: {
                            yAxes: [{
                                    ticks: {
                                        max: 100,
                                        min: 20,
                                        stepSize: 10
                                    }
                                }]
                        }
                    };

                    this.respChart($("#lineChart"), 'Line', lineChart, lineOpts);


                    //donut chart
                    var donutChart = {
                        labels: [
                            "Present",
                            "Absent"
                        ],
                        datasets: [
                            {
                                data: [300, 100],
                                backgroundColor: [
                                    "#30419b",
                                    "#f0f4f7"
                                ],
                                hoverBackgroundColor: [
                                    "#30419b",
                                    "#f0f4f7"
                                ],
                                hoverBorderColor: "#fff"
                            }]
                    };
                    this.respChart($("#doughnut"), 'Doughnut', donutChart);


                    //Pie chart
                    var pieChart = {
                        labels: [
                            "Doctors",
                            "Concultants",
                            "Nurse",
                            "Aya",
                            "Others"
                            
                        ],
                        datasets: [
                            {
                                data: [50,70,85,25,10],
                                backgroundColor: [
                                    "#02c58d",
                                    "#ce9bfa",
                                    "#f7f25e",
                                    "#93d9cd",
                                    "#7facfa"
                                ],
                                hoverBackgroundColor: [
                                    "#02c58d",
                                    "#f0f4f7"
                                ],
                                hoverBorderColor: "#fff"
                            }]
                    };
                    this.respChart($("#pie"), 'Pie', pieChart);


                    //barchart
                    var barChart = {
                        labels: ["January", "February", "March", "April", "May", "June", "July"],
                        datasets: [
                            {
                                label: "Total Number of Patients",
                                backgroundColor: "rgba(2, 197, 141, 0.4)",
                                borderColor: "#02c58d",
                                borderWidth: 1,
                                hoverBackgroundColor: "rgba(2, 197, 141, 0.5)",
                                hoverBorderColor: "#02c58d",
                                data: [55, 63, 83, 65, 76, 80, 50, 20]
                            }
                        ]
                    };
                    this.respChart($("#bar"), 'Bar', barChart);


                    //radar chart


                },
                $.ChartJs = new ChartJs, $.ChartJs.Constructor = ChartJs

    }(window.jQuery),
//initializing
            function ($) {
                "use strict";
                $.ChartJs.init()
            }(window.jQuery);

</script>