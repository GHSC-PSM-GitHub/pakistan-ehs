<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Dashboard</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Hepc</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>

        <div class="row">
            <div class="col-sm-6 col-xl-3">
            <a href="<?php echo base_url('/lab/lab_worker_dataentry/1'); ?>">
                <div class="card">
                    <div class="card-heading p-4">
                        <div class="mini-stat-icon float-right">
                            <i class="mdi mdi-hospital bg-primary  text-white"></i>
                        </div>
                        <div>
                            <h5 class="font-16">Total Lab Patients</h5>
                        </div>
                        <h3 class="mt-4"><?php echo get_total_lab_patients(); ?></h3>
                        <div class="progress mt-4" style="height: 4px;">
                            <div class="progress-bar bg-primary" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <p class="text-muted mt-2 mb-0">Total patients registered for lab tests</p>
                    </div>
                </div>
            </a>
            </div>

            <div class="col-sm-6 col-xl-3">
            <a href="<?php echo base_url('/lab/lab_worker_dataentry/2'); ?>">
                <div class="card">
                    <div class="card-heading p-4">
                        <div class="mini-stat-icon float-right">
                            <i class="mdi mdi-hospital bg-success text-white"></i>
                        </div>
                        <div>
                            <h5 class="font-16">Total Assigned tests</h5>
                        </div>
                        <h3 class="mt-4"><?php echo get_assigned_tests(); ?></h3>
                        <div class="progress mt-4" style="height: 4px;">
                            <div class="progress-bar bg-success" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <p class="text-muted mt-2 mb-0">Number of tests assigned to this lab</p>
                    </div>
                </div>
            </a>
            </div>

            <div class="col-sm-6 col-xl-3">
            <a href="<?php echo base_url('/lab/lab_worker_dataentry/3'); ?>">
                <div class="card">
                    <div class="card-heading p-4">
                        <div class="mini-stat-icon float-right">
                            <i class="mdi mdi-hospital bg-warning text-white"></i>
                        </div>
                        <div>
                            <h5 class="font-16">Pending Results</h5>
                        </div>
                        <h3 class="mt-4"><?php echo get_pending_tests(); ?></h3>
                        <div class="progress mt-4" style="height: 4px;">
                            <div class="progress-bar bg-warning" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <p class="text-muted mt-2 mb-0">Number of tests pending</p>
                    </div>
                </div>
            </a>
            </div>

            <div class="col-sm-6 col-xl-3">
            <a href="<?php echo base_url('/lab/lab_worker_dataentry/4'); ?>">
                <div class="card">
                    <div class="card-heading p-4">
                        <div class="mini-stat-icon float-right">
                            <i class="mdi mdi-hospital  bg-danger text-white"></i>
                        </div>
                        <div>
                            <h5 class="font-16">Result Declared</h5>
                        </div>
                        <h3 class="mt-4"><?php echo get_declared_tests(); ?></h3>
                        <div class="progress mt-4" style="height: 4px;">
                            <div class="progress-bar bg-danger" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <p class="text-muted mt-2 mb-0">Number of test completed</p>
                    </div>
                </div>
            </a>
            </div>

        </div>

    </div>
    <!-- end container-fluid -->
</div>
<!-- end wrapper -->