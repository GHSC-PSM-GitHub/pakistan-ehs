    <div class="wrapper">
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Dashboard</h4>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-right">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">Hepc</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                </div>
                <!-- end row -->
            </div>

            <div class="row">

                <div class="col-sm-6 col-xl-3">
                    <div class="card">
                        <div class="card-heading p-4">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-home-group bg-primary  text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Total Population</h5>
                            </div>
                            <h3 class="mt-4">226,623,627</h3>
                            <div class="progress mt-4" style="height: 4px;">
                                <div class="progress-bar bg-primary" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="text-muted mt-2 mb-0">100% population as of 2020-21 period</p>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card">
                        <div class="card-heading p-4">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-human-female-female bg-success text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Target Population</h5>
                            </div>
                            <h3 class="mt-4">158,636,554</h3>
                            <div class="progress mt-4" style="height: 4px;">
                                <div class="progress-bar bg-success" role="progressbar" style="width: 70%" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="text-muted mt-2 mb-0">70% of total population</p>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card">
                        <div class="card-heading p-4">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-shield-home-outline bg-warning text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Screening Target</h5>
                            </div>
                            <h3 class="mt-4">6,345,462</h3>
                            <div class="progress mt-4" style="height: 4px;">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 4%" aria-valuenow="4" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="text-muted mt-2 mb-0">4% of target poulation</p>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card">
                        <div class="card-heading p-4">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-hospital  bg-danger text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Testing Target</h5>
                            </div>
                            <h3 class="mt-4">439,741</h3>
                            <div class="progress mt-4" style="height: 4px;">
                                <div class="progress-bar bg-danger" role="progressbar" style="width: 7%" aria-valuenow="7" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="text-muted mt-2 mb-0">7% of screening target</p>
                        </div>
                    </div>
                </div>

            </div>

            
            <!-- START ROW -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <h4 class="mt-0 header-title mb-4">Prime Minister's Hep C Elimination Program Summary</h4>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">Province</th>
                                            <th scope="col">Target Population</th>
                                            <th scope="col">Total Screened</th>
                                            <th scope="col">Total RPD</th>
                                            <th scope="col">Total Lab test</th>
                                            <th scope="col">Total Positive</th>
                                            <th scope="col">Total Treated</th>
                                            <th scope="col">Total Recovered</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Punjab</td>
                                            <td>132,623,627</td>
                                            <td>1500</td>
                                            <td>1400</td>
                                            <td>1300</td>
                                            <td>1200</td>
                                            <td>1150</td>
                                            <td>1100</td>
                                        </tr>
                                        <tr>
                                            <td>Sindh</td>
                                            <td>47,000,000</td>
                                            <td>800</td>
                                            <td>700</td>
                                            <td>600</td>
                                            <td>300</td>
                                            <td>250</td>
                                            <td>100</td>
                                        </tr>
                                        <tr>
                                            <td>Khyber Pakhtunkhwa</td>
                                            <td>35,000,000</td>
                                            <td>3500</td>
                                            <td>3400</td>
                                            <td>3200</td>
                                            <td>2200</td>
                                            <td>1100</td>
                                            <td>1100</td>
                                        </tr>
                                        <tr>
                                            <td>Balochistan</td>
                                            <td>12,000,000</td>
                                            <td>5500</td>
                                            <td>4500</td>
                                            <td>3500</td>
                                            <td>2500</td>
                                            <td>1550</td>
                                            <td>1500</td>
                                        </tr>
                                        <tr>
                                            <th>Total</th>
                                            <th>226,623,627</th>
                                            <th>11,300
</th>
                                            <th>10,000
</th>
                                            <th>8,600
</th>
                                            <th>6,200
</th>
                                            <th>4,050
</th>
                                            <th>3,800
</th>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
            <!-- END ROW -->

        </div>
        <!-- end container-fluid -->
    </div>
    <!-- end wrapper -->