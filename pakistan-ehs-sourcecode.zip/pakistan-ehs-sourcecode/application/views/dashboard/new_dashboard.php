<head>
    <link rel="stylesheet" href="../plugins/chartist/css/chartist.min.css">
</head> 
<body>
    <?php
    $from_date = date('Y-m-01', strtotime('-2 month'));
    $to_date = date('Y-m-d');
//    echo $quantity_rcv[0]['quantity_rcv']; exit;
    $patient_rig = '[' . $mj_patient[0]['mj_patients'] . ',' . $nkb_patient[0]['nkb_patients'] . ']';
    $transaction = '[' . $trans_rcv[0]['trans_rcv'] . ',' . $trans_issue[0]['trans_issue'] . ']';
    $product = '[' . $mj_product[0]['mj_product'] . ',' . $nkb_product[0]['nkb_product'] . ']';
    $stock = '[' . $quantity_available[0]['quantity_available'] . ',' . $quantity_rcv[0]['quantity_rcv'] . ',' . $quantity_consume[0]['quantity_consume'] . ']';
//    echo $stock; exit;
    ?>
    <div class="wrapper">
        <div class="container-fluid">
            <!-- Page-Title -->
            
            <div class="row" hidden>
            <form method="post" id="form1" name="form1">
                <div class="row row-sm">
                    <div class=" d-flex ">
                        <div >
                            From Date : <input type="date" id ="from_month" name="from_month" class="form-control  " value="<?php echo $from_date ?>" >
                        </div>
                        <div>
                            To Date : <input type="date" id ="to_month" name="to_month" class="form-control  " value="<?php echo $to_date ?>" >
                        </div>

                        <div>
                            <input class="btn btn-success " class="form-control" type="button" id="save_btn1" value="Go">
                        </div>
                    </div>
                </div>
            </form>
            </div>
           <br>
            <div class="row">
                <div class="col-xl-6">
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Registered Patients</h4>
                            <canvas id="pie" height="260"></canvas>

                        </div>
                    </div>
                </div> <!-- end col -->

                <div class="col-xl-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <h4 class="mt-0 header-title">Stock Status</h4>
                            <canvas id="stock" height="260"></canvas>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->

            <div class="row" >
                <div class="col-xl-6" >
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Usage</h4>
                            <canvas id="doughnut" height="260"></canvas>

                        </div>
                    </div>
                </div>  
                <div class="col-xl-6" >
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Product Registered</h4>
                            <canvas id="doughnut1" height="260"></canvas>

                        </div>
                    </div>
                </div>  
            </div>
        </div>
        <!-- end container-fluid -->
    </div>
    <!-- end wrapper -->

    <!-- jQuery  -->
    <script src="../assets/js/jquery.min.js"></script>
    <!-- chartjs js -->
    <script src="../plugins/chartjs/chart.min.js"></script> 

</body>
<script>
    !function ($) {
        "use strict";

        var ChartJs = function () {};

        ChartJs.prototype.respChart = function (selector, type, data, options) {
            // get selector by context
            var ctx = selector.get(0).getContext("2d");
            // pointing parent container to make chart js inherit its width
            var container = $(selector).parent();

            // enable resizing matter
            $(window).resize(generateChart);

            // this function produce the responsive Chart JS
            function generateChart() {
                // make chart width fit with its container
                var ww = selector.attr('width', $(container).width());
                switch (type) {
                    case 'Line':
                        new Chart(ctx, {type: 'line', data: data, options: options});
                        break;
                    case 'Doughnut':
                        new Chart(ctx, {type: 'doughnut', data: data, options: options});
                        break;
                    case 'Pie':
                        new Chart(ctx, {type: 'pie', data: data, options: options});
                        break;
                    case 'Bar':
                        new Chart(ctx, {type: 'bar', data: data, options: options});
                        break;
                    case 'Radar':
                        new Chart(ctx, {type: 'radar', data: data, options: options});
                        break;
                    case 'PolarArea':
                        new Chart(ctx, {data: data, type: 'polarArea', options: options});
                        break;
                }
                // Initiate new chart or Redraw

            }
            ;
            // run function - render chart at first load
            generateChart();
        },
                //init
                ChartJs.prototype.init = function () {



                    //  xxxxxxxxxxxx Register Patient chart START xxxxxxxxxxxxxxxxxxxxx
                    var pieChart = {
                        labels: [
                            "Molvi Jee",
                            "Naseerullah Khan Baber"
                        ],
                        datasets: [
                            {
                                data: <?php echo $patient_rig; ?>,
                                backgroundColor: [
                                    "#02c58d",
                                    "#f7f25e",
                                    "#ce9bfa",
                                    "#93d9cd",
                                    "#7facfa"
                                ],
                                hoverBackgroundColor: [
                                    "#02c58d",
                                    "#f7f25e"
                                ],
                                hoverBorderColor: "#fff"
                            }]
                    };
                    this.respChart($("#pie"), 'Pie', pieChart);
                    //  xxxxxxxxxxxx Register Patient chart END xxxxxxxxxxxxxxxxxxxxx

                    //  xxxxxxxxxxxx Stock Status chart START xxxxxxxxxxxxxxxxxxxxx
                    var pieChart = {
                        labels: [
                            "Stock Available",
                            "Stock Receive",
                            "Stock Consumption"
                        ],
                        datasets: [
                            {
                                data: <?php echo $stock; ?>,
                                backgroundColor: [
                                    "#107a23",
                                    "#149191",
                                    "#bd0d65"

                                ],
                                hoverBackgroundColor: [
                                     "#107a23",
                                    "#149191",
                                    "#bd0d65"

                                ],
                                hoverBorderColor: "#fff"
                            }]
                    };
                    this.respChart($("#stock"), 'Pie', pieChart);
                    //  xxxxxxxxxxxx Stock Status chart END xxxxxxxxxxxxxxxxxxxxx

                    //  xxxxxxxxxxxx Bar Chart START xxxxxxxxxxxxxxxxxxxxx
//                    var barChart = {
//                        labels: ["Product 1", "Product 2", "Product 3"],
//                        datasets: [
//                            {
//                                label: "Receive",
//                                backgroundColor: "#149191",
//                                borderColor: "#149191",
//                                borderWidth: 1,
//                                hoverBackgroundColor: "#149191",
//                                hoverBorderColor: "#149191",
//                                data: [55, 63, 83]
//                            },
//                             {
//                                label: "Consumption",
//                                backgroundColor: "#bd0d65",
//                                borderColor: "#bd0d65",
//                                borderWidth: 1,
//                                hoverBackgroundColor: "#bd0d65",
//                                hoverBorderColor: "#bd0d65",
//                                data: [35, 47, 33]
//                            },
//                            {
//                                label: "Stock on Hand",
//                                backgroundColor: "#107a23",
//                                borderColor: "#107a23",
//                                borderWidth: 1,
//                                hoverBackgroundColor: "#107a23",
//                                hoverBorderColor: "#107a23",
//                                data: [80, 50, 20,4]
//                            }
//                        ]
//                    };
//                    this.respChart($("#bar"), 'Bar', barChart);
                    //  xxxxxxxxxxxx Bar chart END xxxxxxxxxxxxxxxxxxxxx

                    //  xxxxxxxxxxxx Usage chart START xxxxxxxxxxxxxxxxxxxxx
                    var donutChart = {
                        labels: [
                            "Receive Tansaction",
                            "Issue Tansaction"
                        ],
                        datasets: [
                            {
                                data: <?php echo $transaction; ?>,
                                backgroundColor: [
                                    "#f7b843",
                                    "#fa8039",
                                    "#f0f4f7"
                                ],
                                hoverBackgroundColor: [
                                    "#f7b843",
                                    "#fa8039",
                                    "#f0f4f7"
                                ],
                                hoverBorderColor: "#fff"
                            }]
                    };
                    this.respChart($("#doughnut"), 'Doughnut', donutChart);
                    //  xxxxxxxxxxxx Usage chart END xxxxxxxxxxxxxxxxxxxxx 

                    //  xxxxxxxxxxxx Product Register chart START xxxxxxxxxxxxxxxxxxxxx
                    var donutChart = {
                        labels: [
                            "Molvi Jee",
                            "Naseerullah Khan Baber"
                        ],
                        datasets: [
                            {
                                data: <?php echo $product; ?>,
                                backgroundColor: [
                                    "#7facfa",
                                    "#ce9bfa",
                                    "#30419b",
                                    "#f0f4f7"
                                ],
                                hoverBackgroundColor: [
                                    "#7facfa",
                                    "#ce9bfa",
                                    "#30419b",
                                    "#f0f4f7"
                                ],
                                hoverBorderColor: "#fff"
                            }]
                    };
                    this.respChart($("#doughnut1"), 'Doughnut', donutChart);
                    //  xxxxxxxxxxxx Product Register chart END xxxxxxxxxxxxxxxxxxxxx

                    //radar chart


                },
                $.ChartJs = new ChartJs, $.ChartJs.Constructor = ChartJs

    }(window.jQuery),
//initializing
            function ($) {
                "use strict";
                $.ChartJs.init()
            }(window.jQuery);

</script>