<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12">
                    <!-- Breadcrumb -->
                    
                    <div class="separator bottom"></div>
                   
                    <div class="heading-buttons">
                        <h3>BI Tool</h3>
                        
                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        
                    <iframe src="<?php echo base_url('/pivot/index.php'); ?>" height="500" width="100%" title="Bi Tool" style="border: 0px;"></iframe> 
                        
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>