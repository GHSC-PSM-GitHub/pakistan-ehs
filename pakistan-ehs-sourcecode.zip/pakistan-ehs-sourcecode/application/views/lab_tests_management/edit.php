<?php
//        echo '<pre>'; 
//        print_r($detail_data);
//        echo '</pre>';
//        exit;
?>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <?php
                    if(empty($detail_data))
                    {
                    ?>
                    <div class="heading-buttons">
                        <h3>Lab Test</h3>

                    </div> 
                    <form method="post" id="add_form" name="add_form" action="<?php echo base_url("Lab_tests_management/create_master"); ?>">
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="form-group row"> 
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">ID / Code</label>
                                                <div class="controls">
                                                    <input class="form-control" id="code" name="code" value="<?= $result['code'] ?>" type="text" required="true"/>
                                                </div> 
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Test Name</label>
                                                <div class="controls">
                                                    <input class="form-control" id="" name="name" value="<?= $result['name'] ?>" type="text" required="true"/>
                                                </div> 
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Description</label>
                                                <div class="controls">
                                                    <input class="form-control" id="" name="description" value="<?= $result['description'] ?>" type="text" />
                                                </div> 
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Department</label>
                                                <div class="controls">
                                                    <?php echo create_combo("lab_type_id", $lab_types, $result['department_id']); ?>
                                                </div> 
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Comments</label>
                                                <div class="controls">
                                                    <input class="form-control" id="" name="comments" value="<?= $result['comments'] ?>" type="text" />
                                                </div> 
                                            </div>

                                            <div class="col-md-2" style="margin-top:3%;">
                                                <input type="hidden" name="master_id" value="<?= $result['pk_id'] ?>">
                                                <input type="hidden" name="update" value="yes">
                                                <button type="submit" class="btn btn-primary waves-effect waves-light">
                                                    Update
                                                </button>
                                                <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                    Reset
                                                </button>
                                            </div>
                                        </div> 
                                    </div>



                                </div>
                            </div>
                        </div>
                    </form> 

                    <?php
                    }
                    ?>
                    
                    <div class="col-sm-12" id="div_add_item" style="<?= (!empty($detail_data)) ? '' : 'display:none;'; ?>"> 
                        <div class="separator bottom"></div>

                        <div id="head3" class="heading-buttons">
                            <h3>Lab Test - <?= (!empty($detail_data)) ? 'Edit' : 'Add New'; ?> List Items</h3>

                        </div> 
                        <form method="post" id="list_form" name="list_form" action="<?php echo base_url("Lab_tests_management/create_list_item"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row"> 
                                                <?php
                                                $test_name = '';
                                                $unit = '';
                                                $sample_type_id = '';

                                                $ref_g_min = '';
                                                $ref_g_max = '';

                                                $ref_m_min = '';
                                                $ref_m_max = '';

                                                $ref_f_min = '';
                                                $ref_f_max = '';
                                                if (!empty($detail_data)) {

                                                    $test_name = $detail_data['test_name'];
                                                    $unit = $detail_data['unit'];
                                                    $sample_type_id = $detail_data['sample_type_id'];

                                                    $ref_g_min = $detail_data['ref_range_min_general'];
                                                    $ref_g_max = $detail_data['ref_range_max_general'];

                                                    $ref_m_min = $detail_data['ref_range_min_male'];
                                                    $ref_m_max = $detail_data['ref_range_max_male'];

                                                    $ref_f_min = $detail_data['ref_range_min_female'];
                                                    $ref_f_max = $detail_data['ref_range_max_female'];
                                                }
                                                ?> 
                                                <div class="card-body">
                                                    <div class="form-group row">  
                                                        <div class="col-md-4">
                                                            <label for="example-text-input" class="col-form-label">Test Name</label>
                                                            <div class="controls">
                                                                <input class="form-control" id="test_name" name="test_name" value="<?= $test_name ?>" type="text" required="" placeholder="Hb Test"/>
                                                            </div> 
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label for="example-text-input" class="col-form-label">Unit of Measure</label>
                                                            <div class="controls">
                                                                <input class="form-control" id="unit" name="unit" value="<?= $unit ?>" type="text" required="" placeholder="Unit of measure i.e. g/dl"/>
                                                            </div> 
                                                        </div>
                                                        <div class="col-md-4"> 
                                                            <label for="example-text-input" class="col-form-label">Type of Sample</label>

                                                            <div class="controls">
                                                                <select class="form-control" id="sample_type_id" name="sample_type_id" required="true">
                                                                    <option value="1">Blood</option>
                                                                    <option value="2">Urine</option>
                                                                </select>
                                                            </div>
                                                        </div> 
                                                        <div class="col-md-12"></div>
                                                        <div class="col-md-12">
                                                            <table class="table table-bordered table-condensed">
                                                                <tr>
                                                                    <td></td>
                                                                    <td>Reference Range - Min</td>
                                                                    <td>Reference Range - Max</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>General Range</td>
                                                                    <td><input class="form-control" id="ref_g_min" name="ref_g_min" value="<?= $ref_g_min ?>" type="text"  placeholder="Ref Range Min ( All Genders )"/></td>
                                                                    <td><input class="form-control" id="ref_g_max" name="ref_g_max" value="<?= $ref_g_max ?>" type="text"  placeholder="Ref Range Max ( All Genders )"/></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Specific for Male ( If Any ) </td>
                                                                    <td><input class="form-control" id="" name="ref_m_min" value="<?= $ref_m_min ?>" type="text"  placeholder="Ref Range Min for Male"/></td>
                                                                    <td><input class="form-control" id="" name="ref_m_max" value="<?= $ref_m_max ?>" type="text"  placeholder="Ref Range Max for Male"/></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Specific for Female ( If Any ) </td>
                                                                    <td><input class="form-control" id="" name="ref_f_min" value="<?= $ref_f_min ?>" type="text"  placeholder="Ref Range Min for Female"/></td>
                                                                    <td><input class="form-control" id="" name="ref_f_max" value="<?= $ref_f_max ?>" type="text"  placeholder="Ref Range Max for Female"/></td>
                                                                </tr>
                                                            </table>
                                                        </div>

                                                        <div class="col-md-2" style="margin-top:3%;">
                                                            <input type="hidden" name="master_id" value="<?= $result['pk_id'] ?>">
                                                            <input type="hidden" name="detail_id" value="<?=(!empty($detail_data)?$detail_data['pk_id']:'')?>">
                                                            <input type="hidden" name="update" value="<?=(!empty($detail_data)?'yes':'no')?>">
                                                            <button type="submit" class="btn btn-primary waves-effect waves-light">
                                                                Save
                                                            </button>
                                                        </div>
                                                    </div> 
                                                </div>

                                            </div> 
                                        </div>



                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>


                     <?php
                    if(empty($detail_data))
                    {
                    ?>
                    <div class="col-sm-12"> 
                        <div class="separator bottom"></div>

                        <div class=" row">
                            <h3>Lab Test - List Items</h3>
                            <div id="btn_add_item" class="btn btn-success"><i class="fa fa-plus"></i> Create List Item</div>

                        </div> 
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="form-group row"> 
                                            <table class="table table-bordered table-condensed table-striped">
                                                <tr>
                                                    <td rowspan="3">#</td>
                                                    <td rowspan="3" align="center">Test Name</td>
                                                    <td rowspan="3" align="center">Unit of Measure</td>
                                                    <td rowspan="3" align="center">Sample Type</td>
                                                    <td colspan="6" align="center">Reference Range</td>
                                                    <td rowspan="3">Actions</td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2" align="center">General</td>
                                                    <td colspan="2" align="center">Male (if any)</td>
                                                    <td colspan="2" align="center">Female (if any)</td>
                                                </tr>
                                                <tr>
                                                    <td align="center">Min</td>
                                                    <td align="center">Max</td>
                                                    <td align="center">Min</td>
                                                    <td align="center">Max</td>
                                                    <td align="center">Min</td>
                                                    <td align="center">Max</td>
                                                </tr>
<?php
$c = 1;
if(!empty($list_items)){
    foreach ($list_items as $k => $row) {
        ?>
                                                        <tr>
                                                            <td><?= $c++ ?></td>
                                                            <td><?= $row['test_name'] ?></td>
                                                            <td><?= $row['unit'] ?></td>
                                                            <td><?= $row['sample_type_name'] ?></td>
                                                            <td><?= $row['ref_range_min_general'] ?></td>
                                                            <td><?= $row['ref_range_max_general'] ?></td>
                                                            <td><?= $row['ref_range_min_male'] ?></td>
                                                            <td><?= $row['ref_range_max_male'] ?></td>
                                                            <td><?= $row['ref_range_min_female'] ?></td>
                                                            <td><?= $row['ref_range_max_female'] ?></td>
                                                            <td><a class="btn btn-sm btn-info" href="<?= base_url("Lab_tests_management/edit/" . $row['lab_test_master_id'] . "/" . $row['pk_id']) ?>"><i class="far fa-edit"></i> Edit</a></td>
                                                        </tr>

        <?php
    }
}
?>
                                            </table>
                                        </div> 
                                    </div>



                                </div>
                            </div>
                        </div>
                    </div>
                     <?php
                    }
                    ?>
                </div> 
            </div>
        </div>
    </div>
</div>

