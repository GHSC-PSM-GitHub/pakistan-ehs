 
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Add New Lab Test</h3>
                    </div>
                    <form method="post" id="add_form" name="add_form" action="<?php echo base_url("Lab_tests_management/create_master");?>">
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="form-group row"> 
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">ID / Code</label>
                                                <div class="controls">
                                                    <input class="form-control" id="code" name="code" value="" type="text" required="true"/>
                                                </div> 
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Test Name</label>
                                                <div class="controls">
                                                    <input class="form-control" id="name" name="name" value="" type="text" required="true"/>
                                                </div> 
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Description</label>
                                                <div class="controls">
                                                    <input class="form-control" id="description" name="description" value="" type="text" />
                                                </div> 
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Department</label>
                                                <div class="controls">
                                                <?php echo create_list_combo("lab_type_id", 19, @$form['lab_type_id']); ?>
                                                </div> 
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Comments</label>
                                                <div class="controls">
                                                    <input class="form-control" id="comments" name="comments" value="" type="text" />
                                                </div> 
                                            </div>
                                             
                                            <div class="col-md-2" style="margin-top:3%;">
                                                <button type="submit" class="btn btn-primary waves-effect waves-light">
                                                    Submit
                                                </button>
                                                <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                    Reset
                                                </button>
                                            </div>
                                        </div> 
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div> 
        </div>
    </div>