<?php
if (isset($result)) {

//    $row = $result->result_array();
    $row = $result[0];
    $hf_name = $row['warehouse_name'];
    $category_id = $row['category_id'];
    $type_id = $row['facility_type_id'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Funding Source</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="addwarehouse" name="addwarehouse" action="<?php echo base_url("Warehouse_management/add_funding_source"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row">

                                                <div class="col-md-3" style="display:none">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="category"  >Category<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="category" id="category"  style="width:100%;padding:10%;">
                                                                <option value="7" selected>Supplier</option>
                                                               
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="type"  >Category<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="type" id="type" required readonly style="width:100%;padding:10%;">
                                                                <option value="5">Funding Source</option>                                                              
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div> 
 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf_name"   > Full Name<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="hf_name" id="hf_name" class="form-control" required 
                                                            <?php
                                                            if (isset($result)) {
                                                                echo 'value="' . $hf_name . '"';
                                                            }
                                                            ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                    if (isset($result))
                                                        echo 'value="edit"';
                                                    ?>>
                                                        <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 
                                                <?php if (isset($result)) {
                                                    ?>
                                                    <input type="hidden" id="wh_id" name="wh_id" value="<?php if (isset($result)) echo $_REQUEST['id'] ?>">
                                                <?php } ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                        </form>

                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>