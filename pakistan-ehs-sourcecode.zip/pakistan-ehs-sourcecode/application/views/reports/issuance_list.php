<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12">
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <!-- // Heading END -->
                    <h3>Issuance Report</h3>
                    <div class="innerLR">
                    <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <form action="" method="post">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="example-text-input" required>Product / Item<span style="color: red">*</span> </label>
                                    <div class="controls">
                                        <select class="select2me input-medium" name="product" id="product" required style="width:100%;padding:10%;">
                                            <option value="">Select</option>
                                            <?php
                                            foreach ($product as $row) {
                                            ?>
                                                <option value="<?php echo $row['item_id'] ?>" <?php if (isset($product_id) && $product_id == $row['item_id']) echo "selected='selected'"; ?>><?php echo $row['product_name'] ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label>From Date</label>
                                    <div class="controls">
                                        <input class="form-control" type="text" name="from_date" id="from_date">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label>To Date</label>
                                    <div class="controls">
                                        <input class="form-control" type="text" name="to_date" id="to_date">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="example-text-input">&nbsp;</label>
                                    <div class="controls">
                                        <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light"> Find</button>
                                    </div>
                                </div>
                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <br>


                                        <div id="divToPrint">
                                            <table id="datatable-buttons" class="table table-striped table-bordered table-condensed dt-responsive nowrap">
                                                <thead>
                                                    <tr>
                                                        <td>#</td>
                                                        <td>Issuance Number</td>
                                                        <td>From</td>
                                                        <td>To</td>
                                                        <td>Issuance Date</td>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <?php
                                                    $c = 1;
                                                    if (!empty($list))
                                                        foreach ($list as $k => $row) {
                                                            echo '<tr>';
                                                            echo '<td>' . $c++ . '</td>';
                                                            echo '<td><a target="_blank" href="transaction_detail/' . $row['pk_id'] . '">I-' . sprintf('%04d', $row['pk_id']) . '</a></td>';
                                                            echo '<td>' . $row['wh_from'] . '</td>';
                                                            echo '<td>' . ((!empty($row['issuance_to']) && $row['issuance_to'] == 'patients') ? $row['full_name'] . '-' . $row['nic_no'] : $row['wh_to']) . '</td>';
                                                            echo '<td>' . $row['transaction_date'] . '</td>';
                                                            echo '</tr>';
                                                        }
                                                    ?>

                                                </tbody>
                                            </table>
                                        </div>


                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>