<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12">
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Daily Report</h3>
                      
                        <div class="clearfix"></div>
                        <br>
                    </div>
                    <div class="separator bottom"></div>
                    <div class="innerLR">
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <br>
                                        <?php
                                        if (!empty($report)) {
                                            ?>

                                            <div id="divToPrint">
                                                <table
                                                    class="table table-striped table-bordered table-condensed dt-responsive "
                                                    id="datatable-buttons">
                                                    <thead>
                                                        <tr>


                                                            <th>Sr#</th> 
                                                            <th>Trans Date</th>
                                                            <th>Trans Type</th>
                                                            <th>Hospital</th> 
                                                            <th>Username</th>
                                                            <th>Designation</th>
                                                            <th>Email</th>
                                                            <th>Phone No</th>
                                                            <th>No of Entries</th>

                                  <!--<th style="width:100px;"></th>-->
                                  <!--<th></th>-->
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <!-- Table row -->
                                                        <?php
                                                        $count = 1;
//        echo '<pre>';
//        print_r($result->result_array());
//        exit;
                                                        foreach ($report as $k => $val) {
                                                            ?>
                                                            <tr>
                                                                <td class="center"><?php echo $count; ?></td>
                                                                <td class="important"><?php echo $report[$k]['transaction_date']; ?></td>
                                                                <td class="important"><?php echo $report[$k]['trans_type']; ?></td>
                                                                <td class="important"><?php echo $report[$k]['hospital']; ?></td>
                                                                <td class="important"><?php echo $report[$k]['username']; ?></td>
                                                                <td class="important"><?php echo $report[$k]['designation']; ?></td>
                                                                <td class="important"><?php echo $report[$k]['email']; ?></td>
                                                                <td class="important"><?php echo $report[$k]['phone']; ?></td>
                                                                <td class="important"><?php echo $report[$k]['total']; ?></td>
                                                            </tr>
                                                            <?php
                                                            $count++;
                                                        }
                                                        ?>
                                                        <!-- // Table row END -->
                                                        <!-- Table row -->

                                                        <!-- // Table row END -->
                                                    </tbody>
                                                </table>
                                            </div>

                                            <!-- // Table END -->
                                            <?php
                                        } else {
                                            echo "<hr><h5>No data found!</h5>";
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>