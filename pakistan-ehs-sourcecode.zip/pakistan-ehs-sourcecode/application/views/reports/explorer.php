<?php
$product_id ='';
$from_date = date("m/01/Y");
$to_date = date("m/d/Y");

if(!empty($_POST)){
    $product_id = $_POST['product'];
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];
}
?>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">IM Explorer</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Reports</a></li>
                        <li class="breadcrumb-item active">Explorer</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <form action="" method="post">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="example-text-input" required>Product / Item<span style="color: red">*</span> </label>
                                    <div class="controls">
                                        <select class="select2me input-medium" name="product" id="product" style="width:100%;padding:10%;">
                                            <option value="">All</option>
                                            <?php
                                            foreach ($product as $row) {
                                            ?>
                                                <option value="<?php echo $row['item_id'] ?>" <?php if (isset($product_id) && $product_id == $row['item_id']) echo "selected='selected'"; ?>><?php echo $row['product_name'] ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label>From Date <span style="color: red">*</span></label>
                                    <div class="controls">
                                        <input class="form-control" type="text" required name="from_date" id="from_date" value="<?php echo $from_date; ?>">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label>To Date <span style="color: red">*</span></label>
                                    <div class="controls">
                                        <input class="form-control" type="text" required name="to_date" id="to_date" value="<?php echo $to_date; ?>">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="example-text-input">&nbsp;</label>
                                    <div class="controls">
                                        <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light"> Find</button>
                                    </div>
                                </div>
                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    
                    <div class="card-body">
                        <table id="datatable-buttons"id="datatable-buttons" class="table table-striped table-bordered table-condensed dt-responsive">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th class="col-md-3">Store</th>
                                    <th class="col-md-3">Product</th>
                                    <th class="col-md-2">Opening Balance</th>
                                    <th class="col-md-2">Received</th>
                                    <th class="col-md-2">Issued</th>
                                    <th class="col-md-2">Closing Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $wh_name = '';
                                $count = 1;
                                foreach ($list as $k => $row) {

                                    
                                ?>


                                    <tr>
                                        <td><?php echo $count; ?></td>
                                        <td><?php echo $row['warehouse_name']; ?></td>
                                        <td><?php echo $row['product']; ?></td>
                                        <td><?php echo number_format($row['ob']); ?></td>
                                        <td><?php echo number_format($row['rcv']); ?></td>
                                        <td><?php echo number_format($row['isd']); ?></td>
                                        <td><?php echo number_format($row['cb']); ?></td>
                                    </tr>
                                <?php $count++;
                                } ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>