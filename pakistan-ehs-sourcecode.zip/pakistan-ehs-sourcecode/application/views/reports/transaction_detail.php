<?php
$batch_data = array();
foreach($list as $k=> $row){
    $batch_data['trans_type'] = $row['trans_type'];
    $batch_data['trans_no'] = $row['trans_no'];
    $batch_data['transaction_date'] = $row['transaction_date'];
    $batch_data['transaction_reference'] = $row['transaction_reference'];
    $batch_data['wh_from'] = $row['wh_from'];
    $batch_data['wh_to'] = $row['wh_to'];
    $batch_data['patient_name'] = $row['patient_name'];
    $batch_data['issuance_to'] = $row['issuance_to'];
    $batch_data['remarks'] = $row['remarks'];
    $batch_data['transaction_type_id'] = $row['transaction_type_id'];
    
    
    
    if($row['transaction_type_id'] == 1) $tr_prefix='R';
    elseif($row['transaction_type_id'] == 2) $tr_prefix='I';
    else $tr_prefix='A';
    $tr_number = $tr_prefix.'-'.sprintf('%04d', $batch_data['trans_no']);
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Transaction Number : <?=$tr_number?></h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Reports</a></li>
                        <li class="breadcrumb-item active">Batch History</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                        <div class="card-body">
            
            </div>
                    
                    <div class="card-body">
   
                        <table  id=""  class="table table-striped table-bordered table-condensed">
                            <thead>
                                <tr><td width="25%"><h6>Transaction Type</h6></td>    <td><?=$batch_data['trans_type']?></td><td><h6>Transaction Number</h6></td>   <td><?=$tr_number?></td></tr>
                                <tr><td><h6>Transaction Date</h6></td>    <td><?=$batch_data['transaction_date']?></td><td><h6>Reference</h6></td>   <td><?=$batch_data['transaction_reference']?></td></tr>
                                <tr><td><h6>From</h6></td>   <td><?=$batch_data['wh_from']?></td><td><h6>To</h6></td>  <td><?=((!empty($batch_data['issuance_to'])&& $batch_data['issuance_to'] == 'patients')?$batch_data['patient_name']:$batch_data['wh_to'])?></td></tr>
                            </thead>
                        </table>
                        <table  id="datatable-buttonsx"  class="table table-striped table-bordered table-condensed">
                            <thead>
                            <tr>
                                <td>#</td>
                                <td>Product</td>
                                <td>Batch</td>
                                <td>Expiry</td>
                                <td>Quantity</td>
                                <?php
                                if($batch_data['transaction_type_id'] == '2' && $batch_data['issuance_to'] == 'patients')
                                {
                                ?>
                                <td>Empty Vials Returned</td>
                                <?php
                                }
                                ?>
                            </tr>
                            </thead>
                            <tbody>
                        <?php
                        $c=1;
                        foreach($list as $k=> $row){
                        
                            echo '<tr>';
                            echo '<td>'.$c++.'</td>';
                            echo '<td>'.$row['product_name'].'</td>'; 
                            echo '<td>'.$row['batch_number'].'</td>'; 
                            echo '<td>'.$row['batch_expiry'].'</td>'; 
                            echo '<td align="right">'.number_format(abs($row['quantity'])).'</td>';
                            if($batch_data['transaction_type_id'] == '2' && $batch_data['issuance_to'] == 'patients')
                            {
                                echo '<td align="right">'.number_format($row['vials_returned']).'</td>';
                            }
                            echo '</tr>';
                        }
                        ?>
                            </tbody>
                        </table>
                    </div>
        </div>
        </div>
        </div>
        </div>
        </div>