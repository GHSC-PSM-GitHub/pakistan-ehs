<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Lab Worker Report</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url("/dashboard/lab_supervisor"); ?>">Back to Dashboard</a></li>
                        <li class="breadcrumb-item active">Lab Worker</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- START ROW -->
        <?php if(!empty($pending)) { ?>
        <div class="row">
            <div class="col-xl-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title mb-4">Pending Tests</h4>
                        <div class="table-responsive">
                            
                            <?php echo start_table("lab_supervisor", array("S.No", "Patient Name", "Test Name", "Sample Type", "Sample Date", "Actions")); ?>
                            
                            <?php $count = 1; foreach ($pending->result_object() as $row) { ?>
                            <tr>
                                <td><?php echo $count; ?></td>
                                <td><?php echo $row->patient_name; ?></td>
                                <td><?php echo $row->code."-".$row->name; ?></td>
                                <td><?php echo $row->type_name; ?></td>
                                <td><?php echo convert_date($row->sample_datetime,'toview'); ?></td>
                                <td>
                                    
                                    <!--<button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".lab-detail" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-lab">Lab Detail</button>-->
                                    <button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".patient-detail" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-patient">Update Results</button>
                                    <a href="<?php echo base_url('patients/history?p_id='.$row->patient_id); ?>" target="_blank"><button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-patient">Patient History</button></a>
                                    
                                </td>
                            </tr>
                            <?php $count++; }  ?>

                            <?php echo end_table(); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
        <!-- END ROW -->
<?php if(!empty($completed)) { ?>
        <div class="row">
            <div class="col-xl-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title mb-4">Completed Results</h4>
                        <div class="table-responsive">
                            
                            <?php echo start_table("lab_supervisor", array("S.No", "Patient Name", "Test Name", "Sample Type", "Sample Date", "Actions")); ?>
                            
                            <?php $count = 1; foreach ($completed->result_object() as $row) { ?>
                            <tr>
                                <td><?php echo $count; ?></td>
                                <td><?php echo $row->patient_name; ?></td>
                                <td><?php echo $row->code."-".$row->name; ?></td>
                                <td><?php echo $row->type_name; ?></td>
                                <td><?php echo convert_date($row->sample_datetime,'toview'); ?></td>
                                <td>
                                    
                                    <!--<button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".lab-detail" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-lab">Lab Detail</button>-->
                                    <a href="<?php echo base_url('patients/history?p_id='.$row->patient_id); ?>" target="_blank"><button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-patient">Patient History</button></a>
                                    
                                </td>
                            </tr>
                            <?php $count++; }  ?>

                            <?php echo end_table(); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
        <?php } ?>

    </div>
    <!-- end container-fluid -->
</div>
<!-- end wrapper -->
<div class="modal fade lab-detail" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myLargeModalLabel">Lab Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body" id="lab_result">
                Loading...
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>

<div class="modal fade patient-detail" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myLargeModalLabel">Patient Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body" id="patient_result">
            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="invoice-title">
                                        <h4 class="float-right font-16"><strong>Mr # <?php echo date("ymd-his");?></strong></h4>
                                        <h3 class="m-t-0">
                                            <img src="assets/images/logo-dark.png" alt="logo" height="24">
                                        </h3>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-6">
                                            <address>
                                                <strong>Patient Name:</strong><br>
                                                Ajmal Hussain<br>
                                                Islamabad<br>
                                                Soan Garden<br>
                                                ST 7, B Block<br>
                                                Mobile: 03339652360
                                            </address>
                                        </div>
                                        <div class="col-6 text-right">
                                            <address>
                                                <strong>Emergency Contact:</strong><br>
                                                Kenny Rigdon<br>
                                                1234 Main<br>
                                                Apt. 4B<br>
                                                Springfield, ST 54321<br>
                                                Mobile: 03339652360
                                            </address>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <div class="panel panel-default">
                                        <div class="p-2">
                                            <h3 class="panel-title font-20"><strong>MU01-(01909-1)-Urine R/E</strong></h3>
                                        </div>
                                        <div class="">
                                            <div class="table-responsive">
                                            <?php echo start_table("lab_supervisor", array("S.No", "Investigation", "Result Date", "Patient Value","Normal Range","Comments")); ?>
                                                <tr>
                                                <td>1</td>
                                <td>ESR</td>
                                <td><?php echo date("d/m/Y h:i:s");?></td>
                                <td><input type="text" class="form-control"/></td>
                                <td>0-22 mm/1st hour</td>
                                                <td><input type="text" class="form-control"/></td>
                                                </tr>  
                                                <tr>
                                                <td>2</td>
                                <td>Bicarbonate</td>
                                <td><?php echo date("d/m/Y h:i:s");?></td>
                                <td><input type="text" class="form-control"/></td>
                                <td>22-28 meg/L</td>
                                <td><input type="text" class="form-control"/></td></tr>     
                                                <tr>
                                                <td>3</td>
                                <td>White cell count</td>
                                <td><?php echo date("d/m/Y h:i:s");?></td>
                                <td><input type="text" class="form-control" /></td>
                                <td>4000-11000/cumm</td>
                                <td><input type="text" class="form-control"/></td></tr>                                       
                                            <?php echo end_table(); ?>
                                            </div>

                                            <div class="d-print-none mo-mt-2">
                                                <div class="float-right">
                                                    <a href="javascript:window.print()" class="btn btn-success waves-effect waves-light"><i class="fa fa-print"></i></a>
                                                    <a href="<?php echo base_url("lab/lab_worker_dataentry"); ?>" class="btn btn-primary waves-effect waves-light">Save</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div> <!-- end row -->

                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>

<div class="modal fade approve_assign" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myLargeModalLabel">Approve and Assign</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body" id="assign_to_result">
                Loading...
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>