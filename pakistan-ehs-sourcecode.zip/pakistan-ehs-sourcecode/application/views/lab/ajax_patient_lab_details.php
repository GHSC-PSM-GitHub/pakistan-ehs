<?php
$result = $data->result_object();
?>
<div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="invoice-title">
                                        <h4 class="float-right font-16"><strong>Mr # <?php echo $result[0]->mr_no; ?></strong></h4>
                                        <h3 class="m-t-0">
                                            <img src="assets/images/logo-dark.png" alt="logo" height="24">
                                        </h3>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-6">
                                            <address>
                                                <strong>Patient Name:</strong><br>
                                                <?php echo $result[0]->full_name; ?><br>
                                                <?php echo $result[0]->address; ?>
                                                Mobile: <?php echo $result[0]->mobile_no; ?>
                                            </address>
                                        </div>
                                        <div class="col-6 text-right">
                                            <address>
                                                <strong>Emergency Contact:</strong><br>
                                                Kenny Rigdon<br>
                                                1234 Main<br>
                                                Apt. 4B<br>
                                                Springfield, ST 54321<br>
                                                Mobile: 03339652360
                                            </address>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <form action="" method="post">
                            <div class="row">
                                <div class="col-12">
                                    <div class="panel panel-default">
                                        <div class="p-2">
                                            <h3 class="panel-title font-20"><strong><?php echo $result[0]->name; ?></strong></h3>
                                        </div>
                                        <div class="">
                                            <div class="table-responsive">
                                            <?php echo start_table("lab_supervisor", array("S.No", "Investigation", "Result Date", "Patient Value","Normal Range","Comments")); ?>
                                            <?php $count = 1; foreach ($result as $row){ 
                                                
                                                ?>    
                                            <tr>
                                                <td><?php echo $count; ?></td>
                                                <td><?php echo $row->test_name; ?></td>
                                                <td><?php echo date("d/m/Y h:i:s");?></td>
                                                <td><input type="text" name="pval[<?php echo $row->patient_id; ?>][<?php echo $row->patient_lab_master_id; ?>][<?php echo $row->lab_test_master_id; ?>][<?php echo $row->lab_test_detail_id?>]" class="form-control"/></td>
                                                <td>General: <?php echo $row->ref_range_min_general; ?>-<?php echo $row->ref_range_max_general; ?> <?php echo $row->unit; ?><br>
                                                Male: <?php echo $row->ref_range_min_male; ?>-<?php echo $row->ref_range_max_male; ?> <?php echo $row->unit; ?><br>
                                                Female: <?php echo $row->ref_range_min_female; ?>-<?php echo $row->ref_range_max_female; ?> <?php echo $row->unit; ?><br>
                                                </td>
                                                <td><input type="text" name="comments[<?php echo $row->patient_id; ?>][<?php echo $row->patient_lab_master_id; ?>][<?php echo $row->lab_test_master_id; ?>][<?php echo $row->lab_test_detail_id?>]" class="form-control"/></td>
                                            </tr>
                                            <?php $count++; } ?>                                      
                                            <?php echo end_table(); ?>
                                            </div>

                                            <div class="d-print-none mo-mt-2">
                                                <div class="float-right">
                                                    <a href="javascript:window.print()" class="btn btn-success waves-effect waves-light"><i class="fa fa-print"></i></a>
                                                    <button type="submit" class="btn btn-primary waves-effect waves-light">Save</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div> <!-- end row -->
                            </form>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>