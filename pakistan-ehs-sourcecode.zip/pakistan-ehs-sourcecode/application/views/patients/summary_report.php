<style>
    h2 {
        margin-top: 18px !important;
    }
</style>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Patient Daily Census</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Manage Patients</a></li>
                        <li class="breadcrumb-item active">Report</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">

                        <form name="report" id="report" action="" method="post">
                        
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Patient Status:</label>
    <div class="col-sm-4">
    <?php echo create_list_combo("discharge_reason", 7, @$form['discharge_reason'],''); ?>
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Location:</label>
    <div class="col-sm-4" id="facility_div">
    <?php echo create_combo("facility", $rooms, @$form['facility'],''); ?>
    </div>
</div>

                            <div class="form-group row m-b-0">
                            <label for="example-search-input" class="col-sm-2 col-form-label">Search By:</label>
    <div class="col-sm-4">
    <?php 
    $all_fields = array(
        'full_name' => 'Name',
'mr_no' => 'Mr#',
'date_of_birth' => 'Date of birth',
'marital_status' => 'Marital status',
'gender' => 'Gender',
'nic_no' => 'Nic no',
'address' => 'Address',
'city' => 'City',
'mobile_no' => 'Mobile no',
'status' => 'status',
'vaccination_status' => 'Vaccination status',
'last_dose_date' => 'Last dose date',
'vaccine_name' => 'Vaccine name',
'covid_status' => 'Covid status',
'oxygen_status' => 'Oxygen status'
    );
    echo create_combo("search_by", $all_fields, @$form['search_by']); ?>
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Enter text:</label>
    <div class="col-sm-4">
        <input type="text" class="form-control" name="search_text" value="<?php echo @$form['search_text']; ?>" />
    </div>

                                 
                            </div>
                            <div class="form-group row m-b-0 right"><div class="col-sm-12">
                                    <button type="submit" class="btn btn-primary waves-effect waves-light" id="btnrdt">
                                        Search
                                    </button>
                                </div></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <?php if (isset($search_result) && !empty($search_result)) {
                            echo start_table("datatable-buttons", array("S.No", "Patient Name", "Age", "Gender", "Mr#", "CNIC#", "City", "Mobile#","DOA","Status")); ?>
                            
                            <?php $count = 1;
                            $wh_name = true;
                            foreach ($search_result->result_object() as $row) { 
                                if($wh_name != $row->wh_name) {
                                    $wh_name = $row->wh_name;
                                ?>
                            <tr><td colspan="11" style="background-color: #e5e5e5; font-weight: bold; text-align: center"><?php echo !empty($row->wh_name) ? $row->wh_name : "Unassigned" ; ?></td></tr>
                            <?php } ?>
                                <tr>
                                    <td><?php echo $count; ?></td>
                                    <td><?php echo $row->full_name; ?></td>
                                    <td><?php echo $row->date_of_birth; ?></td>
                                    <td><?php echo $row->gender; ?></td>
                                    <td><?php echo $row->mr_no; ?></td>
                                    <td><?php echo $row->nic_no; ?></td>
                                    <td><?php echo $row->city; ?></td>
                                    <td><?php echo $row->mobile_no; ?></td>
                                    <td><?php echo $row->created_date; ?></td>
                                    <td><?php echo $row->list_value; ?></td>
                                </tr>
                            <?php $count++;
                            } ?>
                            <?php echo end_table(); ?>


                        <?php } else {
                            echo "<h6>No record found!</h6>";
                        } ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <?php if (isset($search_result) && !empty($search_result)) {
                            $arr_status = array("Positive","Negative","Result Awaited","Ventilator","Bi Pap/C pap","High- Flow","Low- Flow","Room Air");


                            echo start_table("datatable-buttons", array(date("d-m-Y"), "Unit 1 ICU", "Unit 1 Ward", "Unit 2 Ward", "Unit 2 HDU", "Unit 3 Ward", "Unit 3 ICU", "Unit 4 Ward","Unit 4 ICU")); 
                            
                            foreach($arr_status as $val){
                            ?>
                            
                            
                                <tr>
                                    <td><?php echo $val; ?></td>
                                    <td><?php echo rand(0,10); ?></td>
                                    <td><?php echo rand(0,10); ?></td>
                                    <td><?php echo rand(0,10); ?></td>
                                    <td><?php echo rand(0,10); ?></td>
                                    <td><?php echo rand(0,10); ?></td>
                                    <td><?php echo rand(0,10); ?></td>
                                    <td><?php echo rand(0,10); ?></td>
                                    <td><?php echo rand(0,10); ?></td>
                                </tr>
                            <?php }
                             ?>
                            <?php echo end_table(); ?>


                        <?php } else {
                            echo "<h6>No record found!</h6>";
                        } ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <?php if (isset($search_result) && !empty($search_result)) {
                            $arr_status = array("Morning (0700-1500hrs)","Evening (1500-2300hrs)","Night (2300-0700hrs)");


                            echo start_table("datatable-buttons", array("Shift", "Admission", "Discharged", "Lama", "Refer Out", "Expired")); 
                            
                            foreach($arr_status as $val){
                            ?>
                            
                            
                                <tr>
                                    <td><?php echo $val; ?></td>
                                    <td><?php echo rand(0,10); ?></td>
                                    <td><?php echo rand(0,10); ?></td>
                                    <td><?php echo rand(0,10); ?></td>
                                    <td><?php echo rand(0,10); ?></td>
                                    <td><?php echo rand(0,10); ?></td>
                                </tr>
                            <?php }
                             ?>
                            <?php echo end_table(); ?>


                        <?php } else {
                            echo "<h6>No record found!</h6>";
                        } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>