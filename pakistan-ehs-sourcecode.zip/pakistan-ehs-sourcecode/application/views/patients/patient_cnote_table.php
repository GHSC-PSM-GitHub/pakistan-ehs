<?php
echo start_table("datatable-buttons", array("S.No", "Visit Code","Doctor", "Complaints", "Diagnosis","Action")); ?>
<?php $count = 1; foreach ($patient_cnote->result_object() as $row) { ?>
<tr>
    <td><?php echo $count; ?></td>
    <td><?php echo $row->checkup_date; ?></td>
    <td><?php echo $row->full_name; ?></td>
    <td><?php echo $row->notes; ?></td>
    <td><?php echo $row->diagnosis; ?></td>
    
    <td>
        <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deletecnote">
            <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
        </button>
        <!--<button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>-->
    </td>
</tr>
<?php $count++; } ?>
<?php echo end_table(); ?>