<p class="mb-0">
    <?php echo start_form("cnotes"); ?>
<div class="form-group row m-b-0">
    <!--<label for="example-search-input" class="col-sm-2 col-form-label">Visit Code:</label>
    <div class="col-sm-4">
    <?php //echo create_combo("disease_date", $visit_codes); ?>
    </div>-->
    <label for="example-search-input" class="col-sm-2 col-form-label">Doctor Name:</label>
    <div class="col-sm-4">
        <?php echo create_combo("hr_id",$doctors); ?>
    </div>
</div>
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Complaint (Signs / Symptoms):</label>
    <div class="col-sm-10">
        <textarea name="notes" id="notes" cols="80%" rows="10"></textarea>
    </div>
</div>
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Diagnosis:</label>
    <div class="col-sm-10">
        <textarea name="diagnosis" id="diagnosis" cols="80%" rows="10"></textarea>
    </div>

    <input type="hidden" name="patient_id" id="patient_id" value="<?php echo $pk_id; ?>" />
</div>
<div class="row">
    <div class="col-12">
        <div class="form-group">
            <div style="float:right;">
                <button type="button" class="btn btn-dark waves-effect waves-light" id="btncnote">
                    Save
                </button>
                <button type="reset" class="btn btn-warning waves-effect m-l-5">
                    Reset
                </button>
            </div>
        </div>
    </div>
</div>
<?php echo end_form(); ?>
</p>
<p>
<div id="cnote_result">
    <?php
    if (!empty($patient_cnote)) {
        include("patient_cnote_table.php");
    }
    ?>
</div>
</p>