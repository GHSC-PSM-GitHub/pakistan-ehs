<p class="mb-0">
    <?php echo start_form("prescriptions"); ?>
<div class="form-group row">
    <label for="example-text-input" class="col-form-label col-sm-2">Medicine:</label>
    <div class="col-sm-4">
        <?php
        $selected = (!empty($form['medicine']) ? $form['medicine'] : '');
        echo create_combo("medicine", $medicines, $selected); ?>

    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Prescription Quantity:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" id="pres_qty" name="schedule_value">
    </div>
</div>
<div class="form-group row">
    <label for="example-search-input" class="col-sm-2 col-form-label">Quantity Issued:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" id="issued_qty" name="issued_qty">
    </div>
</div>

<!--<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Strength:</label>
    <div class="col-sm-4">
        <select class="form-control" id="strength" name="strength" required>
            <option value="">Select</option>
            <?php $strength = array(1 => "500mg", 2 => "250mg", 3 => "1000mg");
            foreach ($strength as $key => $str) {
                $sel = '';
                if ($form['strength'] == $key) {
                    $sel = "selected=selected";
                }
            ?>
                <option value="<?php echo $str; ?>" <?php echo $sel; ?>><?php echo $str; ?></option>
            <?php
            }
            ?>
        </select>
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Dose:</label>
    <div class="col-sm-4">
        <select class="form-control" id="dose" name="dose" required>
            <option value="">Select</option>
            <?php $doses = array(1 => "One time a day (1)", 2 => "2 times a day (1+1)", 3 => "3 times a day (1+1+1)");
            foreach ($doses as $key => $dose) {
                $sel = '';
                if ($form['doses'] == $key) {
                    $sel = "selected=selected";
                }
            ?>
                <option value="<?php echo $dose; ?>" <?php echo $sel; ?>><?php echo $dose; ?></option>
            <?php
            }
            ?>
        </select>
    </div>
</div>
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Days:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" id="days" name="days">
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Date:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" value="<?php echo date("d/m/Y"); ?>" id="sample_date" name="sample_date">
    </div>

    
</div>
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Schedule Every:</label>
    <div class="col-sm-2">
        <input class="form-control" type="text" id="schedule_value" name="schedule_value">
    </div>
    <div class="col-sm-2">
        <?php echo create_combo("schedule_type", array("Second"=>"Second","Minute"=>"Minute","Hour"=>"Hour","Day"=>"Day","Week"=>"Week","Month"=>"Month","Quarter"=>"Quarter","Year"=>"Year")); ?>
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Start date:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" value="<?php echo date("d/m/Y"); ?>" id="start_date" name="start_date">
    </div>
    
   
</div>-->
<div class="row">
    <div class="col-12">
        <div class="form-group">
            <div style="float:right;">
            <input type="hidden" name="patient_id" id="patient_id" value="<?php echo $pk_id; ?>" />
                <button type="button" class="btn btn-dark waves-effect waves-light" id="btnprescription">
                    Save
                </button>
                <button type="reset" class="btn btn-warning waves-effect m-l-5">
                    Reset
                </button>
            </div>
        </div>
    </div>
</div>
<?php echo end_form(); ?>
</p>
<p>
<div id="prescription_result">
    <?php
    if (!empty($patient_prescription)) {
        include("patient_prescription_table.php");
    }
    ?>
</div>
</p>