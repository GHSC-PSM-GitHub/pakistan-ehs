<p class="mb-0">
    <?php echo start_form("labtest"); ?>
<div class="form-group row">
    <label for="example-text-input" class="col-form-label col-sm-2">Lab:</label>
    <div class="col-sm-4">
        <?php echo create_combo("lab_list", $lab_list); ?>

    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Sample Date:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" value="<?php echo date("d/m/Y"); ?>" id="sample_date" name="sample_date">
    </div>

</div>

<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Lab Test Code:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" id="lab_test_code" name="lab_test_code">
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Lab Test Name:</label>
    <div class="col-sm-4" id="lab_test_div">
        <?php //echo create_combo("lab_test", $lab_test); ?>
        <?php echo create_combo("lab_test", array()); ?>
    </div>

</div>
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Sample Collection Type:</label>
    <div class="col-sm-4">
    <?php echo create_list_combo("sample_type", 8, @$form['sample_type']); ?>
    </div>

    <input type="hidden" name="patient_id" id="patient_id" value="<?php echo $pk_id; ?>" />
</div>
<div class="row">
    <div class="col-12">
        <div class="form-group">
            <div style="float:right;">
                <button type="button" class="btn btn-dark waves-effect waves-light" id="btnlabtest">
                    Save
                </button>
                <button type="reset" class="btn btn-warning waves-effect m-l-5">
                    Reset
                </button>
            </div>
        </div>
    </div>
</div>
<?php echo end_form(); ?>
</p>
<p>
<div id="labtest_result">
    <?php
    if (!empty($patient_labtest)) {
        include("lab_test_table.php");
    }
    ?>
</div>
</p>