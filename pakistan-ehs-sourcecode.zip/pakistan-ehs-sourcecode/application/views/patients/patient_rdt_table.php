<?php
echo start_table("datatable-buttons", array("Test Id", "Test Name", "Result", "Date","Action")); ?>
<?php $count = 1; foreach ($data->result_object() as $row) { ?>
<tr>
    <td><?php echo $count; ?></td>
    <td><?php echo $row->rdt_name; ?></td>
    <td><?php echo $row->result; ?></td>
    <td><?php echo convert_date($row->test_date,'toview'); ?></td>
    <td>
        <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-delete">
            <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Delete
        </button>
    </td>
</tr>
<?php $count++; }  ?>
<?php echo end_table();