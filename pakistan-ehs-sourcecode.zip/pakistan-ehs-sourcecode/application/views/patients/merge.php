<style>
    h2 {
        margin-top: 18px !important;
    }
</style>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title"><?php echo $page_title; ?></h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Manage Patients</a></li>
                        <li class="breadcrumb-item active">Search Patient</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <form name="rdt" id="rdt" action="" method="post">
                            <div class="form-group row m-b-0">
                                <label for="example-text-input" class="col-form-label col-sm-2">First EMR No:</label>
                                <div class="col-sm-3">
                                    <div class="input-group">
                                        <input class="form-control" type="text" id="primary_emr" required name="primary_emr" placeholder="Enter EMR No" value="<?php if (isset($form['primary_emr'])) {
                                                                                                                                                                    echo $form['primary_emr'];
                                                                                                                                                                } ?>">
                                    </div>
                                </div>
                                <label for="example-text-input" class="col-form-label col-sm-2">Second EMR No:</label>
                                <div class="col-sm-3">
                                    <div class="input-group">
                                        <input class="form-control" type="text" id="secondary_emr" name="secondary_emr" required placeholder="Enter EMR No" value="<?php if (isset($form['secondary_emr'])) {
                                                                                                                                                                        echo $form['secondary_emr'];
                                                                                                                                                                    } ?>">
                                    </div>
                                </div>

                                <div class="col-sm-2">
                                    <button type="submit" class="btn btn-primary waves-effect waves-light" id="btnrdt">
                                        Search
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <form name="mergeform" id="mergeform" action="" method="post">
                            <?php
                            echo start_table("merge_table", array("Select Primary", "Mr#", "Patient Name", "CNIC#", "Mobile#")); ?>
                            <?php
                            $count = 1;
                            if (isset($primary_emr) && !empty($primary_emr)) {

                                foreach ($primary_emr->result_object() as $row) { ?>
                                    <tr>
                                        <td><input type="radio" name="mergeoption" id="mergeoption" value="<?php echo $row->pk_id; ?>" class="form-control" checked /></td>
                                        <td><?php echo $row->mr_no; ?></td>
                                        <td><?php echo $row->full_name; ?></td>
                                        <!-- <td><?php //echo convert_date($row->admission_date, 'toview'); 
                                                    ?></td> -->
                                        <td><?php echo $row->nic_no; ?></td>
                                        <td><?php echo $row->mobile_no; ?></td>
                                    </tr>
                                    <input type="hidden" name="patient_ids[]" value="<?php echo $row->pk_id; ?>"/>
                                <?php $count++;
                                }
                            }

                            if (isset($secondary_emr) && !empty($secondary_emr)) {
                                foreach ($secondary_emr->result_object() as $row) { ?>
                                    <tr>
                                        <td><input type="radio" name="mergeoption" value="<?php echo $row->pk_id; ?>" id="mergeoption" class="form-control" /></td>
                                        <td><?php echo $row->mr_no; ?></td>
                                        <td><?php echo $row->full_name; ?></td>
                                        <!-- <td><?php //echo convert_date($row->admission_date, 'toview'); 
                                                    ?></td> -->
                                        <td><?php echo $row->nic_no; ?></td>
                                        <td><?php echo $row->mobile_no; ?></td>
                                    </tr>
                                    <input type="hidden" name="patient_ids[]" value="<?php echo $row->pk_id; ?>"/>
                                <?php $count++;
                                }
                            }
                            if ($count == 1) { ?>
                                <tr>
                                    <td colspan="6">No Record Found</td>
                                </tr>
                            <?php } ?>
                            <?php echo end_table(); ?>
                            <?php if ($count > 1) { ?>
                                <button type="button" class="btn btn-info waves-effect waves-light" id="mergebutton">Click here to Merge</button></a>
                            <?php } ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>