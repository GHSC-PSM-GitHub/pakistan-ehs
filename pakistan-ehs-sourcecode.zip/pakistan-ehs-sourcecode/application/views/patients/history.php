<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Patient's History</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Manage Patients</a></li>
                        <li class="breadcrumb-item active">History</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>
        <?php
                                    if(!empty($patient)){
                                        $patient_data = $patient->result_object();
                                    }
                                    ?>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                        <div class="card-body">

                        <div class="row">
                                <div class="col-12">
                                    <div class="invoice-title">
                                        <h4 class="float-right font-16"><img src="<?php echo base_url("assets/barcode/barcode.php.png"); ?>"><br>
                                        <strong> Mr # <?php echo $patient_data[0]->mr_no; ?></strong></h4>
                                        <h3 class="m-t-0">
                                            <img src="<?php echo base_url("assets/images/users/user-1.jpg"); ?>">
                                        </h3>
                                    </div>
                                    <hr>
                                    
                                    <div class="row">
                                        <div class="col-6">
                                            <address>
                                                <strong>Patient Info:</strong><br>
                                                <?php echo $patient_data[0]->full_name; ?><br>
                                                <?php echo $patient_data[0]->date_of_birth; ?><br>
                                                <?php echo $patient_data[0]->address; ?><br>
                                                <?php echo $patient_data[0]->city; ?>
                                            </address>
                                        </div>
                                        <div class="col-6 text-right">
                                            <address>
                                                <strong>Guardian Info:</strong><br>
                                                ----<br>
                                                ----<br>
                                                ----<br>
                                                ----
                                            </address>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6 m-t-30">
                                            <address>
                                                <strong>Additional Info:</strong><br>
                                                c: <?php echo $patient_data[0]->mobile_no; ?>
                                            </address>
                                        </div>
                                        <div class="col-6 m-t-30 text-right">
                                            <address>
                                                <strong>Last Visit Date:</strong><br>
                                                <?php echo $patient_data[0]->created_date; ?><br><br>
                                            </address>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div id="accordion">
                                <div class="card mb-0">
                                    <div class="card-header" id="heading1">
                                        <h5 class="mb-0 mt-0 font-14">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="true" aria-controls="collapse1" class="text-dark">
                                                Rapid Tests History
                                            </a>
                                        </h5>
                                    </div>

                                    <div id="collapse1" class="collapse show" aria-labelledby="heading1" data-parent="#accordion" style="">
                                        <div class="card-body">
                                        <?php
                                        if(!empty($data)){

                                            echo start_table("datatable-buttons", array("Test Id", "Test Name", "Result", "Date")); ?>
                                            <?php 
                                            
                                            $count = 1; foreach ($data->result_object() as $row) { ?>
                                            <tr>
                                                <td><?php echo $count; ?></td>
                                                <td><?php echo $row->rdt_name; ?></td>
                                                <td><?php echo $row->result; ?></td>
                                                <td><?php echo convert_date($row->test_date,'toview'); ?></td>
                                            </tr>
                                            <?php $count++; }  ?>
                                            <?php echo end_table(); 
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="card mb-0">
                                    <div class="card-header" id="heading2">
                                        <h5 class="mb-0 mt-0 font-14">
                                            <a class="text-dark collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse2" aria-expanded="false" aria-controls="collapse2">
                                                Lab Tests History
                                            </a>
                                        </h5>
                                    </div>
                                    <div id="collapse2" class="collapse" aria-labelledby="heading2" data-parent="#accordion" style="">
                                        <div class="card-body">
                                        <?php
                                            echo start_table("datatable-buttons", array("Test Id", "Test Name", "Sample Type", "Sample Date", "Range", "Result")); ?>
                                            <?php if(!empty($patient_labtest)) { $count = 1; foreach ($patient_labtest->result_object() as $row) { ?>
                                            <tr>
                                                <td><?php echo $count; ?></td>
                                                <td><?php echo $row->code."-".$row->test_name; ?></td>
                                                <td><?php echo $row->type_name; ?></td>
                                                <td><?php echo convert_date($row->sample_datetime,'toview'); ?></td>
                                                <td><?php echo $row->ref_range_min_general."-".$row->ref_range_max_general. " ". $row->unit; ?> </td>
                                                <td><?php echo $row->test_result; ?></td>
                                            </tr>
                                            <?php $count++; } } ?>
                                            <?php echo end_table(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="card mb-0">
                                    <div class="card-header" id="heading3">
                                        <h5 class="mb-0 mt-0 font-14">
                                            <a class="text-dark collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse3" aria-expanded="false" aria-controls="collapse3">
                                            Preliminary Examination History
                                            </a>
                                        </h5>
                                    </div>
                                    <div id="collapse3" class="collapse" aria-labelledby="heading3" data-parent="#accordion" style="">
                                        <div class="card-body">
                                        <?php
                                        if(!empty($patient_preexam)){
                                            echo start_table("datatable-buttons", array("S.No","Visit date","Vitals History")); ?>
                                            <?php $count = 1; foreach ($patient_preexam->result_object() as $row) { 
                                                ?>
                                            <tr>
                                                <td><?php echo $count; ?></td>
                                                <td><?php echo convert_date($row->visit_date,'toview'); ?></td>
                                                <td><?php echo $row->ind_values; ?></td>                                                
                                            </tr>
                                            <?php $count++; } ?>
                                            <?php echo end_table(); } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="card mb-0">
                                    <div class="card-header" id="heading4">
                                        <h5 class="mb-0 mt-0 font-14">
                                            <a class="text-dark collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse4" aria-expanded="false" aria-controls="collapse4">
                                                Clinical Notes
                                            </a>
                                        </h5>
                                    </div>
                                    <div id="collapse4" class="collapse" aria-labelledby="heading4" data-parent="#accordion" style="">
                                        <div class="card-body">
                                        <?php
                                        if(!empty($patient_cnote)){
                                            echo start_table("datatable-buttons", array("S.No", "Checkup date","Disease Name", "Additional Notes")); ?>
                                            <?php $count = 1; foreach ($patient_cnote->result_object() as $row) { ?>
                                            <tr>
                                                <td><?php echo $count; ?></td>
                                                <td><?php echo convert_date($row->checkup_date,'toview'); ?></td>
                                                <td><?php echo $row->disease_name; ?></td>
                                                <td><?php echo $row->value; ?></td>
                                               
                                            </tr>
                                            <?php $count++; } ?>
                                            <?php echo end_table(); } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="card mb-0">
                                    <div class="card-header" id="heading5">
                                        <h5 class="mb-0 mt-0 font-14">
                                            <a class="text-dark collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse5" aria-expanded="false" aria-controls="collapse5">
                                                Prescriptions History
                                            </a>
                                        </h5>
                                    </div>
                                    <div id="collapse5" class="collapse" aria-labelledby="heading5" data-parent="#accordion" style="">
                                        <div class="card-body">
                                        <?php
                                            echo start_table("datatable-buttons", array("S.No", "Prescription date","Prescribed By", "Additional Notes", "Action")); ?>
                                            
                                            <tr>
                                                <td>1</td>
                                                <td><?php echo date("d/m/Y"); ?></td>
                                                <td>Dr. Inayatullah Khan</td>
                                                <td>Seasonal Virus</td>
                                                <td><button data-toggle="modal" data-target=".patient-detail" class="btn btn-success waves-effect waves-light"><i class="fa fa-print"></i> Print Prescription</button></td>
                                            </tr>
                                            <?php echo end_table(); ?>

                                            
                                        </div>
                                    </div>
                                </div>
                                
                            </div>

                        </div>
                    </div>
                    </div>
                            </div>
                            <div class="modal fade patient-detail" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myLargeModalLabel">IHITC Islamabad | (051) 9334329 | e: ihitcislamabad@gmail.com</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body" id="patient_result">
            <div class="row">
                <div class="col-12">
            <img class="float-right" src="<?php echo base_url("/assets/barcode/barcode.php.png");?>" />
            </div></div>
            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                        
                            <div class="row">
                                <div class="col-12">
                                
                                    <div class="invoice-title">
                                        <h4 class="float-right font-16"><strong>Patient Mr # <?php echo $patient_data[0]->mr_no; ?><br></strong>
                                        </h4>                                        
                                        <h3 class="m-t-0">
                                        Dr........
                                        </h3>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-6">
                                            <address>
                                                IHITC, Islamabad<br>
                                                Phone: (051) 9334329
                                                Email: ihitcislamabad@gmail.com
                                            </address>
                                        </div>
                                        <div class="col-6 text-right">
                                            <address>
                                                Name: <?php echo $patient_data[0]->full_name; ?><br>
                                                DOB: <?php echo $patient_data[0]->date_of_birth; ?><br>
                                                Address: <?php echo $patient_data[0]->address; ?><br>
                                                City: <?php echo $patient_data[0]->city; ?><br>
                                                Mobile No: <?php echo $patient_data[0]->mobile_no; ?>
                                            </address>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <div class="panel panel-default">
                                    <div class="p-2">
                                            <h3 class="panel-title font-20"><strong>Prescribed Medicines</strong></h3>
                                        </div>
                                    <div class="row">
                                        <div class="col-9">
                                            <div class="table-responsive">
                                            <?php
                                                echo start_table("datatable-buttons", array("S.No", "Medicine","Method","Strength", "Dose","Days")); ?>
                                                <?php if(!empty($patient_prescription)) { $count = 1; foreach ($patient_prescription->result_object() as $row) { ?>
                                                <tr>
                                                    <td><?php echo $count; ?></td>
                                                    <td><?php echo $row->medicine_name; ?></td>
                                                    <td><?php echo $row->method; ?></td>
                                                    <td><?php echo $row->strength; ?></td>
                                                    <td><?php echo $row->dose; ?></td>
                                                    <td><?php echo $row->days; ?></td>
                                                </tr>
                                                <?php $count++; } }  ?>
                                                <?php echo end_table(); ?>
                                            </div>

                                            
                                        </div>
                                        <div class="col-3">                                            
                                            <b class="font-14">Preliminary Examination</b> <br> <br>
                                            
                                            Temprature: 102 F <br>
                                            BP: 80/110 mmgh <br>
                                            Pulse Rate: 50 bpm <br>
                                            <hr>
                                            <b class="font-14">Clinical Notes</b> <br> <br>
                                            
                                           
                                            Fever: Yes <br>                                            
                                            <hr>
                                            <b class="font-14">Lab Test</b> <br> <br>
                                            
                                            Urine: Yes <br>
                                            Blood: Yes <br>
                                        </div>
                                        </div>
                                    </div>

                                </div>
                            </div> <!-- end row -->
                            <div class="d-print-none mo-mt-2">
                                                <div class="float-right">
                                                    <a href="javascript:window.print()" class="btn btn-success waves-effect waves-light"><i class="fa fa-print"></i></a>
                                                   <!-- <a href="<?php //echo base_url("lab/lab_worker_dataentry"); ?>" class="btn btn-primary waves-effect waves-light">Save</a> -->
                                                </div>
                                            </div>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
                        </div>
                    </div>



                    