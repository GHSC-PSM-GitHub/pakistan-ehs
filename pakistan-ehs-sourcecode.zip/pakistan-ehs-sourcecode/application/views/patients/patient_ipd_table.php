<?php
echo start_table("datatable-buttons", array("S.No", "Admitted On","Ward Name", "Additional Notes","Action")); ?>
<?php $count = 1; foreach ($patient_ipd->result_object() as $row) { ?>
<tr>
    <td><?php echo $count; ?></td>
    <td><?php echo convert_date($row->admission_date,'toview'); ?></td>
    <td><?php echo $row->ward_name; ?></td>
    <td><?php echo $row->notes; ?></td>
    
    <td>
        <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deleteipd">
            <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
        </button>
        <!--<button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>-->
    </td>
</tr>
<?php $count++; } ?>
<?php echo end_table(); ?>