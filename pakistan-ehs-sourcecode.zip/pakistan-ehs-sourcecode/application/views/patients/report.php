<style>
    h2 {
        margin-top: 18px !important;
    }
</style>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Patient Detail Report</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Manage Patients</a></li>
                        <li class="breadcrumb-item active">Report</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">

                        <form name="report" id="report" action="" method="post">
                        
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Patient Status:</label>
    <div class="col-sm-4">
    <?php echo create_list_combo("discharge_reason", 7, @$form['discharge_reason'],''); ?>
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Location:</label>
    <div class="col-sm-4" id="facility_div">
    <?php echo create_combo("facility", $rooms, @$form['facility'],''); ?>
    </div>
</div>

                            <div class="form-group row m-b-0">
                            <label for="example-search-input" class="col-sm-2 col-form-label">Search By:</label>
    <div class="col-sm-4">
    <?php 
    $all_fields = array(
        'full_name' => 'Name',
'mr_no' => 'Mr#',
'date_of_birth' => 'Date of birth',
'marital_status' => 'Marital status',
'gender' => 'Gender',
'nic_no' => 'Nic no',
'address' => 'Address',
'city' => 'City',
'mobile_no' => 'Mobile no',
'status' => 'status',
'vaccination_status' => 'Vaccination status',
'last_dose_date' => 'Last dose date',
'vaccine_name' => 'Vaccine name',
'covid_status' => 'Covid status',
'oxygen_status' => 'Oxygen status'
    );
    echo create_combo("search_by", $all_fields, @$form['search_by']); ?>
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Enter text:</label>
    <div class="col-sm-4">
        <input type="text" class="form-control" name="search_text" value="<?php echo @$form['search_text']; ?>" />
    </div>

                                 
                            </div>
                            <div class="form-group row m-b-0 right"><div class="col-sm-12">
                                    <button type="submit" class="btn btn-primary waves-effect waves-light" id="btnrdt">
                                        Search
                                    </button>
                                </div></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <?php if (isset($search_result) && !empty($search_result)) {
                            echo start_table("datatable-buttons", array("S.No", "Patient Name", "Age", "Gender", "Mr#", "CNIC#", "Address", "City", "Mobile#", "Symptoms","Sample Collection", "Result","DOA","DOD","Status")); ?>
                            <?php $count = 1;
                            foreach ($search_result->result_object() as $row) { ?>
                                <tr>
                                    <td><?php echo $count; ?></td>
                                    <td><?php echo $row->full_name; ?></td>
                                    <td><?php echo $row->date_of_birth; ?></td>
                                    <td><?php echo $row->gender; ?></td>
                                    <td><?php echo $row->mr_no; ?></td>
                                    <td><?php echo $row->nic_no; ?></td>
                                    <td><?php echo $row->address; ?></td>
                                    <td><?php echo $row->city; ?></td>
                                    <td><?php echo $row->mobile_no; ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><?php echo $row->created_date; ?></td>
                                    <td><?php echo convert_date($row->date_of_discharge,'toview'); ?></td>
                                    <td><?php echo $row->list_value; ?></td>
                                </tr>
                            <?php $count++;
                            } ?>
                            <?php echo end_table(); ?>


                        <?php } else {
                            echo "<h6>No record found!</h6>";
                        } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>