<p class="mb-0">
    <?php echo start_form("rdt"); ?>
    <div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Test Name:</label>
    <div class="col-sm-4">
        <?php echo create_combo("testname",$rdt_list); ?>
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Result:</label>
    <div class="col-sm-4">
    <?php
        $rslt_list = array(
            'Positive' => 'Positive',
            'Negative' => 'Negative',
            'Error' => 'Error'                                    
        );
        echo create_combo("result",$rslt_list); 
    ?>                                                               
    </div>
    </div>
    <div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Date:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" value="<?php echo date("d/m/Y"); ?>" id="test_date" name="test_date">
    </div>
    
    <input type="hidden" name="patient_id" id="patient_id" value="<?php echo $pk_id; ?>" />        
    </div>
    <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <div style="float:right;">
                                            <button type="button" class="btn btn-dark waves-effect waves-light" id="btnrdt">
                                            Save
                                            </button>
                                            <button type="reset" class="btn btn-warning waves-effect m-l-5">
                                                Reset
                                            </button>
                                        </div>
                                    </div>
                                </div> 
                        </div>
    <?php echo end_form(); ?>
</p>
<p>
    <div id="rdt_result">
    <?php
    if(!empty($patient_rdt)){
        $data = $patient_rdt;
        include("patient_rdt_table.php");
    }
    ?> 
    </div>
</p>