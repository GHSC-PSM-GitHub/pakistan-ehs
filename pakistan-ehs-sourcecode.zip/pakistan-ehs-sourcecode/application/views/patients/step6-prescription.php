<p class="mb-0">
<form method="post" id="prescriptions" name="prescriptions" action="">
    <input type="hidden" name="center_from" id="center_from" value="<?= ($this->session->warehouse_id) ?>" />
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">
                    <!--<div class="form-group row"> 
                                                 
                        <div class="col-md-3">
                            <div class="control-group">
                                <label class="example-text-input" for="hf" required >Date <span style="color: red">*</span> </label>
                                <div class="controls">
                                    <input type="text" class="form-control" name="receiving_time" id="receiving_time" required value="<?php echo date("d/m/Y"); ?>" <?php if (isset($master_id)) echo 'readonly="true"' ?>>

                                </div>
                            </div>
                        </div> 

                        
                        </div>-->
                    <div class="form-group row">
                        <!--<div class="col-md-3">
                            <div class="control-group">
                                <label class="example-text-input" for="visit_code" required id="qty_label">Visit code<span style="color: red">*</span></label>
                                <div class="controls">
                                    <?php //echo create_combo("visit_code", $visit_codes) ?>
                                </div>
                            </div>
                        </div>-->

                        <div class="col-md-3">
                            <label class="example-text-input" required>Item / Product Name<span style="color: red">*</span> </label>
                            <div class="controls">
                                <select class="select2me input-medium" name="product" id="product" required style="width:100%;padding:10%;">
                                    <option value="">Select</option>
                                    <?php
                                    $prod_assoc_array = array();
                                    if (!empty($medicines)) {
                                        $medicines = $medicines->result_array();
                                        foreach ($medicines as $row) {
                                            $prod_assoc_array[$row['item_id']] = $row;
                                    ?>
                                            <option value="<?php echo $row['item_id'] ?>" <?php if (isset($product_id) && $product_id == $row['item_id']) echo "selected='selected'"; ?> issuance_limit="<?= @$row['issuance_limit'] ?>" daily_units_in_single_item="<?= @$row['daily_units_in_single_item'] ?>"><?php echo $row['product_name'] ?></option>
                                    <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3" style="display: none;">
                            <div class="control-group">
                                <label class="example-text-input" for="batch" required>Batch Number<span style="color: red">*</span> </label>
                                <div class="controls">
                                    <select class="select2me input-medium" name="batch" id="batch" required style="width:100%;padding:10%;">
                                        <option value="">Select</option>

                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="control-group">
                                <label class="example-text-input" for="available_quantity" required>Available Quantity</label>
                                <div class="controls">
                                    <input name="available_quantity" tabindex="-1" id="available_quantity" class="form-control bg-grey" readonly="true">
                                </div>
                            </div>
                        </div>


                        <!--<div class="col-md-3">
                            <div class="control-group">
                                <label class="example-text-input" for="hf" required>Expiry Date </label>
                                <div class="controls">
                                    <input type="text" name="batch_expiry" tabindex="-1" id="batch_expiry" class="form-control bg-grey" value="" readonly="true">
                                </div>
                            </div>
                        </div>-->
                    </div>
                    <div class="form-group row">


                        <div class="col-md-3">
                            <div class="control-group">
                                <label class="example-text-input" for="quantity"  id="pre_quantity">Prescribed Quantity</label>
                                <div class="controls">
                                    <input type="number" name="pre_quantity" id="pre_quantity" class="form-control" >
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="control-group">
                                <label class="example-text-input" for="quantity" required id="qty_label">Issued Quantity<span style="color: red">*</span></label>
                                <div class="controls">
                                    <input type="number" name="quantity" id="quantity" class="form-control" required>
                                    <span id="prod_unit"></span>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="control-group">
                                <label class="example-text-input" for="hf" required>Remarks</label>
                                <div class="controls">
                                    <input name="remarks" id="remarks" class="form-control" />
                                </div>
                            </div>
                        </div>



                    </div>
                    <div class="form-group row">


                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <div style="float:right;">
                                    <input type="hidden" name="patient_id" id="patient_id" value="<?php echo $pk_id; ?>" />
                                    <button type="button" class="btn btn-dark waves-effect waves-light" id="btnprescription">
                                        Save
                                    </button>
                                    <button type="reset" class="btn btn-warning waves-effect m-l-5">
                                        Reset
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <br>

</form>
</p>
<p>
<div id="prescription_result">
    <?php
    if (!empty($temp_records)) {
        include("stock_issue_patients2.php");
    }
    ?>
</div>
</p>