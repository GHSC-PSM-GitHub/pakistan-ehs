<?php
echo start_table("datatable-buttons", array("Test Id", "Test Name", "Sample Type", "Sample Date","Action")); ?>
<?php $count = 1; foreach ($patient_labtest->result_object() as $row) { ?>
<tr>
    <td><?php echo $count; ?></td>
    <td><?php echo $row->code."-".$row->name; ?></td>
    <td><?php  echo $row->type_name; ?></td>
    <td><?php echo convert_date($row->sample_datetime,'toview'); ?></td>
    <td>
        <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deletelab">
            <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Cancel
        </button>
        <!--<button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>-->
    </td>
</tr>
<?php $count++; } ?>
<?php echo end_table(); ?>