<p class="mb-0">
    <?php echo start_form("ipd"); ?>
    <div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Select Ward:</label>
    <div class="col-sm-4">
        <?php echo create_combo("ward",array("Ward 1"=>"Ward 1 (2 bed available)","Ward 2"=>"Ward 2 (No Space)","Ward 3"=>"Ward 3 (10 beds available)")); ?>
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Patient Condition:</label>
    <div class="col-sm-4">
        <?php echo create_combo("pcondition",array("Mild"=>"Mild","Severe"=>"Severe","Critical"=>"Critical")); ?>
    </div>
    </div>
    <div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Additional Notes:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" id="add_notes" name="add_notes">                                                             
    </div>
    
    <label for="example-search-input" class="col-sm-2 col-form-label">Date:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" value="<?php echo date("d/m/Y"); ?>" id="disease_date" name="disease_date">
    </div>
    
    <input type="hidden" name="patient_id" id="patient_id" value="<?php echo $pk_id; ?>" />        
    </div>
    <div class="row">
        <div class="col-12">
            <div class="form-group">
                <div style="float:right;">
                    <button type="button" class="btn btn-dark waves-effect waves-light" id="btnipd">
                        Shifted to Ward
                    </button>
                </div>
            </div>
        </div> 
    </div>
    <?php echo end_form(); ?>
</p>
<p>
    <div id="ipd_result">
    <?php
    if(!empty($patient_ipd)){
        include("patient_ipd_table.php");
    }
    ?> 
    </div>
</p>