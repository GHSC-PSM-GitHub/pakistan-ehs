<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12">
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <!-- // Heading END -->
                    <h3>Patients Data</h3>

                    <div class="innerLR">
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <br>
                                        <?php
                                        if (isset($patients) && !empty($patients)) {
                                        ?>

                                            <div id="divToPrint">
                                                <table id="datatable-buttons" class="table table-striped table-bordered table-condensed dt-responsive nowrap">
                                                    <thead>
                                                        <tr>
                                                            <th class="center">No.</th>
                                                            <th>Patient Name</th>
                                                            <th>MR No.</th>
                                                            <th>Gender</th>
                                                            <th>CNIC</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <!-- Table row -->
                                                        <?php
                                                        $count = 1;
                                                        foreach ($patients->result_array() as $row) {
                                                        ?>
                                                            <tr>
                                                                <td class="center"><?php echo $count; ?></td>
                                                                <td><?php
                                                                    echo $row['full_name'];
                                                                    ?></td>
                                                                <td class="important">
                                                                    <?php echo $row['mr_no']; ?>
                                                                </td>
                                                                <td> <?php echo $row['gender'] ?> </td>
                                                                <td> <?php echo $row['nic_no'] ?> </td>
                                                                <td>
                                                                    <a href="<?php echo base_url("masterdata_management/add_mdm?id=") . $row['pk_id']; ?>&type=patient" class="btn btn-success" title="add_ext">MDM</a>

                                                                </td>
                                                            </tr>
                                                        <?php
                                                            $count++;
                                                        }
                                                        ?>
                                                        <!-- // Table row END -->
                                                        <!-- Table row -->

                                                        <!-- // Table row END -->
                                                    </tbody>
                                                </table>
                                            </div>

                                            <!-- // Table END -->
                                        <?php
                                        } else {
                                            echo "<hr><h5>No data found!</h5>";
                                        }
                                        ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>