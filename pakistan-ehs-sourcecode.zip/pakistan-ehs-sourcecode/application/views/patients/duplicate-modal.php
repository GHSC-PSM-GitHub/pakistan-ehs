<div class="modal fade patient-detail" tabindex="-1" role="dialog" aria-labelledby="duplicate" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="duplicate">Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body" id="p_result">
                Loading...
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>