<?php
//if (isset($temp_records) && (!empty($temp_records))) {
?>

    <div id="divToPrint">
        <table class="table table-striped table-bordered table-condensed dt-responsive ">
            <thead>
                <tr>
                    <th style="width: 1%;" class="center">No.</th>
                    <!--                                                <th>Funding Source</th>-->
                    <th>Product Name</th>
                    <!--                                                <th>Manufacturer</th>-->
                    <th>Batch Number</th>
                    <th>Expiry Date</th>
                    <th>Quantity</th>
                    <!--<th>Action</th>-->
                </tr>
            </thead>
            <tbody>
                <!-- Table row -->
                <?php
                $count = 1;
                foreach ($temp_records->result_array() as $row) {
                ?>
                    <tr>
                        <td class="center"><?php echo $count; ?></td>
                        <!--                                                    <td class="important"><?php //echo $row['funding_source_name']; 
                                                                                                        ?></td>-->
                        <td><?php echo $row['product_name']; ?></td>
                        <!--                                                    <td class="important"><?php //echo $row['manufacturer']; 
                                                                                                        ?></td>-->
                        <td class="important"><?php echo $row['batch_number']; ?></td>
                        <td class="important"><?php echo $row['batch_expiry']; ?></td>
                        <td class="important"><?php echo $row['quantity']; ?></td>

                        <!--                                                <td>  
                                                                            <a onclick="return confirm('Are you sure you want to Delete?');" href="<?php echo base_url("product_management/deactivate?id=") . $row['pk_id']; ?>&status=1" class="btn btn-sm btn-light glyphicons bin" > Delete</a>
                                                                        </td> -->
                    </tr>
                <?php
                    $count++;
                }
                ?>
                <!-- // Table row END -->
                <!-- Table row -->

                <!-- // Table row END -->
            </tbody>
        </table>
    </div>

    <!-- // Table END -->
    <button type="button" id="save_temp_issue" name="save_temp_issue" class="btn btn-primary waves-effect waves-light" style="margin-left:90%;">Save</button>

<?php
//}
?>

<div class="d-print-none mo-mt-2">
    <div class="float-right">
        <button data-toggle="modal" data-target=".patient-detail" class="btn btn-success waves-effect waves-light"><i class="fa fa-print"></i> Print Prescription</button>
        <!--<a href="<?php //echo base_url("lab/lab_worker_dataentry"); 
                        ?>" class="btn btn-primary waves-effect waves-light">Save</a>-->
    </div>
</div>

<div class="modal fade patient-detail" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myLargeModalLabel">PIMS Hospital Islamabad | 051-66698723 | Contact person: ABC</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body" id="patient_result">
                <div class="row">
                    <div class="col-12">
                        <img class="float-right" src="<?php echo base_url("/assets/barcode/barcode.php.png"); ?>" />
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card m-b-30">
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-12">

                                        <div class="invoice-title">
                                            <h4 class="float-right font-16"><strong>Patient Mr # <?php echo date("ymd-his"); ?></strong>
                                            </h4>
                                            <h3 class="m-t-0">
                                                Dr. Inayatullah Khan
                                            </h3>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-6">
                                                <address>
                                                    <strong>MBBS</strong><br>
                                                    Islamabad<br>
                                                    G11/4<br>
                                                    ST 7, B Block<br>
                                                    Mobile: 03339652360
                                                </address>
                                            </div>
                                            <div class="col-6 text-right">
                                                <address>
                                                    Ajmal Hussain<br>
                                                    Soan Garden<br>
                                                    Islamabad<br>
                                                    Emergency: 03339652360<br>
                                                    Mobile: 03331512197
                                                </address>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-12">
                                        <div class="panel panel-default">
                                            <div class="p-2">
                                                <h3 class="panel-title font-20"><strong>Prescribed Medicines</strong></h3>
                                            </div>
                                            <div class="row">
                                                <div class="col-9">
                                                    <div class="table-responsive">
                                                        <?php
                                                        echo start_table("datatable-buttons", array("S.No", "Medicine", "Method", "Strength", "Dose", "Days")); ?>
                                                        <?php $count = 1;
                                                        foreach ($patient_prescription->result_object() as $row) { ?>
                                                            <tr>
                                                                <td><?php echo $count; ?></td>
                                                                <td><?php echo $row->medicine_name; ?></td>
                                                                <td><?php echo $row->method; ?></td>
                                                                <td><?php echo $row->strength; ?></td>
                                                                <td><?php echo $row->dose; ?></td>
                                                                <td><?php echo $row->days; ?></td>
                                                            </tr>
                                                        <?php $count++;
                                                        } ?>
                                                        <?php echo end_table(); ?>
                                                    </div>


                                                </div>
                                                <div class="col-3">
                                                    <b class="font-14">Preliminary Examination</b> <br> <br>

                                                    Temprature: 102 F <br>
                                                    BP: 80/110 mmgh <br>
                                                    Pulse Rate: 50 bpm <br>
                                                    <hr>
                                                    <b class="font-14">Clinical Notes</b> <br> <br>

                                                    Dengue: Yes <br>
                                                    Fever: Yes <br>
                                                    <hr>
                                                    <b class="font-14">Lab Test</b> <br> <br>

                                                    Urine: Yes <br>
                                                    Blood: Yes <br>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div> <!-- end row -->
                                <div class="d-print-none mo-mt-2">
                                    <div class="float-right">
                                        <a href="javascript:window.print()" class="btn btn-success waves-effect waves-light"><i class="fa fa-print"></i></a>
                                        <!-- <a href="<?php //echo base_url("lab/lab_worker_dataentry"); 
                                                        ?>" class="btn btn-primary waves-effect waves-light">Save</a> -->
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div> <!-- end col -->
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>