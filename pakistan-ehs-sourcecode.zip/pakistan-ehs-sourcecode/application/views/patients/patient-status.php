<p class="mb-0">
    <?php echo start_form("form_ps"); ?>
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Mark to:</label>
    <div class="col-sm-4">
    <?php //echo create_list_combo("markto", 5, $wh_category); ?>
    <?php echo create_combo("markto", $types); ?>
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Room/Ward #:</label>
    <div class="col-sm-4" id="facility_div">
        <?php echo create_combo("facility", array()); ?>
    </div>
</div>
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Select Consultant:</label>
    <div class="col-sm-4">
        <?php echo create_combo("consultant", $consultant); ?>
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Diagnosis:</label>
    <div class="col-sm-4">
        <?php echo create_list_combo("diagnosis", 4); ?>
    </div>

</div>
<div class="form-group row m-b-0">
    
    <label for="example-search-input" class="col-sm-2 col-form-label">Consultant Fee:</label>
    <div class="col-sm-4">
    <input class="form-control" type="number" value="<?php echo isset($form['visit_fees']) ? $form['visit_fees'] : ''; ?>" id="visit_fees" name="visit_fees">
    </div>
    <!--<label for="example-search-input" class="col-sm-2 col-form-label">Payment Method:</label>
    <div class="col-sm-4">
    <?php //echo create_list_combo("payment_method", 2, $form['payment_method'],''); ?>
    </div>-->
    
</div>
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Visit Date:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" value="<?php echo date("Y-m-d H:i"); ?>" id="visit_date" name="visit_date">
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Additional Notes:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" id="add_notes" name="add_notes">
    </div>
    <input type="hidden" name="patient_id" id="patient_id" value="<?php echo $pk_id; ?>" />
</div>
<div class="row">
    <div class="col-12">
        <div class="form-group">
            <div style="float:right;">
                <button type="button" class="btn btn-dark waves-effect waves-light" id="btnps">
                    Save
                </button>
            </div>
        </div>
    </div>
</div>
<?php echo end_form(); ?>
</p>
<p>
<div id="ps_result">
    <?php
    if (!empty($patient_status)) {
        include("patient_status_table.php");
    }
    ?>
</div>
</p>