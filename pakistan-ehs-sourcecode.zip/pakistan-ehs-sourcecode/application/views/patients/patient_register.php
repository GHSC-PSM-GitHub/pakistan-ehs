<?php
$role = $this->session->get_userdata()['role'];
$isdisabled = '';
if ($role == 4) {
    $isdisabled = "readonly=''";
}

echo start_form('data'); ?>
<div class="form-group row">
    <label for="example-text-input" class="col-form-label col-sm-2">MR#<span style="color:red;">*</span> :</label>
    <div class="col-sm-4">
        <input class="form-control" <?php echo $isdisabled; ?> tabindex="-1" type="text" readonly="" value="<?php echo (isset($form['mrno']) ? $form['mrno'] : date("y") . "-" . get_mr_no_count()); ?>" id="mrno" name="mrno">
    </div>
    <div class="col-sm-6">
        <b style="float: right;"><span style="color:red;">*</span> Required Fields</b>
    </div>
</div>
<div class="form-group row">
    <label for="example-text-input" class="col-form-label col-sm-2">Full Name<span style="color:red;">*</span> :</label>
    <div class="col-sm-1">
        <select class="form-control" id="prefix" name="prefix" required <?php echo $isdisabled; ?>>
            <option value="Mr." <?php if ($prefix == 'Mr.') {
                                    echo "selected=selected";
                                } ?>>Mr.</option>
            <option value="Mrs." <?php if ($prefix == 'Mrs.') {
                                        echo "selected=selected";
                                    } ?>>Mrs.</option>
            <option value="Ms." <?php if ($prefix == 'Ms.') {
                                    echo "selected=selected";
                                } ?>>Ms.</option>
            <option value="Dr." <?php if ($prefix == 'Dr.') {
                                    echo "selected=selected";
                                } ?>>Dr.</option>
        </select>
    </div>
    <div class="col-sm-3">
        <input class="form-control" <?php echo $isdisabled; ?> type="text" value="<?php echo isset($form['full_name']) ? $form['full_name'] : ''; ?>" id="full_name" name="full_name" minlength="3" required>
    </div>
    <label for="example-text-input" class="col-form-label col-sm-2">CNIC#/B-Form:</label>
    <div class="col-sm-4">
        <!-- <input class="form-control" data-inputmask-mask="99999-9999999-9" type="text" value="<?php //echo isset($form['cnic']) ? $form['cnic'] : ''; 
                                                                                                    ?>" id="cnic" name="cnic"> -->
        <input class="form-control check_duplicate" type="text" value="<?php echo isset($form['cnic']) ? $form['cnic'] : ''; ?>" id="cnic" name="cnic" minlength="15" <?php echo $isdisabled; ?>>
    </div>
</div>

<div class="form-group row">
    <label for="example-text-input" class="col-form-label col-sm-2">Gender<span style="color:red;">*</span> :</label>
    <div class="col-sm-4">
        <select class="form-control" id="gender" name="gender" required <?php echo $isdisabled; ?>>
            <?php $gender = array("Male", "Female", "Transgender");
            foreach ($gender as $gen) {
                $sel = '';
                if ($form['gender'] == $gen) {
                    $sel = "selected=selected";
                }
            ?>
                <option value="<?php echo $gen; ?>" <?php echo $sel; ?>><?php echo $gen; ?></option>
            <?php
            }
            ?>
        </select>
    </div>

    <label for="example-text-input" class="col-form-label col-md-2">Date of Birth<span style="color:red;">*</span> :</label>
    <div class="col-sm-4">
        <div class="input-group">
              <input type="text" name="age" id="age" onkeyup="calculate_age(this.value,'age2dob')" class="form-control" placeholder="Age" required <?php echo $isdisabled; ?> />
            <select class="form-control" onchange="calculate_age(this.value,'dob2age')" id="day" name="dob[]" required <?php echo $isdisabled; ?>>
                <?php for ($d = 1; $d <= 31; $d++) {
                    $sel = "";
                    if ($d == $form['dob']['0']) {
                        $sel = "selected=selected";
                    }
                ?>
                    <option value="<?php echo $d; ?>" <?php echo $sel; ?>><?php echo $d; ?></option>
                <?php } ?>
            </select>
            <select class="form-control" onchange="calculate_age(this.value,'dob2age')" id="month" name="dob[]" required <?php echo $isdisabled; ?>>
                <?php for ($m = 1; $m <= 12; $m++) {
                    $sel = "";
                    if ($m == $form['dob']['1']) {
                        $sel = "selected=selected";
                    }
                ?>
                    <option value="<?php echo $m; ?>" <?php echo $sel; ?>><?php echo date('F', mktime(0, 0, 0, $m, 10)); ?></option>
                <?php } ?>
            </select>
            <select class="form-control" onchange="calculate_age(this.value,'dob2age')" id="year" name="dob[]" required <?php echo $isdisabled; ?>>
                <?php
                if (empty($form['dob']['2'])) {
                    $form['dob']['2'] = 1990;
                }
                for ($y = 1901; $y <= date("Y"); $y++) {
                    $sel = "";
                    if ($y == $form['dob']['2']) {
                        $sel = "selected=selected";
                    }
                ?>
                    <option value="<?php echo $y; ?>" <?php echo $sel; ?>><?php echo $y; ?></option>
                <?php } ?>
            </select>
          
        </div><!-- input-group -->
    </div>
</div>

<div class="form-group row">
    <label for="example-text-input" class="col-form-label col-sm-2">Address:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" value="<?php echo isset($form['address']) ? $form['address'] : ''; ?>" id="address" name="address" <?php echo $isdisabled; ?>>
    </div>

    <!--<label for="example-text-input" class="col-form-label col-md-2">City:</label>
    <div class="col-sm-4">
        <?php //echo create_combo("city", $cities, (isset($form['city']) ? $form['city'] : ''), 'required', $isdisabled); ?>
        
    </div>-->
</div>
<div class="form-group row">
    <label for="example-search-input" class="col-sm-2 col-form-label">Mobile Phone :</label>
    <div class="col-sm-4">
        <input class="form-control check_duplicate" type="text" value="<?php echo isset($form['mobile_phone']) ? $form['mobile_phone'] : ''; ?>" id="mobile_phone" name="mobile_phone" minlength="15" <?php echo $isdisabled; ?>>

    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Landline Number :</label>
    <div class="col-sm-4">
        <input class="form-control check_duplicate" type="text" value="<?php echo isset($form['landline']) ? $form['landline'] : ''; ?>" id="landline" name="landline" minlength="14" <?php echo $isdisabled; ?>>

    </div>
    <!--<label for="example-search-input" class="col-sm-2 col-form-label">Registration Fee :</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" value="<?php echo isset($form['reg_fees']) ? $form['reg_fees'] : ''; ?>" id="reg_fees" name="reg_fees">

    </div>-->
</div>

<div class="form-group row">
    <label for="example-search-input" class="col-sm-2 col-form-label">Nationality : </label>
    <div class="col-sm-4">
       <select class="form-control" id="country" name="country" <?php echo $isdisabled; ?>>    
    <option value="PK" <?php if (@$form['country'] == 'PK') {echo "selected=selected";} ?>>Pakistan</option>
    <option value="AF" <?php if (@$form['country'] == 'AF') {echo "selected=selected";} ?>>Afghanistan</option>
    <option value="AX" <?php if (@$form['country'] == 'AX') {echo "selected=selected";} ?>>Aland Islands</option>
    <option value="AL" <?php if (@$form['country'] == 'AL') {echo "selected=selected";} ?>>Albania</option>
    <option value="DZ" <?php if (@$form['country'] == 'DZ') {echo "selected=selected";} ?>>Algeria</option>
    <option value="AS" <?php if (@$form['country'] == 'AS') {echo "selected=selected";} ?>>American Samoa</option>
    <option value="AD" <?php if (@$form['country'] == 'AD') {echo "selected=selected";} ?>>Andorra</option>
    <option value="AO" <?php if (@$form['country'] == 'AO') {echo "selected=selected";} ?>>Angola</option>
    <option value="AI" <?php if (@$form['country'] == 'AI') {echo "selected=selected";} ?>>Anguilla</option>
    <option value="AQ" <?php if (@$form['country'] == 'AQ') {echo "selected=selected";} ?>>Antarctica</option>
    <option value="AG" <?php if (@$form['country'] == 'AG') {echo "selected=selected";} ?>>Antigua and Barbuda</option>
    <option value="AR" <?php if (@$form['country'] == 'AR') {echo "selected=selected";} ?>>Argentina</option>
    <option value="AM" <?php if (@$form['country'] == 'AM') {echo "selected=selected";} ?>>Armenia</option>
    <option value="AW" <?php if (@$form['country'] == 'AW') {echo "selected=selected";} ?>>Aruba</option>
    <option value="AU" <?php if (@$form['country'] == 'AU') {echo "selected=selected";} ?>>Australia</option>
    <option value="AT" <?php if (@$form['country'] == 'AT') {echo "selected=selected";} ?>>Austria</option>
    <option value="AZ" <?php if (@$form['country'] == 'AZ') {echo "selected=selected";} ?>>Azerbaijan</option>
    <option value="BS" <?php if (@$form['country'] == 'BS') {echo "selected=selected";} ?>>Bahamas</option>
    <option value="BH" <?php if (@$form['country'] == 'BH') {echo "selected=selected";} ?>>Bahrain</option>
    <option value="BD" <?php if (@$form['country'] == 'BD') {echo "selected=selected";} ?>>Bangladesh</option>
    <option value="BB" <?php if (@$form['country'] == 'BB') {echo "selected=selected";} ?>>Barbados</option>
    <option value="BY" <?php if (@$form['country'] == 'BY') {echo "selected=selected";} ?>>Belarus</option>
    <option value="BE" <?php if (@$form['country'] == 'BE') {echo "selected=selected";} ?>>Belgium</option>
    <option value="BZ" <?php if (@$form['country'] == 'BZ') {echo "selected=selected";} ?>>Belize</option>
    <option value="BJ" <?php if (@$form['country'] == 'BJ') {echo "selected=selected";} ?>>Benin</option>
    <option value="BM" <?php if (@$form['country'] == 'BM') {echo "selected=selected";} ?>>Bermuda</option>
    <option value="BT" <?php if (@$form['country'] == 'BT') {echo "selected=selected";} ?>>Bhutan</option>
    <option value="BO" <?php if (@$form['country'] == 'BO') {echo "selected=selected";} ?>>Bolivia</option>
    <option value="BQ" <?php if (@$form['country'] == 'BQ') {echo "selected=selected";} ?>>Bonaire, Sint Eustatius and Saba</option>
    <option value="BA" <?php if (@$form['country'] == 'BA') {echo "selected=selected";} ?>>Bosnia and Herzegovina</option>
    <option value="BW" <?php if (@$form['country'] == 'BW') {echo "selected=selected";} ?>>Botswana</option>
    <option value="BV" <?php if (@$form['country'] == 'BV') {echo "selected=selected";} ?>>Bouvet Island</option>
    <option value="BR" <?php if (@$form['country'] == 'BR') {echo "selected=selected";} ?>>Brazil</option>
    <option value="IO" <?php if (@$form['country'] == 'IO') {echo "selected=selected";} ?>>British Indian Ocean Territory</option>
    <option value="BN" <?php if (@$form['country'] == 'BN') {echo "selected=selected";} ?>>Brunei Darussalam</option>
    <option value="BG" <?php if (@$form['country'] == 'BG') {echo "selected=selected";} ?>>Bulgaria</option>
    <option value="BF" <?php if (@$form['country'] == 'BF') {echo "selected=selected";} ?>>Burkina Faso</option>
    <option value="BI" <?php if (@$form['country'] == 'BI') {echo "selected=selected";} ?>>Burundi</option>
    <option value="KH" <?php if (@$form['country'] == 'KH') {echo "selected=selected";} ?>>Cambodia</option>
    <option value="CM" <?php if (@$form['country'] == 'CM') {echo "selected=selected";} ?>>Cameroon</option>
    <option value="CA" <?php if (@$form['country'] == 'CA') {echo "selected=selected";} ?>>Canada</option>
    <option value="CV" <?php if (@$form['country'] == 'CV') {echo "selected=selected";} ?>>Cape Verde</option>
    <option value="KY" <?php if (@$form['country'] == 'KY') {echo "selected=selected";} ?>>Cayman Islands</option>
    <option value="CF" <?php if (@$form['country'] == 'CF') {echo "selected=selected";} ?>>Central African Republic</option>
    <option value="TD" <?php if (@$form['country'] == 'TD') {echo "selected=selected";} ?>>Chad</option>
    <option value="CL" <?php if (@$form['country'] == 'CL') {echo "selected=selected";} ?>>Chile</option>
    <option value="CN" <?php if (@$form['country'] == 'CN') {echo "selected=selected";} ?>>China</option>
    <option value="CX" <?php if (@$form['country'] == 'CX') {echo "selected=selected";} ?>>Christmas Island</option>
    <option value="CC" <?php if (@$form['country'] == 'CC') {echo "selected=selected";} ?>>Cocos (Keeling) Islands</option>
    <option value="CO" <?php if (@$form['country'] == 'CO') {echo "selected=selected";} ?>>Colombia</option>
    <option value="KM" <?php if (@$form['country'] == 'KM') {echo "selected=selected";} ?>>Comoros</option>
    <option value="CG" <?php if (@$form['country'] == 'CG') {echo "selected=selected";} ?>>Congo</option>
    <option value="CD" <?php if (@$form['country'] == 'CD') {echo "selected=selected";} ?>>Congo, Democratic Republic of the Congo</option>
    <option value="CK" <?php if (@$form['country'] == 'CK') {echo "selected=selected";} ?>>Cook Islands</option>
    <option value="CR" <?php if (@$form['country'] == 'CR') {echo "selected=selected";} ?>>Costa Rica</option>
    <option value="CI" <?php if (@$form['country'] == 'CI') {echo "selected=selected";} ?>>Cote D'Ivoire</option>
    <option value="HR" <?php if (@$form['country'] == 'HR') {echo "selected=selected";} ?>>Croatia</option>
    <option value="CU" <?php if (@$form['country'] == 'CU') {echo "selected=selected";} ?>>Cuba</option>
    <option value="CW" <?php if (@$form['country'] == 'CW') {echo "selected=selected";} ?>>Curacao</option>
    <option value="CY" <?php if (@$form['country'] == 'CY') {echo "selected=selected";} ?>>Cyprus</option>
    <option value="CZ" <?php if (@$form['country'] == 'CZ') {echo "selected=selected";} ?>>Czech Republic</option>
    <option value="DK" <?php if (@$form['country'] == 'DK') {echo "selected=selected";} ?>>Denmark</option>
    <option value="DJ" <?php if (@$form['country'] == 'DJ') {echo "selected=selected";} ?>>Djibouti</option>
    <option value="DM" <?php if (@$form['country'] == 'DM') {echo "selected=selected";} ?>>Dominica</option>
    <option value="DO" <?php if (@$form['country'] == 'DO') {echo "selected=selected";} ?>>Dominican Republic</option>
    <option value="EC" <?php if (@$form['country'] == 'EC') {echo "selected=selected";} ?>>Ecuador</option>
    <option value="EG" <?php if (@$form['country'] == 'EG') {echo "selected=selected";} ?>>Egypt</option>
    <option value="SV" <?php if (@$form['country'] == 'SV') {echo "selected=selected";} ?>>El Salvador</option>
    <option value="GQ" <?php if (@$form['country'] == 'GQ') {echo "selected=selected";} ?>>Equatorial Guinea</option>
    <option value="ER" <?php if (@$form['country'] == 'ER') {echo "selected=selected";} ?>>Eritrea</option>
    <option value="EE" <?php if (@$form['country'] == 'EE') {echo "selected=selected";} ?>>Estonia</option>
    <option value="ET" <?php if (@$form['country'] == 'ET') {echo "selected=selected";} ?>>Ethiopia</option>
    <option value="FK" <?php if (@$form['country'] == 'FK') {echo "selected=selected";} ?>>Falkland Islands (Malvinas)</option>
    <option value="FO" <?php if (@$form['country'] == 'FO') {echo "selected=selected";} ?>>Faroe Islands</option>
    <option value="FJ" <?php if (@$form['country'] == 'FJ') {echo "selected=selected";} ?>>Fiji</option>
    <option value="FI" <?php if (@$form['country'] == 'FI') {echo "selected=selected";} ?>>Finland</option>
    <option value="FR" <?php if (@$form['country'] == 'FR') {echo "selected=selected";} ?>>France</option>
    <option value="GF" <?php if (@$form['country'] == 'GF') {echo "selected=selected";} ?>>French Guiana</option>
    <option value="PF" <?php if (@$form['country'] == 'PF') {echo "selected=selected";} ?>>French Polynesia</option>
    <option value="TF" <?php if (@$form['country'] == 'TF') {echo "selected=selected";} ?>>French Southern Territories</option>
    <option value="GA" <?php if (@$form['country'] == 'GA') {echo "selected=selected";} ?>>Gabon</option>
    <option value="GM" <?php if (@$form['country'] == 'GM') {echo "selected=selected";} ?>>Gambia</option>
    <option value="GE" <?php if (@$form['country'] == 'GE') {echo "selected=selected";} ?>>Georgia</option>
    <option value="DE" <?php if (@$form['country'] == 'DE') {echo "selected=selected";} ?>>Germany</option>
    <option value="GH" <?php if (@$form['country'] == 'GH') {echo "selected=selected";} ?>>Ghana</option>
    <option value="GI" <?php if (@$form['country'] == 'GI') {echo "selected=selected";} ?>>Gibraltar</option>
    <option value="GR" <?php if (@$form['country'] == 'GR') {echo "selected=selected";} ?>>Greece</option>
    <option value="GL" <?php if (@$form['country'] == 'GL') {echo "selected=selected";} ?>>Greenland</option>
    <option value="GD" <?php if (@$form['country'] == 'GD') {echo "selected=selected";} ?>>Grenada</option>
    <option value="GP" <?php if (@$form['country'] == 'GP') {echo "selected=selected";} ?>>Guadeloupe</option>
    <option value="GU" <?php if (@$form['country'] == 'GU') {echo "selected=selected";} ?>>Guam</option>
    <option value="GT" <?php if (@$form['country'] == 'GT') {echo "selected=selected";} ?>>Guatemala</option>
    <option value="GG" <?php if (@$form['country'] == 'GG') {echo "selected=selected";} ?>>Guernsey</option>
    <option value="GN" <?php if (@$form['country'] == 'GN') {echo "selected=selected";} ?>>Guinea</option>
    <option value="GW" <?php if (@$form['country'] == 'GW') {echo "selected=selected";} ?>>Guinea-Bissau</option>
    <option value="GY" <?php if (@$form['country'] == 'GY') {echo "selected=selected";} ?>>Guyana</option>
    <option value="HT" <?php if (@$form['country'] == 'HT') {echo "selected=selected";} ?>>Haiti</option>
    <option value="HM" <?php if (@$form['country'] == 'HM') {echo "selected=selected";} ?>>Heard Island and Mcdonald Islands</option>
    <option value="VA" <?php if (@$form['country'] == 'VA') {echo "selected=selected";} ?>>Holy See (Vatican City State)</option>
    <option value="HN" <?php if (@$form['country'] == 'HN') {echo "selected=selected";} ?>>Honduras</option>
    <option value="HK" <?php if (@$form['country'] == 'HK') {echo "selected=selected";} ?>>Hong Kong</option>
    <option value="HU" <?php if (@$form['country'] == 'HU') {echo "selected=selected";} ?>>Hungary</option>
    <option value="IS" <?php if (@$form['country'] == 'IS') {echo "selected=selected";} ?>>Iceland</option>
    <option value="IN" <?php if (@$form['country'] == 'IN') {echo "selected=selected";} ?>>India</option>
    <option value="ID" <?php if (@$form['country'] == 'ID') {echo "selected=selected";} ?>>Indonesia</option>
    <option value="IR" <?php if (@$form['country'] == 'IR') {echo "selected=selected";} ?>>Iran, Islamic Republic of</option>
    <option value="IQ" <?php if (@$form['country'] == 'IQ') {echo "selected=selected";} ?>>Iraq</option>
    <option value="IE" <?php if (@$form['country'] == 'IE') {echo "selected=selected";} ?>>Ireland</option>
    <option value="IM" <?php if (@$form['country'] == 'IM') {echo "selected=selected";} ?>>Isle of Man</option>
    <option value="IL" <?php if (@$form['country'] == 'IL') {echo "selected=selected";} ?>>Israel</option>
    <option value="IT" <?php if (@$form['country'] == 'IT') {echo "selected=selected";} ?>>Italy</option>
    <option value="JM" <?php if (@$form['country'] == 'JM') {echo "selected=selected";} ?>>Jamaica</option>
    <option value="JP" <?php if (@$form['country'] == 'JP') {echo "selected=selected";} ?>>Japan</option>
    <option value="JE" <?php if (@$form['country'] == 'JE') {echo "selected=selected";} ?>>Jersey</option>
    <option value="JO" <?php if (@$form['country'] == 'JO') {echo "selected=selected";} ?>>Jordan</option>
    <option value="KZ" <?php if (@$form['country'] == 'KZ') {echo "selected=selected";} ?>>Kazakhstan</option>
    <option value="KE" <?php if (@$form['country'] == 'KE') {echo "selected=selected";} ?>>Kenya</option>
    <option value="KI" <?php if (@$form['country'] == 'KI') {echo "selected=selected";} ?>>Kiribati</option>
    <option value="KP" <?php if (@$form['country'] == 'KP') {echo "selected=selected";} ?>>Korea, Democratic People's Republic of</option>
    <option value="KR" <?php if (@$form['country'] == 'KR') {echo "selected=selected";} ?>>Korea, Republic of</option>
    <option value="XK" <?php if (@$form['country'] == 'XK') {echo "selected=selected";} ?>>Kosovo</option>
    <option value="KW" <?php if (@$form['country'] == 'KW') {echo "selected=selected";} ?>>Kuwait</option>
    <option value="KG" <?php if (@$form['country'] == 'KG') {echo "selected=selected";} ?>>Kyrgyzstan</option>
    <option value="LA" <?php if (@$form['country'] == 'LA') {echo "selected=selected";} ?>>Lao People's Democratic Republic</option>
    <option value="LV" <?php if (@$form['country'] == 'LV') {echo "selected=selected";} ?>>Latvia</option>
    <option value="LB" <?php if (@$form['country'] == 'LB') {echo "selected=selected";} ?>>Lebanon</option>
    <option value="LS" <?php if (@$form['country'] == 'LS') {echo "selected=selected";} ?>>Lesotho</option>
    <option value="LR" <?php if (@$form['country'] == 'LR') {echo "selected=selected";} ?>>Liberia</option>
    <option value="LY" <?php if (@$form['country'] == 'LY') {echo "selected=selected";} ?>>Libyan Arab Jamahiriya</option>
    <option value="LI" <?php if (@$form['country'] == 'LI') {echo "selected=selected";} ?>>Liechtenstein</option>
    <option value="LT" <?php if (@$form['country'] == 'LT') {echo "selected=selected";} ?>>Lithuania</option>
    <option value="LU" <?php if (@$form['country'] == 'LU') {echo "selected=selected";} ?>>Luxembourg</option>
    <option value="MO" <?php if (@$form['country'] == 'MO') {echo "selected=selected";} ?>>Macao</option>
    <option value="MK" <?php if (@$form['country'] == 'MK') {echo "selected=selected";} ?>>Macedonia, the Former Yugoslav Republic of</option>
    <option value="MG" <?php if (@$form['country'] == 'MG') {echo "selected=selected";} ?>>Madagascar</option>
    <option value="MW" <?php if (@$form['country'] == 'MW') {echo "selected=selected";} ?>>Malawi</option>
    <option value="MY" <?php if (@$form['country'] == 'MY') {echo "selected=selected";} ?>>Malaysia</option>
    <option value="MV" <?php if (@$form['country'] == 'MV') {echo "selected=selected";} ?>>Maldives</option>
    <option value="ML" <?php if (@$form['country'] == 'ML') {echo "selected=selected";} ?>>Mali</option>
    <option value="MT" <?php if (@$form['country'] == 'MT') {echo "selected=selected";} ?>>Malta</option>
    <option value="MH" <?php if (@$form['country'] == 'MH') {echo "selected=selected";} ?>>Marshall Islands</option>
    <option value="MQ" <?php if (@$form['country'] == 'MQ') {echo "selected=selected";} ?>>Martinique</option>
    <option value="MR" <?php if (@$form['country'] == 'MR') {echo "selected=selected";} ?>>Mauritania</option>
    <option value="MU" <?php if (@$form['country'] == 'MU') {echo "selected=selected";} ?>>Mauritius</option>
    <option value="YT" <?php if (@$form['country'] == 'YT') {echo "selected=selected";} ?>>Mayotte</option>
    <option value="MX" <?php if (@$form['country'] == 'MX') {echo "selected=selected";} ?>>Mexico</option>
    <option value="FM" <?php if (@$form['country'] == 'FM') {echo "selected=selected";} ?>>Micronesia, Federated States of</option>
    <option value="MD" <?php if (@$form['country'] == 'MD') {echo "selected=selected";} ?>>Moldova, Republic of</option>
    <option value="MC" <?php if (@$form['country'] == 'MC') {echo "selected=selected";} ?>>Monaco</option>
    <option value="MN" <?php if (@$form['country'] == 'MN') {echo "selected=selected";} ?>>Mongolia</option>
    <option value="ME" <?php if (@$form['country'] == 'ME') {echo "selected=selected";} ?>>Montenegro</option>
    <option value="MS" <?php if (@$form['country'] == 'MS') {echo "selected=selected";} ?>>Montserrat</option>
    <option value="MA" <?php if (@$form['country'] == 'MA') {echo "selected=selected";} ?>>Morocco</option>
    <option value="MZ" <?php if (@$form['country'] == 'MZ') {echo "selected=selected";} ?>>Mozambique</option>
    <option value="MM" <?php if (@$form['country'] == 'MM') {echo "selected=selected";} ?>>Myanmar</option>
    <option value="NA" <?php if (@$form['country'] == 'NA') {echo "selected=selected";} ?>>Namibia</option>
    <option value="NR" <?php if (@$form['country'] == 'NR') {echo "selected=selected";} ?>>Nauru</option>
    <option value="NP" <?php if (@$form['country'] == 'NP') {echo "selected=selected";} ?>>Nepal</option>
    <option value="NL" <?php if (@$form['country'] == 'NL') {echo "selected=selected";} ?>>Netherlands</option>
    <option value="AN" <?php if (@$form['country'] == 'AN') {echo "selected=selected";} ?>>Netherlands Antilles</option>
    <option value="NC" <?php if (@$form['country'] == 'NC') {echo "selected=selected";} ?>>New Caledonia</option>
    <option value="NZ" <?php if (@$form['country'] == 'NZ') {echo "selected=selected";} ?>>New Zealand</option>
    <option value="NI" <?php if (@$form['country'] == 'NI') {echo "selected=selected";} ?>>Nicaragua</option>
    <option value="NE" <?php if (@$form['country'] == 'NE') {echo "selected=selected";} ?>>Niger</option>
    <option value="NG" <?php if (@$form['country'] == 'NG') {echo "selected=selected";} ?>>Nigeria</option>
    <option value="NU" <?php if (@$form['country'] == 'NU') {echo "selected=selected";} ?>>Niue</option>
    <option value="NF" <?php if (@$form['country'] == 'NF') {echo "selected=selected";} ?>>Norfolk Island</option>
    <option value="MP" <?php if (@$form['country'] == 'MP') {echo "selected=selected";} ?>>Northern Mariana Islands</option>
    <option value="NO" <?php if (@$form['country'] == 'NO') {echo "selected=selected";} ?>>Norway</option>
    <option value="OM" <?php if (@$form['country'] == 'OM') {echo "selected=selected";} ?>>Oman</option>
    <option value="PW" <?php if (@$form['country'] == 'PW') {echo "selected=selected";} ?>>Palau</option>
    <option value="PS" <?php if (@$form['country'] == 'PS') {echo "selected=selected";} ?>>Palestinian Territory, Occupied</option>
    <option value="PA" <?php if (@$form['country'] == 'PA') {echo "selected=selected";} ?>>Panama</option>
    <option value="PG" <?php if (@$form['country'] == 'PG') {echo "selected=selected";} ?>>Papua New Guinea</option>
    <option value="PY" <?php if (@$form['country'] == 'PY') {echo "selected=selected";} ?>>Paraguay</option>
    <option value="PE" <?php if (@$form['country'] == 'PE') {echo "selected=selected";} ?>>Peru</option>
    <option value="PH" <?php if (@$form['country'] == 'PH') {echo "selected=selected";} ?>>Philippines</option>
    <option value="PN" <?php if (@$form['country'] == 'PN') {echo "selected=selected";} ?>>Pitcairn</option>
    <option value="PL" <?php if (@$form['country'] == 'PL') {echo "selected=selected";} ?>>Poland</option>
    <option value="PT" <?php if (@$form['country'] == 'PT') {echo "selected=selected";} ?>>Portugal</option>
    <option value="PR" <?php if (@$form['country'] == 'PR') {echo "selected=selected";} ?>>Puerto Rico</option>
    <option value="QA" <?php if (@$form['country'] == 'QA') {echo "selected=selected";} ?>>Qatar</option>
    <option value="RE" <?php if (@$form['country'] == 'RE') {echo "selected=selected";} ?>>Reunion</option>
    <option value="RO" <?php if (@$form['country'] == 'RO') {echo "selected=selected";} ?>>Romania</option>
    <option value="RU" <?php if (@$form['country'] == 'RU') {echo "selected=selected";} ?>>Russian Federation</option>
    <option value="RW" <?php if (@$form['country'] == 'RW') {echo "selected=selected";} ?>>Rwanda</option>
    <option value="BL" <?php if (@$form['country'] == 'BL') {echo "selected=selected";} ?>>Saint Barthelemy</option>
    <option value="SH" <?php if (@$form['country'] == 'SH') {echo "selected=selected";} ?>>Saint Helena</option>
    <option value="KN" <?php if (@$form['country'] == 'KN') {echo "selected=selected";} ?>>Saint Kitts and Nevis</option>
    <option value="LC" <?php if (@$form['country'] == 'LC') {echo "selected=selected";} ?>>Saint Lucia</option>
    <option value="MF" <?php if (@$form['country'] == 'MF') {echo "selected=selected";} ?>>Saint Martin</option>
    <option value="PM" <?php if (@$form['country'] == 'PM') {echo "selected=selected";} ?>>Saint Pierre and Miquelon</option>
    <option value="VC" <?php if (@$form['country'] == 'VC') {echo "selected=selected";} ?>>Saint Vincent and the Grenadines</option>
    <option value="WS" <?php if (@$form['country'] == 'WS') {echo "selected=selected";} ?>>Samoa</option>
    <option value="SM" <?php if (@$form['country'] == 'SM') {echo "selected=selected";} ?>>San Marino</option>
    <option value="ST" <?php if (@$form['country'] == 'ST') {echo "selected=selected";} ?>>Sao Tome and Principe</option>
    <option value="SA" <?php if (@$form['country'] == 'SA') {echo "selected=selected";} ?>>Saudi Arabia</option>
    <option value="SN" <?php if (@$form['country'] == 'SN') {echo "selected=selected";} ?>>Senegal</option>
    <option value="RS" <?php if (@$form['country'] == 'RS') {echo "selected=selected";} ?>>Serbia</option>
    <option value="CS" <?php if (@$form['country'] == 'CS') {echo "selected=selected";} ?>>Serbia and Montenegro</option>
    <option value="SC" <?php if (@$form['country'] == 'SC') {echo "selected=selected";} ?>>Seychelles</option>
    <option value="SL" <?php if (@$form['country'] == 'SL') {echo "selected=selected";} ?>>Sierra Leone</option>
    <option value="SG" <?php if (@$form['country'] == 'SG') {echo "selected=selected";} ?>>Singapore</option>
    <option value="SX" <?php if (@$form['country'] == 'SX') {echo "selected=selected";} ?>>Sint Maarten</option>
    <option value="SK" <?php if (@$form['country'] == 'SK') {echo "selected=selected";} ?>>Slovakia</option>
    <option value="SI" <?php if (@$form['country'] == 'SI') {echo "selected=selected";} ?>>Slovenia</option>
    <option value="SB" <?php if (@$form['country'] == 'SB') {echo "selected=selected";} ?>>Solomon Islands</option>
    <option value="SO" <?php if (@$form['country'] == 'SO') {echo "selected=selected";} ?>>Somalia</option>
    <option value="ZA" <?php if (@$form['country'] == 'ZA') {echo "selected=selected";} ?>>South Africa</option>
    <option value="GS" <?php if (@$form['country'] == 'GS') {echo "selected=selected";} ?>>South Georgia and the South Sandwich Islands</option>
    <option value="SS" <?php if (@$form['country'] == 'SS') {echo "selected=selected";} ?>>South Sudan</option>
    <option value="ES" <?php if (@$form['country'] == 'ES') {echo "selected=selected";} ?>>Spain</option>
    <option value="LK" <?php if (@$form['country'] == 'LK') {echo "selected=selected";} ?>>Sri Lanka</option>
    <option value="SD" <?php if (@$form['country'] == 'SD') {echo "selected=selected";} ?>>Sudan</option>
    <option value="SR" <?php if (@$form['country'] == 'SR') {echo "selected=selected";} ?>>Suriname</option>
    <option value="SJ" <?php if (@$form['country'] == 'SJ') {echo "selected=selected";} ?>>Svalbard and Jan Mayen</option>
    <option value="SZ" <?php if (@$form['country'] == 'SZ') {echo "selected=selected";} ?>>Swaziland</option>
    <option value="SE" <?php if (@$form['country'] == 'SE') {echo "selected=selected";} ?>>Sweden</option>
    <option value="CH" <?php if (@$form['country'] == 'CH') {echo "selected=selected";} ?>>Switzerland</option>
    <option value="SY" <?php if (@$form['country'] == 'SY') {echo "selected=selected";} ?>>Syrian Arab Republic</option>
    <option value="TW" <?php if (@$form['country'] == 'TW') {echo "selected=selected";} ?>>Taiwan, Province of China</option>
    <option value="TJ" <?php if (@$form['country'] == 'TJ') {echo "selected=selected";} ?>>Tajikistan</option>
    <option value="TZ" <?php if (@$form['country'] == 'TZ') {echo "selected=selected";} ?>>Tanzania, United Republic of</option>
    <option value="TH" <?php if (@$form['country'] == 'TH') {echo "selected=selected";} ?>>Thailand</option>
    <option value="TL" <?php if (@$form['country'] == 'TL') {echo "selected=selected";} ?>>Timor-Leste</option>
    <option value="TG" <?php if (@$form['country'] == 'TG') {echo "selected=selected";} ?>>Togo</option>
    <option value="TK" <?php if (@$form['country'] == 'TK') {echo "selected=selected";} ?>>Tokelau</option>
    <option value="TO" <?php if (@$form['country'] == 'TO') {echo "selected=selected";} ?>>Tonga</option>
    <option value="TT" <?php if (@$form['country'] == 'TT') {echo "selected=selected";} ?>>Trinidad and Tobago</option>
    <option value="TN" <?php if (@$form['country'] == 'TN') {echo "selected=selected";} ?>>Tunisia</option>
    <option value="TR" <?php if (@$form['country'] == 'TR') {echo "selected=selected";} ?>>Turkey</option>
    <option value="TM" <?php if (@$form['country'] == 'TM') {echo "selected=selected";} ?>>Turkmenistan</option>
    <option value="TC" <?php if (@$form['country'] == 'TC') {echo "selected=selected";} ?>>Turks and Caicos Islands</option>
    <option value="TV" <?php if (@$form['country'] == 'TV') {echo "selected=selected";} ?>>Tuvalu</option>
    <option value="UG" <?php if (@$form['country'] == 'UG') {echo "selected=selected";} ?>>Uganda</option>
    <option value="UA" <?php if (@$form['country'] == 'UA') {echo "selected=selected";} ?>>Ukraine</option>
    <option value="AE" <?php if (@$form['country'] == 'AE') {echo "selected=selected";} ?>>United Arab Emirates</option>
    <option value="GB" <?php if (@$form['country'] == 'GB') {echo "selected=selected";} ?>>United Kingdom</option>
    <option value="US" <?php if (@$form['country'] == 'US') {echo "selected=selected";} ?>>United States</option>
    <option value="UM" <?php if (@$form['country'] == 'UM') {echo "selected=selected";} ?>>United States Minor Outlying Islands</option>
    <option value="UY" <?php if (@$form['country'] == 'UY') {echo "selected=selected";} ?>>Uruguay</option>
    <option value="UZ" <?php if (@$form['country'] == 'UZ') {echo "selected=selected";} ?>>Uzbekistan</option>
    <option value="VU" <?php if (@$form['country'] == 'VU') {echo "selected=selected";} ?>>Vanuatu</option>
    <option value="VE" <?php if (@$form['country'] == 'VE') {echo "selected=selected";} ?>>Venezuela</option>
    <option value="VN" <?php if (@$form['country'] == 'VN') {echo "selected=selected";} ?>>Viet Nam</option>
    <option value="VG" <?php if (@$form['country'] == 'VG') {echo "selected=selected";} ?>>Virgin Islands, British</option>
    <option value="VI" <?php if (@$form['country'] == 'VI') {echo "selected=selected";} ?>>Virgin Islands, U.s.</option>
    <option value="WF" <?php if (@$form['country'] == 'WF') {echo "selected=selected";} ?>>Wallis and Futuna</option>
    <option value="EH" <?php if (@$form['country'] == 'EH') {echo "selected=selected";} ?>>Western Sahara</option>
    <option value="YE" <?php if (@$form['country'] == 'YE') {echo "selected=selected";} ?>>Yemen</option>
    <option value="ZM" <?php if (@$form['country'] == 'ZM') {echo "selected=selected";} ?>>Zambia</option>
    <option value="ZW" <?php if (@$form['country'] == 'ZW') {echo "selected=selected";} ?>>Zimbabwe</option>
</select>
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Passport Number :</label>
    <div class="col-sm-4">
        <input class="form-control check_duplicate" type="text" value="<?php echo isset($form['passport_no']) ? $form['passport_no'] : ''; ?>" id="passport_no" name="passport_no" minlength="9" <?php echo $isdisabled; ?>>

    </div>
   
</div>
<!--<div class="form-group row">
    <label for="example-search-input" class="col-sm-2 col-form-label">Payment Method :</label>
    <div class="col-sm-4">
        <?php echo create_list_combo("payment_method", 2, $form['payment_method'], ''); ?>
    </div>

    <label for="example-search-input" class="col-sm-2 col-form-label">Vaccination Status :</label>
    <div class="col-sm-4">
        <?php echo create_list_combo("vaccination_status", 15, $form['vaccination_status'], ''); ?>
    </div>
</div>
<div class="form-group row">
    <label for="example-search-input" class="col-sm-2 col-form-label">Last dose date :</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" value="<?php echo isset($form['last_dose_date']) ? $form['last_dose_date'] : ''; ?>" id="last_dose_date" name="last_dose_date">
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Vaccine Name :</label>
    <div class="col-sm-4">
        <?php echo create_list_combo("vaccine_name", 16, $form['vaccine_name'], ''); ?>
    </div>
</div>
<div class="form-group row">
    <label for="example-search-input" class="col-sm-2 col-form-label">Covid Status :</label>
    <div class="col-sm-4">
    <?php echo create_list_combo("covid_status", 17, $form['covid_status'], ''); ?>
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Oxygen Status :</label>
    <div class="col-sm-4">
        <?php echo create_list_combo("oxygen_status", 18, $form['oxygen_status'], ''); ?>
    </div>
</div>-->
<!--<div class="form-group row m-b-0">
    <div class="col-6">
        <div class="custom-control custom-checkbox">
            <input type="checkbox" class="custom-control-input" disabled="disabled" id="nadra" name="nadra" data-parsley-multiple="groups" data-parsley-mincheck="2" checked <?php //echo (isset($form['nadra']) && $form['nadra'] == 'on') ? "checked" : ''; 
                                                                                                                                                                                ?>>
            <label class="custom-control-label" for="nadra">NADRA Verified</label>


        </div>
    </div>
</div>-->



<input type="hidden" name="pk_id" id="pk_id" value="<?php echo $pk_id; ?>" />
<div class="row">
    <div class="col-12">
        <div class="form-group">
            <div style="float:right;">
                <button id="submitreg" type="submit" class="btn <?php echo !empty($pk_id) ? "btn-secondary" : "btn-dark"; ?> waves-effect waves-light">
                    <?php echo !empty($pk_id) ? "Update" : "Register"; ?>
                </button>
                <button type="reset" class="btn btn-warning waves-effect m-l-5">
                    Reset
                </button>
                <?php if ($this->session->get_userdata()['stk_id'] == 1) { ?>
                    <?php if (!empty($pk_id)) { ?>
                        <a href="history?p_id=<?php echo $pk_id; ?>" target="_blank">
                            <button type="button" class="btn btn-primary waves-effect m-l-5">
                                Patient History
                            </button>
                        </a>
                        <!-- <button type="button" id="token" class="btn btn-danger waves-effect m-l-5">
                                                Token
                                            </button> -->
                    <?php } ?>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<?php echo end_form(); ?>

<?php if($role <> 8){ ?>
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Select Visit Code :</label>
    <div class="col-sm-4">
        <?php echo create_combo("visit_code_master", $visit_codes); ?>
    </div>
</div>
<?php } ?>

<div class="row" id="get-token" style="display:none;">
    <div class="col-sm-12">
        <table>
            <tr>
                <td width="200px">Token No</td>
                <td width="200px"><span style="font-size: 3em;" id="tokenno">...</span></td>

            </tr>
            <tr>
                <td>Patient Name</td>
                <td id="patientname">Loading...</td>
            </tr>
            <tr>
                <td>Consultant Name</td>
                <td id="consultantname">Loading...</td>
                <td><button id="printbtn" type="button" onclick="printdiv()" class="btn btn-dark">
                        Print Token
                    </button></td>
            </tr>
        </table>
    </div>
</div>