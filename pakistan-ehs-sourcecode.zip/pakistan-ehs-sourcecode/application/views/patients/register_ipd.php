<style>
    h2 {
        margin-top: 18px !important;
    }
</style>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Patient's Personal Data</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url("patients/search"); ?>">Search Patients</a></li>
                        <li class="breadcrumb-item active">Register Patient</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>
        
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                    <?php
                        //print_r($_POST);
                        $prefix = (isset($form['prefix']) ? $form['prefix'] : '');

                        include "patient_register.php";
                        ?>
                        <br>
                        <div class="row">
                            <div class="col-12" id="gen-token" style="display:none;">
                                <div class="form-group row m-b-0">
                                    <label for="example-search-input" class="col-sm-2 col-form-label">Select Doctor:</label>
                                    <div class="col-sm-3">
                                        <?php echo create_combo("doctors", array("Doctor1" => "Shamim Akhtar (5 patients assigned today)", "Doctor2" => "Azhar Iqbal (Available)", "Doctor3" => "Ghulam Mustafa (10 patients assigned today)")); ?>
                                    </div>
                                    <div class="col-sm-1">
                                        <button type="button" class="btn btn-dark waves-effect waves-light" id="generate_token">
                                            Generate
                                        </button>
                                    </div>
                                    <div class="col-sm-6 token" style="display: none;">

                                    </div>
                                </div>
                            </div>

                        </div>

                        <div <?php if (empty($pk_id)) { ?> style="display:none" <?php } ?>>
                            <ul class="nav nav-pills nav-justified" role="tablist">
                                <!--<li class="nav-item waves-effect waves-light">
                                    <a class="nav-link active" data-toggle="tab" href="#additional-info" role="tab">
                                        <span class="d-none d-md-block">1. Additional Info</span><span class="d-block d-md-none"><i class="mdi mdi-home-variant h5"></i></span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#rapid-test" role="tab">
                                        <span class="d-none d-md-block">2. Rapid Test</span><span class="d-block d-md-none"><i class="mdi mdi-account h5"></i></span>
                                    </a>
                                </li>
                                
                                -->
                                <!--<li class="nav-item waves-effect waves-light">
                                    <a class="nav-link " data-toggle="tab" href="#allocation" role="tab">
                                        <span class="d-none d-md-block">1. Patient Allocation</span><span class="d-block d-md-none"><i class="mdi mdi-home-variant h5"></i></span>
                                    </a>
                                </li><li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#lab-test" role="tab">
                                        <span class="d-none d-md-block">3. Lab System</span><span class="d-block d-md-none"><i class="mdi mdi-email h5"></i></span>
                                    </a>
                                </li><li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#ipdtab" role="tab">
                                        <span class="d-none d-md-block">6. Patient Movement</span><span class="d-block d-md-none"><i class="mdi mdi-settings h5"></i></span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#dischargetab" role="tab">
                                        <span class="d-none d-md-block">7. Discharge</span><span class="d-block d-md-none"><i class="mdi mdi-settings h5"></i></span>
                                    </a>
                                </li>-->
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link active" data-toggle="tab" href="#preexamination" role="tab">
                                        <span class="d-none d-md-block">1. Update Vitals</span><span class="d-block d-md-none"><i class="mdi mdi-settings h5"></i></span>
                                    </a>
                                </li>
                                
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#clinicalnotes" role="tab">
                                        <span class="d-none d-md-block">2. Clinical Notes</span><span class="d-block d-md-none"><i class="mdi mdi-settings h5"></i></span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#prescription" role="tab">
                                        <span class="d-none d-md-block">3. Medicine Issued</span><span class="d-block d-md-none"><i class="mdi mdi-settings h5"></i></span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#otherprod" role="tab">
                                        <span class="d-none d-md-block">4. Medicine Not Issued</span><span class="d-block d-md-none"><i class="mdi mdi-settings h5"></i></span>
                                    </a>
                                </li>
                                
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <!--<div class="tab-pane active p-3" id="additional-info" role="tabpanel">
                                    <?php //include("step1-additional-info.php"); 
                                    ?>
                                </div>
                                <div class="tab-pane p-3" id="rapid-test" role="tabpanel">
                                    <?php //include("step2-rdt.php"); 
                                    ?>
                                </div>-->
                                <!--<div class="tab-pane active p-3" id="allocation" role="tabpanel">
                                    <?php //include("patient-allocation.php"); ?>
                                </div>-->
                                <div class="tab-pane active p-3" id="preexamination" role="tabpanel">
                                    <?php include("step4-preexamination.php"); ?>
                                </div>
                                <!--<div class="tab-pane p-3" id="lab-test" role="tabpanel">
                                    <?php //include("step3-lab-test.php"); ?>
                                </div>-->

                                <div class="tab-pane p-3" id="clinicalnotes" role="tabpanel">
                                    <?php include("step5-clinicalnotes.php"); ?>
                                </div>
                                <div class="tab-pane p-3" id="prescription" role="tabpanel">
                                    <?php include("step6-prescription.php"); ?>
                                </div>
                                <div class="tab-pane p-3" id="otherprod" role="tabpanel">
                                <?php include("other-products.php"); ?>
                                </div>
                                <!--<div class="tab-pane p-3" id="ipdtab" role="tabpanel">
                                    <?php //include("patient-status.php"); ?>
                                </div>-->
                                <!--<div class="tab-pane p-3" id="dischargetab" role="tabpanel">
                                    <?php //include("patient-discharge.php"); ?>
                                </div>-->
                            </div>
                        </div>

                    </div>

                </div> <!-- end col -->



            </div>






        </div>
        <!-- end container-fluid -->
    </div>
    <!-- end wrapper -->
    <?php include("duplicate-modal.php"); ?>