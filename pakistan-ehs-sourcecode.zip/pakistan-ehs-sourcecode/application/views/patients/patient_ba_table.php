<?php
if(!empty($patient_ba)){
echo start_table("datatable-buttons", array("S.No", "Visit Date","Room/Ward Name/Number","Consultant Name", "Nurse Name","Action")); ?>
<?php $count = 1; foreach ($patient_ba->result_object() as $row) { ?>
<tr>
    <td><?php echo $count; ?></td>
    <td><?php echo convert_date($row->date,'toview'); ?></td>
    <td><?php echo $row->wh_name; ?>/Bed#<?php echo $row->bed_no_allocated; ?></td>
    <td><?php echo $row->consultant_name; ?></td>
    <td><?php echo $row->nurse_name; ?></td>
    
    <td>
        <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deleteba">
            <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
        </button>
        <!--<button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>-->
    </td>
</tr>
<?php $count++; } ?>
<?php echo end_table(); 
} else {
    echo "No record found";
}
?>