<p class="mb-0">
<div class="form-group row m-b-0">
    <label for="example-text-input" class="col-form-label col-sm-2">NIC#/B-Form:</label>
    <div class="col-sm-4">
        <input class="form-control" data-inputmask-mask="99999-9999999-9" type="text" value="<?php echo isset($form['cnic']) ? $form['cnic'] : ''; ?>" id="cnic" name="cnic" required>
    </div>
    <label for="example-text-input" class="col-form-label col-sm-2">Marital Status:</label>
    <div class="col-sm-4">
        <select class="form-control" id="marital" name="marital" required>
            <?php $marital = array("Married", "Single", "Divorced", "Widowed");
            foreach ($marital as $mar) {
                $sel = '';
                if ($form['marital'] == $mar) {
                    $sel = "selected=selected";
                }
            ?>
                <option value="<?php echo $mar; ?>" <?php echo $sel; ?>><?php echo $mar; ?></option>
            <?php
            }
            ?>
        </select>
    </div>
</div>
<div class="form-group row">
    <label for="example-text-input" class="col-form-label col-sm-2">Province:</label>
    <div class="col-sm-4">
        <select class="form-control" id="province" name="province" required>
            <option value="">Select</option>
            <?php $provinces = array(1 => "Punjab", 2 => "Sindh", 3 => "Khyber Pakhtunkhwa", 4 => "Balochistan", 5 => "AJK", 6 => "FATA", 7 => "Gilgit Baltistan", 8 => "Islamabad");
            foreach ($provinces as $key => $prov) {
                $sel = '';
                if ($form['province'] == $key) {
                    $sel = "selected=selected";
                }
            ?>
                <option value="<?php echo $key; ?>" <?php echo $sel; ?>><?php echo $prov; ?></option>
            <?php
            }
            ?>
        </select>
    </div>
    <label for="example-text-input" class="col-form-label col-sm-2">District:</label>
    <div class="col-sm-4">
        <select class="form-control" id="district" name="district" required>
            <?php
            echo "<option value=>Select</option>";
            if (isset($districts)) {
                foreach ($districts->result_object() as $row) {
                    $sel = '';
                    if ($form['district'] == $row->pk_id) {
                        $sel = "selected=selected";
                    }
                    echo "<option value=" . $row->pk_id . " $sel >" . $row->location_name . "</option>";
                }
            }
            ?>
        </select>
    </div>
</div>

<div class="form-group row">
    <label for="example-text-input" class="col-form-label col-sm-2">Tehsil:</label>
    <div class="col-sm-4">
        <select class="form-control" id="tehsil" name="tehsil" required>
            <?php
            echo "<option value=>Select</option>";
            if (isset($tehsils)) {
                foreach ($tehsils->result_object() as $row) {
                    $sel = '';
                    if ($form['tehsil'] == $row->pk_id) {
                        $sel = "selected=selected";
                    }
                    echo "<option value=" . $row->pk_id . " $sel>" . $row->location_name . "</option>";
                }
            }
            ?>
        </select>
    </div>

    <label for="example-text-input" class="col-form-label col-sm-2">UC:</label>
    <div class="col-sm-4">
        <select class="form-control" id="uc" name="uc" required>
            <?php
            echo "<option value=>Select</option>";
            if (isset($ucs)) {
                foreach ($ucs->result_object() as $row) {
                    $sel = '';
                    if ($form['uc'] == $row->pk_id) {
                        $sel = "selected=selected";
                    }
                    echo "<option value=" . $row->pk_id . " $sel>" . $row->location_name . "</option>";
                }
            }
            ?>
        </select>
    </div>
</div>

<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Guardian Name:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" minlength="5" value="<?php echo isset($form['father_guardian_name']) ? $form['father_guardian_name'] : ''; ?>" id="father_guardian_name" name="father_guardian_name">

    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Guardian Relation:</label>
    <div class="col-sm-4">
        <?php echo create_combo("relation", array("Father" => "Father", "Brother" => "Brother", "Husband" => "Husband")); ?>

    </div>
</div>
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Guardian NIC:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" data-inputmask-mask="99999-9999999-9" value="<?php echo isset($form['father_guardian_nic']) ? $form['father_guardian_nic'] : ''; ?>" id="father_guardian_nic" name="father_guardian_nic">

    </div>

    
</div>
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Upload Picture:</label>
    <div class="col-sm-4">
        <input class="form-control" type="file" value="<?php echo isset($form['picture']) ? $form['picture'] : ''; ?>" id="picture" name="picture" accept="image/*" capture>
    </div>
</div>