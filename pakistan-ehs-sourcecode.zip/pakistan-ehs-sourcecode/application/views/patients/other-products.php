<p class="mb-0">
    <?php echo start_form("form_op"); ?>
<!--<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Visit Code:</label>
    <div class="col-sm-4">
    <?php //echo create_list_combo("markto", 5, $wh_category); ?>
    <?php //echo create_combo("markto", $types); ?>
    <?php //echo create_combo("visit_code", $visit_codes); ?>
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Referred To:</label>
    <div class="col-sm-4" id="facility_div">
        <?php //echo create_combo("facility", array()); ?>
    </div>
</div>-->
<div class="form-group row m-b-0">
    <label for="example-search-input" class="col-sm-2 col-form-label">Product Name:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" value="" id="product_name" name="product_name">
    </div>
    <label for="example-search-input" class="col-sm-2 col-form-label">Prescribed Quantity:</label>
    <div class="col-sm-4">
        <input class="form-control" type="text" id="pres_qty" name="pres_qty" value="">
    </div>
    <input type="hidden" name="patient_id" id="patient_id" value="<?php echo $pk_id; ?>" />
</div>
<div class="row">
    <div class="col-12">
        <div class="form-group">
            <div style="float:right;">
            <a href="<?php echo base_url("patients/search"); ?>"><button type="button" class="btn btn-info waves-effect waves-light">
                    Finish
                </button></a>
                <button type="button" class="btn btn-dark waves-effect waves-light" id="btnop">
                    Save
                </button>
            </div>
        </div>
    </div>
</div>
<?php echo end_form(); ?>
</p>
<p>
<div id="op_result">
    <?php
    if (!empty($patient_op)) {
        include("patient_op_table.php");
    }
    ?>
</div>
</p>