<?php
if (!empty($patient_op)) {
    echo start_table("datatable-buttons", array("S.No", "Visit Code","Product Name", "Prescribed Quantity", "Action")); ?>
    <?php $count = 1;
    foreach ($patient_op->result_object() as $row) {
        

    ?>
        <tr>
            <td><?php echo $count; ?></td>
            <td><?php echo $row->visit_code; ?></td>
            <td><?php echo $row->product_name; ?></td>
            <td><?php echo $row->quantity; ?></td>
            <td>
                <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id . "_" . $row->patient_id; ?>-deleteop">
                    <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
                </button>
                <!--<button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>-->
            </td>
        </tr>
    <?php $count++;
    } ?>
<?php echo end_table();
} else {
    echo "No record found";
}
?>