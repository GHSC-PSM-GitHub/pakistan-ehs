<?php if (!empty($searched_data)) { ?>
    <table id="search_table" class="display  table table-condensed" cellspacing="0">
        <thead>
            <th>S. No.</th>
            <th>MR Number</th>
            <th>Patient Name</th>
            <th>CNIC</th>
            <th>Mobile</th>
            <th>Landline</th>
            <!--<th class='notexport'>Action</th>-->
        </thead>
        <tbody>
            <?php

            $count = 1;
            foreach ($searched_data as $value) {

               // if($value['created_by'] == $_SESSION['id']){
                    ?>
                   <tr>
                    <!--<td>
                        <label for="checkid" style="word-wrap:break-word">
                            <input id="checkidmr" name="checkidmr[]" type="checkbox" value="<?php echo  $value['pk_id']; ?>" style="vertical-align:middle;" />
                        </label>
               </td>-->
                    <td><?php echo $count++; ?></td>
                    <td><?php echo $value['mr_no'] ?> </td>
                    <td><?php echo $value['full_name'] ?> </td>
                    <td><?php echo $value['nic_no'] ?> </td>
                    <td><?php echo $value['mobile_no'] ?> </td>
                    <td><?php echo $value['landline'] ?> </td>
                    <td>
                        <a class="btn btn-warning" href="<?php echo base_url("patients/register?id=" . $value['pk_id'] . "&edit=true") ?>">YES!</a>
                    </td>
                </tr>
                <tr><td colspan="7" style="text-align: right;"><button type="button" class="btn btn-success" data-dismiss="modal" aria-label="Close">
                    Ignore and Continue
                </button></td></tr>
                    <?php
                //} else {
            ?>
                <!--<tr><td colspan="7">No duplicate data found! But same person information found in our database! Click on IMPORT button if you want to import his profile.</td></tr>-->
                <!--<tr>
                    <td>
                        <label for="checkid" style="word-wrap:break-word">
                            <input id="checkidmr" name="checkidmr[]" type="checkbox" value="<?php echo  $value['pk_id']; ?>" style="vertical-align:middle;" />
                        </label>
                    </td>
                    <td><?php echo $count++; ?></td>
                    <td><?php echo $value['mr_no'] ?> </td>
                    <td><?php echo $value['full_name'] ?> </td>
                    <td><?php echo $value['nic_no'] ?> </td>
                    <td><?php echo $value['mobile_no'] ?> </td>
                    <td><?php echo $value['landline'] ?> </td>
                    <td>
                        <a class="btn btn-warning" href="<?php echo base_url("patients/import?id=" . $value['pk_id']) ?>">Import</a>
                    </td>
                </tr>-->
            <?php
            //}
            }
            ?>
        </tbody>
    </table>
<?php } else {
    echo false;
} ?>