<style>
    h2 {
        margin-top: 18px !important;
    }
</style>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Search Patient</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Manage Patients</a></li>
                        <li class="breadcrumb-item active">Search Patient</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>
        <?php if($this->session->get_userdata()['role'] != 4) { ?>
        <div class="row">
            <div class="col-12">
                    <a href="<?php echo base_url("patients/register"); ?>" class="btn btn-primary btn-icon glyphicons circle_plus"><i class="fas fa-user-plus"></i> New Patient</a>
            </div>
        </div>
        <?php } ?>
        <br>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">

                        <form name="rdt" id="rdt" action="" method="post">
                            <div class="form-group row m-b-0">
                                <label for="example-text-input" class="col-form-label col-sm-2">Search By:</label>
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <select class="form-control col-sm-3" id="search_by" name="search_by" required>
                                            <?php $searchby = array("nic_no" => "CNIC", "notes" => "Visit Code", "mr_no" => "Mr#", "full_name" => "Patient Name", "mobile_no" => "Mobile No", "created_date" => "Registration date");
                                            foreach ($searchby as $key => $value) {
                                                $sel = '';
                                                if ($form['search_by'] == $key) {
                                                    $sel = "selected=selected";
                                                }
                                            ?>
                                                <option value="<?php echo $key; ?>" <?php echo $sel; ?>><?php echo $value; ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                        <input class="form-control" type="text" id="search_text" name="search_text" placeholder="Search Text" value="<?php if (isset($form['search_text'])) {
                                                                                                                                                            echo $form['search_text'];
                                                                                                                                                        } ?>">
                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <button type="submit" class="btn btn-primary waves-effect waves-light" id="btnrdt">
                                        Search
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <?php if (isset($search_result) && !empty($search_result)) {
                            echo start_table("datatable-buttons", array("S.No","Registration date", "Mr#", "Patient Name", "CNIC#", "Mobile#", "Action")); ?>
                            <?php $count = 1;
                            foreach ($search_result->result_object() as $row) { ?>
                                <tr>
                                    <td><?php echo $count; ?></td>
                                    <td><?php echo convert_date($row->created_date,'toview'); ?></td>
                                    <td><?php echo $row->mr_no; ?></td>
                                    <td><?php echo $row->full_name; ?></td>
                                    <!-- <td><?php //echo convert_date($row->admission_date, 'toview'); 
                                                ?></td> -->
                                    <td><?php echo $row->nic_no; ?></td>
                                    <td><?php echo $row->mobile_no; ?></td>

                                    <td>
                                        <a href="<?php echo base_url("patients/register?id=" . $row->pk_id); ?>"><button type="button" class="btn btn-info btn-sm waves-effect waves-light">View Detail</button></a>
                                    </td>
                                </tr>
                            <?php $count++;
                            } ?>
                            <?php echo end_table(); ?>


                        <?php } else {
                            echo "<h6>No record found!</h6>";
                        } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>