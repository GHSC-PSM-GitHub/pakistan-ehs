<table class="table table-striped table-bordered table-condensed dt-responsive ">
    <thead>
        <tr>
            <th style="width: 1%;" class="center">No.</th>
            <th>Visit Code</th>
            <th>Product Name</th>
            <th>Prescribed Qty</th>
            <!--<th>Batch Number</th>-->
            <!--<th>Expiry Date</th>-->
            <th>Issued Quantity</th>
            <th>Remarks</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <!-- Table row -->
        <?php
        $count = 1;
        foreach ($temp_records->result_array() as $row) {
        ?>
            <tr> <form method="post" action='<?= base_url().'patients/update_qty';?>'>
                <input type="hidden" name="batch_id" id="batch_id<?= $row['batch_id'];?>" value= "<?php echo $row['batch_id']; ?>" >
                <input type="hidden" name="patient_id" value= "<?= !empty($_GET['id'])?$_GET['id']:'';?>" >
                <!-- <input type="hidden" name="product_name" id="product_name<?php //echo $row['product_name'];?>" value= "<?php //echo $row['product_name']; ?>" > -->
                <!-- <input type="hidden" name="prescribed_quantity" id="prescribed_quantity<?php //echo $row['prescribed_quantity'];?>" value= "<?php //echo $row['prescribed_quantity']; ?>" > -->
                <!-- <input type="hidden" name="quantity" id="quantity<?php //echo $row['quantity'];?>" value= "<?php //echo $row['quantity']; ?>" >    -->
                <!-- <input type="hidden" name="remarks" id="remarks<?php //echo $row['remarks'];?>" value= "<?php //echo $row['remarks']; ?>" >    -->
            
                <td class="center"><?php echo $count;?></td>
                <td><?php echo $row['transaction_reference']; ?></td>
                <td><?php echo $row['product_name']; ?></td>
                <td class="important"><?php echo $row['prescribed_quantity']; ?></td>
                <!--<td class="important"><?php //echo $row['batch_number']; ?></td>-->
                <!--<td class="important"><?php //echo $row['batch_expiry']; ?></td>-->
                <td class="important quantity" data='<?php echo $row['quantity']; ?>' data-id='<?= $row['batch_id'];?>'><?php echo $row['quantity']; ?></td>
                <td class="important"><?php echo $row['remarks']; ?></td>
                <td><button class="btn btn-danger btn-sm" type="button" id="<?php echo $row['batch_id'] . "_" . $row['pk_id'] . "_" . $row['stock_master_id'] . "_" . $row['patient_id']; ?>-deletepp">
                    <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
                </button>
            <button type="submit" class="btn btn-sm btn-warning waves-effect m-l-5" ><span class="fa fa-pencil" role="status" aria-hidden="true"></span>Update</button>
          
        </td> </form>
            </tr>
        <?php
            $count++;
        }
        ?>
        <!-- // Table row END -->
        <!-- Table row -->

        <!-- // Table row END -->
    </tbody>
</table>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script>
<script>
    $(document).on('click', '.quantity', function(){ 
        $(this).removeClass('quantity');
     //   $(this).off('click' , ' . quantity' , function)
        $(this).html('<input type=number name="quantity" id="quantity" value="'+$(this).attr('data')+'" />');
    });


    
</script>