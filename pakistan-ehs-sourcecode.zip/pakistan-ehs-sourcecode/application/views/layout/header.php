<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>EHS - <?php echo $page_title; ?></title>
    <meta content="Responsive admin theme build on top of Bootstrap 4" name="description" />
    <meta content="Themesdesign" name="author" />
    <link rel="shortcut icon" href="<?php echo base_url('assets/images/favicon.ico') ?>">

    <!--Morris Chart CSS -->
    <link rel="stylesheet" href="../plugins/morris/morris.css">
    <link href="<?php echo base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('assets/css/metismenu.min.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('assets/css/icons.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('assets/css/style.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('plugins/select2/select2.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css') ?>"
        rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('plugins/datetimepicker/bootstrap-datetimepicker.min.css') ?>" rel="stylesheet"
        type="text/css">
    <link href="<?php echo base_url('plugins/datatables/dataTables.bootstrap4.min.css') ?>" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo base_url('plugins/datatables/buttons.bootstrap4.min.css') ?>" rel="stylesheet"
        type="text/css" />

    <?php echo add_page_css_file(); ?>
    <?php echo add_page_custom_css_file(@$css); ?>
    <?php include "css.php"; ?>
</head>

<body>

    <div class="header-bg">
        <!-- Navigation Bar-->
        <header id="topnav">
            <div class="topbar-main">
                <div class="container-fluid">
                    <!-- Logo-->
                    <div>
                        <a href="#" class="logo">
                            <span class="logo-light" style="font-size:24px">
                                <img src="<?php echo base_url('/assets/images/govpk1.png') ?>" width="48" /> Health
                                Enterprise Solution
                            </span>
                        </a>
                    </div>
                    <!-- End Logo-->
                    <div class="menu-extras topbar-custom navbar p-0">
                        <ul class="list-inline d-none d-lg-block mb-0">
                            <li class="hide-phone app-search float-left">
                                <form role="search" class="app-search">
                                    <div class="form-group mb-0">
                                        <input type="text" class="form-control" placeholder="Search..">
                                        <button type="submit"><i class="fa fa-search"></i></button>
                                    </div>
                                </form>
                            </li>
                        </ul>

                        <ul class="navbar-right ml-auto list-inline float-right mb-0">
                            <!-- language-->


                            <!-- full screen -->
                            <li class="dropdown notification-list list-inline-item d-none d-md-inline-block">
                                <a class="nav-link waves-effect" href="#" id="btn-fullscreen">
                                    <i class="mdi mdi-arrow-expand-all noti-icon"></i>
                                </a>
                            </li>

                            <!-- notification -->
                            <li class="dropdown notification-list list-inline-item">
                                <a class="nav-link dropdown-toggle arrow-none waves-effect" data-toggle="dropdown"
                                    href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <i class="mdi mdi-bell-outline noti-icon"></i>
                                    <span class="badge badge-pill badge-danger noti-icon-badge">1</span>
                                </a>
                                <div
                                    class="dropdown-menu dropdown-menu-right dropdown-menu-animated dropdown-menu-lg px-1">
                                    <!-- item-->
                                    <h6 class="dropdown-item-text">
                                        Notifications
                                    </h6>
                                    <div class="slimscroll notification-item-list">
                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item active">
                                            <div class="notify-icon bg-success"><i class="mdi mdi-cart-outline"></i>
                                            </div>
                                            <p class="notify-details">You are logged in.</p>
                                        </a>

                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-danger"><i
                                                    class="mdi mdi-message-text-outline"></i></div>
                                            <p class="notify-details">b</p>
                                        </a>

                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-info"><i class="mdi mdi-filter-outline"></i>
                                            </div>
                                            <p class="notify-details">c</p>
                                        </a>

                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-success"><i
                                                    class="mdi mdi-message-text-outline"></i></div>
                                            <p class="notify-details"><span class="text-muted">d</span></p>
                                        </a>

                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-warning"><i class="mdi mdi-cart-outline"></i>
                                            </div>
                                            <p class="notify-details">e</p>
                                        </a>

                                    </div>
                                    <!-- All-->
                                    <a href="javascript:void(0);"
                                        class="dropdown-item text-center notify-all text-primary">
                                        View all <i class="fi-arrow-right"></i>
                                    </a>
                                </div>
                            </li>

                            <li class="dropdown notification-list list-inline-item">
                                <div class="dropdown notification-list nav-pro-img">
                                    <a class="dropdown-toggle nav-link arrow-none nav-user" data-toggle="dropdown"
                                        href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                        <img src="<?php echo base_url('assets/images/kp.png') ?>" alt="user"
                                            class="rounded-circle">
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                        <!-- item-->
<!--                                        <a class="dropdown-item" href="#"><i class="mdi mdi-account-circle"></i>-->
<!--                                            Profile</a>-->
                                        <a class="dropdown-item" href="<?php echo base_url('users_management/change_pass') ?>"><i class="mdi mdi-account-circle"></i> Change Password</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item text-danger"
                                            href="<?php echo base_url('Auth/logout') ?>"><i
                                                class="mdi mdi-power text-danger"></i> Logout</a>
                                    </div>
                                </div>
                            </li>

                            <li class="menu-item dropdown notification-list list-inline-item">
                                <!-- Mobile menu toggle-->
                                <a class="navbar-toggle nav-link">
                                    <div class="lines">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </a>
                                <!-- End mobile menu toggle-->
                            </li>

                        </ul>

                    </div>
                    <!-- end menu-extras -->

                    <div class="clearfix"></div>

                </div>
                <!-- end container -->
            </div>
            <!-- end topbar-main -->

            <?php include "top-menu.php"; ?>
        </header>
        <!-- End Navigation Bar-->

    </div>
    <!-- header-bg -->