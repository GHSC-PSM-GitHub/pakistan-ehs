<script>
     $(function () {
   $("#province").change(function(){
//       alert("check");
       var value= $("#province option:selected" ).text(); 
        $("#province_name").val(value);
    });
    $("#city").change(function(){
       var value= $("#city option:selected" ).text(); 
        $("#city_name").val(value);
    });
    $("#district").change(function(){
       var value= $("#district option:selected" ).text(); 
        $("#district_name").val(value);
    });
    $("#tehsil").change(function(){
       var value= $("#tehsil option:selected" ).text(); 
        $("#tehsil_name").val(value);
    });
    $("#uc").change(function(){
       var value= $("#uc option:selected" ).text(); 
        $("#uc_name").val(value);
    });
    $("#stakeholder").change(function(){
       var value= $("#stakeholder option:selected" ).text(); 
        $("#stakeholder_name").val(value);
    });
    $("#type").change(function(){
       var value= $("#type option:selected" ).text(); 
        $("#facility_type_name").val(value);
    });
    $("#parent_hospital").change(function(){
       var value= $("#parent_hospital option:selected" ).text(); 
        $("#parent_hospital_name").val(value);
    });
    $("#category").change(function(){
       var value= $("#category option:selected" ).text();
       $("#category_name").val(value);
       if($(this).val()!=1){
           $("#parent_div").css("display","block");
           $.ajax({
            type: "POST",
            url: "<?php echo base_url('ajax/facilities_by_category'); ?>",
            data: {
                category: $(this).val()
            },
            dataType: 'html',
            success: function (data) {
                $('#parent_hospital').html(data);
            }
        });
       }
        else{
        $("#parent_div").css("display","none");
        }
        
    });
    
    $("#addwarehouse").validate({
               rules: {
                   province: "required",
                   district: "required",
                   stakeholder: "required", 
                   hf_name: "required" ,
                   city:"required",
                   tehsil:"required",
                   uc:"required",
                   category:"requied",
                   type:"required",
                   contact_person:"required",
                   designation:"required",
                   contact_number:"requied",
                   address:"required"
               }  
           });
   });
   
  
   
</script>
