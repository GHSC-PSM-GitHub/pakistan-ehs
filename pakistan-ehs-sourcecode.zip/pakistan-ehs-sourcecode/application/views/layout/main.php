<?php include 'header.php'; ?>
<?php echo $main_content; ?>
<?php
include 'footer.php';
//$params = helper_function( current_url() )
//print_r($this->router->fetch_class());exit;
if ($this->router->fetch_class() == "Users_management") {
    ?>
    <script src="<?php echo base_url('assets/js/users.js') ?>"></script>
    <?php
} else if ($this->router->fetch_class() == "warehouse_management") {
     include "warehouses_js.php";
} else if ($this->router->fetch_class() == "location_management") {

    include "locations_js.php";
} else if ($this->router->fetch_class() == "masterdata_management") {
    include "mdm_js.php";
} 
else if ($this->router->fetch_class() == "hr_profile_management") {
    include "hr_profile.php";
} 
?>