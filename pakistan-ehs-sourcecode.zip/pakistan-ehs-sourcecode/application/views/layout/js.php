<script>
    /* $(function () {
        $('.select2me').select2();
        $("#nominee").multiselect({
            includeSelectAllOption: false,
            enableFiltering: true,
            enableCaseInsensitiveFiltering: true
        });
    }); */
    $(function () {
         $('.select2me').select2();
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
        var csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>'; 
       
        $("#province").change(function(){
            var value = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/combo"); ?>',
                data: {
                    id: value,
                    lvl: 4,
                    [csrfName]: csrfHash
                },
                dataType: 'html',
                success: function (data) {
                    $('#district').html(data);
                }
            });
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/cities"); ?>',
                data: {
                    province_id: value, 
                    [csrfName]: csrfHash
                },
                dataType: 'html',
                success: function (data) {
                    $('#city').html(data);
                }
            });
        });

        $("#province_lab").change(function(){
            var value = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/facilities"); ?>',
                data: {
                    id: value,
                    [csrfName]: csrfHash
                },
                dataType: 'html',
                success: function (data) {
                    $('#lab_list').html(data);
                }
            });
        });
        
        $("#district").change(function(){
            var value = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/combo"); ?>',
                data: {
                    id: value,
                    lvl: 5,
                    [csrfName]: csrfHash
                },
                dataType: 'html',
                success: function (data) {
                    $('#tehsil').html(data);
                }
            });
        });

        $("#tehsil").change(function(){
            var value = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/combo"); ?>',
                data: {
                    id: value,
                    lvl: 6,
                    [csrfName]: csrfHash
                },
                dataType: 'html',
                success: function (data) {
                    $('#uc').html(data);
                }
            });
        });

        $("#uc").change(function(){
            var value = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/facilities"); ?>',
                data: {
                    id: value,
                    [csrfName]: csrfHash
                },
                dataType: 'html',
                success: function (data) {
                    $('#facility').html(data);
                }
            });
        });

        
    });

    function PrintDiv() {

        var divToPrint = document.getElementById('divToPrint');
        var popupWin = window.open('', '_blank', 'width=1750,height=800');
        popupWin.document.open();
        popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
        popupWin.document.close();

    }

    function minmax(value, min, max)
    {
        if (parseInt(value) < min || isNaN(parseInt(value)))
            return min;
        else if (parseInt(value) > max)
            return max;
        else
            return value;
    }

    function emailIsValid(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
    }

    function cnicIsValid(cnic) {
        return /\d{5}-\d{7}-\d/.test(cnic)
    }

    $("input[id$='-tid']").keyup(function () {
        var value = $(this).attr("id");
        var id = value.replace("-tid", "");
        var id1 = $("#"+id+"-tid").val();
        var id2 = $("#"+id+"-eid").val();
        
        $("#"+id+"-sumid").val(parseInt(id1)+parseInt(id2));
    });

    $("input[id$='-eid']").keyup(function () {
        var value = $(this).attr("id");
        var id = value.replace("-eid", "");
        var id1 = $("#"+id+"-tid").val();
        var id2 = $("#"+id+"-eid").val();
        
        $("#"+id+"-sumid").val(parseInt(id1)+parseInt(id2));
    });

    $("#from_date, #to_date").datepicker();

    
</script>