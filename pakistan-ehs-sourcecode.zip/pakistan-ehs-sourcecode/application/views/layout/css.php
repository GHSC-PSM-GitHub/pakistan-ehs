<style>
.datepicker {
    top: 5.5px;
    left: 966.5px;
    z-index: 10000 !important;
    display: block;
    overflow: visible;
}
</style>