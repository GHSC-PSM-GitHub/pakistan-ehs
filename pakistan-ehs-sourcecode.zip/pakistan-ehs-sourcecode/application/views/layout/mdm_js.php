<script>
    $(function () {
        $("#addmdm").validate({
            rules: {
                ext_system: "required",
                external_pk: "required"
            }
        });

        $.ajax({
            type: "POST",
            url: "<?php echo base_url('ajax/mdm_entities'); ?>",
            data: {
                type: "<?php echo $_REQUEST['type'] ?>",
                id:<?php echo $_REQUEST['id'] ?>
            },
            dataType: 'html',
            success: function (data) {
                $('#entity').val(data);
            }
        });
    });
</script>