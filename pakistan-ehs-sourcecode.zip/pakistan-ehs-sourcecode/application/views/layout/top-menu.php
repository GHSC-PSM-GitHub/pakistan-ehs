<!-- MENU Start -->
<div class="navbar-custom">
    <div class="container-fluid">
        <div id="navigation">

            <?php if ($this->session->get_userdata()['role'] == 0) { ?>
                <!-- Navigation Menu-->
                <ul class="navigation-menu">
                    <li>&nbsp;</li>
                    <li class="has-submenu">
                        <a href="#"><i class="icon-setting-1"></i> Systems Configurations <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <div class="col-md-12">
                                <div class="">
                                    <div><span style="display:inline-block; width: 180px;">Hospitals Management </span></span><a href="<?php echo base_url('/hospital_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/hospital_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                </div>
                            </div>
                            <!--                            <li>
                                                            <ul>
                                                                <li><a href="#">Manage Roles</a></li>
                                                                <li><a href="#">Manage Resources</a></li>
                                                                <li><a href="#">Manage ACL</a></li>
                                                            </ul>
                                                        </li>-->
                        </ul>
                    </li>
                </ul>
            <?php } ?>
            <?php if ($this->session->get_userdata()['role'] == 1) { ?>
                <!-- Navigation Menu-->
                <ul class="navigation-menu">

                    <!--<li class="has-submenu">
                        <a href="<?php echo base_url('/dashboard/index'); ?>"><i class="icon-accelerator"></i> Dashboard</a>
                    </li>-->

                    <li class="has-submenu">
                        <a href="#"><i class="icon-setting-1"></i> CMS Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <div class="col-md-12">
                                <div class="">
                                    <!--<div><span style="display:inline-block; width: 180px;">Products </span><a href="<?php echo base_url('/product_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/product_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                    <div><span style="display:inline-block; width: 180px;">Product Family (Category) </span><a href="<?php echo base_url('/productcategory_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productcategory_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Products (Generic Names) </span><a href="<?php echo base_url('/productgeneric_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productgeneric_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product Brands </span><a href="<?php echo base_url('/product_management/brand'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/product_management/addbrand'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product Strength </span><a href="<?php echo base_url('/productstrength_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productstrength_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <!--<div><span style="display:inline-block; width: 180px;">Product Sub Category </span><a href="<?php echo base_url('/productsubcategory_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productsubcategory_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                   <div><span style="display:inline-block; width: 180px;">Product Method types </span><a href="<?php echo base_url('/productmethodtype_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productmethodtype_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product Manufacturer </span><a href="<?php echo base_url('/productmanufacturer_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productmanufacturer_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <!--<div><span style="display:inline-block; width: 180px;">Contradictory Products </span><a href="<?php echo base_url('/product_management/list_contradicts'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/product_management/contradictory_products'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                    <hr />
                                    <div><span style="display:inline-block; width: 180px;">Facility/Labs </span><a href="<?php echo base_url('/warehouse_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/warehouse_management/add_wh'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Facilities Types </span><a href="<?php echo base_url('/wh_types_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/wh_types_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Facilities Category </span><a href="<?php echo base_url('/wh_categories_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/wh_categories_management/add_wh_category'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <!--<div><span style="display:inline-block; width: 180px;">Stakeholder/Departments </span><a href="<?php echo base_url('/stakeholder_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php //echo base_url('/stakeholder_management/add'); 
                                                                                                                                                                                                                                                    ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                    <hr />
                                    <!--<div><span style="display:inline-block; width: 180px;">Labs Order Settings </span><a href="<?php echo base_url('/lab_tests_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/lab_tests_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Lab Departments </span><a href="<?php echo base_url('/list_management/index/19'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/list_management/add/19'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                    <!-- <div><span style="display:inline-block; width: 180px;">Cities </span><a href="<?php echo base_url('/Cities_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/Cities_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div> -->
                                    <div><span style="display:inline-block; width: 180px;">Users</span><a href="<?php echo base_url('/users_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/users_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Vitals </span><a href="<?php echo base_url('/vitals/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/vitals/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>

                                    <!--                                    <div><span style="display:inline-block; width: 180px;">Test Sample Types</span><a href="<?php echo base_url('/Test_sample_types/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/Test_sample_types/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>      -->
                                    <!-- <div><span style="display:inline-block; width: 180px;">External Systems </span><a href="<?php echo base_url('/externalsystems_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/externalsystems_management/add_ext_system'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div> -->

                                </div>
                            </div>
                            <!--                            <li>
                                                            <ul>
                                                                <li><a href="#">Manage Roles</a></li>
                                                                <li><a href="#">Manage Resources</a></li>
                                                                <li><a href="#">Manage ACL</a></li>
                                                            </ul>
                                                        </li>-->
                        </ul>
                    </li>
                    <!--<li class="has-submenu">
                        <a href="#"><i class="icon-paper-sheet"></i> DataEntry <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">

                            <li>
                                <ul>
                                    <li><a href="<?php echo base_url('/dataentry/summary_form'); ?>">Summary Form</a></li>

                                </ul>
                            </li>
                            
                        </ul>
                    </li>-->
                    <?php
                    $configuration_menu_hr = array(
                        1 => "HR Categories",
                        6 => "HR Status",
                        9 => "Designations",
                        10 => "Departments",
                        11 => "PMC/PNC Category",
                        12 => "Blood Group",
                        13 => "Job Band",
                        14 => "Gender"
                    );
                    ?>
                    <li class="has-submenu">
                        <a href="#"><i class="icon-todolist"></i> HR <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <li>
                                <ul>
                                    <li><a href="<?php echo base_url('/hr_profile_management/add'); ?>"><i class="fa fa-plus-circle"></i> Add HR Profile</a></li>
                                    <li><a href="<?php echo base_url('/hr_profile_management/index'); ?>"><i class="fa fa-search"></i> Search Profile</a></li>

                                </ul>
                            </li>
                            <hr>
                            <div class="col-md-12">
                                <div class="">

                                    <?php foreach ($configuration_menu_hr as $key => $value) { ?>
                                        <div><span style="display:inline-block; width: 180px;"><?php echo $value; ?> </span><a href="<?php echo base_url('/list_management/index/' . $key); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/list_management/add/' . $key); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <?php } ?>
                                </div>
                            </div>
                        </ul>

                    </li>
                    <li class="has-submenu">
                        <a href="#"><i class="icon-life-buoy"></i> Analytics Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <li>
                                <ul>
                                <li><a href="<?php echo base_url('/patients/search'); ?>">Patients data</a></li>
                                <li><a href="<?php echo base_url('/reports/explorer'); ?>">IM Explorer</a></li>
                                    <li><a href="<?php echo base_url('/reports/soh'); ?>">Stock On Hand</a></li>
                                    <li><a href="<?php echo base_url('/reports/stock_ledger'); ?>">Stock Ledger</a></li>
                                    <li><a href="<?php echo base_url('/reports/issuance_list'); ?>">Stock Issuance Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/receive_list'); ?>">Stock Receive Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/raw_data_report'); ?>">Raw Data Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/entry_report'); ?>">Daily Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/stock_detail'); ?>">Stock Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/batch_report'); ?>">Batch Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/pivot'); ?>">BI Tool</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>

                    <?php
                    if ($this->session->get_userdata()['role'] == 5) {
                        $configuration_menu = array(
                            18 => "Oxygen Status"
                        );

                    ?>
                        <li class="has-submenu">
                            <a href="#"><i class="icon-todolist"></i> Inventory Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                            <ul class="submenu megamenu">
                                <li>
                                    <ul>
                                        <?php
                                        if ($this->session->get_userdata()['role'] == 1) { ?>
                                            <li><a href="<?php echo base_url('/inventory_management/stock_receive'); ?>">Stock Receive</a></li>
                                            <li><a href="<?php echo base_url('/inventory_management/stock_issue'); ?>">Stock Issue to Centers</a></li>
                                            <li><a href="<?php echo base_url('/inventory_management/stock_adjustment'); ?>">Stock Adjustments</a></li>
                                            <li><a href="<?php echo base_url('/inventory_management/admin_transfers'); ?>">Stock Transfers</a></li>

                                        <?php }
                                        if ($this->session->get_userdata()['role'] == 3) { ?>
                                            <!--                                    <li><a href="<?php //echo base_url('/inventory_management/stock_issue_patients'); 
                                                                                                    ?>">Stock Issue to Patients</a></li>-->
                                            <li><a href="<?php echo base_url('/patients/search'); ?>">Stock Issue to Patients</a></li>
                                            <li><a href="<?php echo base_url('/inventory_management/acknowledge_records'); ?>">Acknowledge Receiving</a></li>

                                        <?php } ?>
                                        <li><a href="<?php echo base_url('/inventory_management/stock_issue_search'); ?>">Stock Issue Search</a></li>
                                        <li><a href="<?php echo base_url('/inventory_management/stock_receive_search'); ?>">Stock Receive Search</a></li>

                                    </ul>
                                </li>
                            </ul>
                        </li>

                        <li class="has-submenu">
                            <a href="#"><i class="icon-setting-1"></i> CMS Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                            <ul class="submenu megamenu">
                                <div class="col-md-12">
                                    <div class="">
                                       <!--<div><span style="display:inline-block; width: 180px;">Products </span><a href="<?php echo base_url('/product_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/product_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                    <div><span style="display:inline-block; width: 180px;">Product Family (Category) </span><a href="<?php echo base_url('/productcategory_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productcategory_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Products (Generic Names) </span><a href="<?php echo base_url('/productgeneric_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productgeneric_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product Brands </span><a href="<?php echo base_url('/product_management/brand'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/product_management/addbrand'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product Strength </span><a href="<?php echo base_url('/productstrength_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productstrength_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <!--<div><span style="display:inline-block; width: 180px;">Product Sub Category </span><a href="<?php echo base_url('/productsubcategory_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productsubcategory_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                   <div><span style="display:inline-block; width: 180px;">Product Method types </span><a href="<?php echo base_url('/productmethodtype_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productmethodtype_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                        <div><span style="display:inline-block; width: 180px;">Product Manufacturer </span><a href="<?php echo base_url('/productmanufacturer_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productmanufacturer_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                        <!--<div><span style="display:inline-block; width: 180px;">Contradictory Products </span><a href="<?php echo base_url('/product_management/list_contradicts'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/product_management/contradictory_products'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                        <hr />
                                        <?php foreach ($configuration_menu as $key => $value) { ?>
                                            <!--<div><span style="display:inline-block; width: 180px;"><?php echo $value; ?> </span><a href="<?php echo base_url('/list_management/index/' . $key); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/list_management/add/' . $key); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                        <?php } ?>
                                        <!--<div><span style="display:inline-block; width: 180px;">Facility/Labs </span><a href="<?php echo base_url('/warehouse_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/warehouse_management/add_wh'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                        <div><span style="display:inline-block; width: 180px;">Facilities Types </span><a href="<?php echo base_url('/wh_types_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/wh_types_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                        <div><span style="display:inline-block; width: 180px;">Facilities Category </span><a href="<?php echo base_url('/wh_categories_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/wh_categories_management/add_wh_category'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                        <!--<div><span style="display:inline-block; width: 180px;">Cities </span><a href="<?php echo base_url('/productsubcategory_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productsubcategory_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->

                                    </div>
                                </div>
                            </ul>
                        </li>


                        <!--<li class="has-submenu">
                            <a href="#"><i class="icon-todolist"></i> Procurement <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                            <ul class="submenu megamenu">
                                <li>
                                    <ul>
                                        <li><a href="#">Add Purchase Order</a></li>
                                        <li><a href="#">Search Purchase Order</a></li>
                                        <li><a href="#">Procurment Dashboard</a></li>
                                        <li><a href="#">Procurment Report</a></li>
                                        <li><a href="#">Budget Status</a></li>
                                        <li><a href="#">Procurment Portfolio</a></li>
                                        <li><a href="#">Summary Report</a></li>
                                        <li><a href="#">Comprehensive Report</a></li>

                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="has-submenu">
                            <a href="#"><i class="icon-todolist"></i> FICO <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                            <ul class="submenu megamenu">
                                <li>
                                    <ul>
                                        <li><a href="#">Chart of Accounts</a></li>
                                        <li><a href="#">Budget & Cost Centers</a></li>
                                        <li><a href="#">Ledger</a></li>
                                        <li><a href="#">Trial Balance</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>-->


                    <?php } ?>
                </ul>
            <?php } elseif (in_array($this->session->get_userdata()['role'], array(2, 3))) {

                $configuration_menu = array(
                    2 => "Payment Methods",
                    3 => "Ward Types",
                    4 => "Diagnosis",
                    15 => "Vaccination Status",
                    16 => "Vaccine Name",
                    17 => "Covid Status",
                    18 => "Oxygen Status",
                    20 => "DIET",
                    21 => "Financial clearance"
                );


                if ($this->session->get_userdata()['role'] == 4) {
                    $configuration_menu[7] = "Discharge Reason";
                    $configuration_menu[8] = "Sample collection types";
                }

            ?>
                <ul class="navigation-menu">


                    <li class="has-submenu">
                        <a href="">&nbsp;</a>
                    </li>

                    <li class="has-submenu">
                        <a href="#"><i class="icon-paper-sheet"></i> EMR Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">

                            <div class="col-md-12">
                                <div class="">
                                    <div><span style="display:inline-block; width: 180px;">Manage Patients </span>
                                        <hr>
                                        <a href="<?php echo base_url('/patients/register'); ?>"><i class="fa fa-plus-circle"></i>Register</a> |
                                        <a href="<?php echo base_url('/patients/search'); ?>"><i class="fa fa-search"></i>Search </a> |
                                        <a href="<?php echo base_url('/patients/merge'); ?>"><i class="fa fa-settings"></i>Merge</a>
                                    </div>
                                    <?php if ($this->session->get_userdata()['role'] == 2) { ?>
                                        <hr>
                                        <li><a href="<?php echo base_url('/patients/report'); ?>">Patient Detail Report</a></li>
                                        <li><a href="<?php echo base_url('/patients/summary_report'); ?>">Patient Daily Census</a></li>
                                    <?php } ?>
                                </div>
                            </div>



                        </ul>
                    </li>

                    <!--<li class="has-submenu">
                        <a href="#"><i class="icon-setting-1"></i> CMS Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <div class="col-md-12">
                                <div class="">
                                    <?php foreach ($configuration_menu as $key => $value) { ?>
                                        <div><span style="display:inline-block; width: 180px;"><?php echo $value; ?> </span><a href="<?php echo base_url('/list_management/index/' . $key); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/list_management/add/' . $key); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <?php } ?>
                                    <hr />
                                    <div><span style="display:inline-block; width: 180px;">Facility/Labs </span><a href="<?php echo base_url('/warehouse_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/warehouse_management/add_wh'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Facilities Types </span><a href="<?php echo base_url('/wh_types_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/wh_types_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Facilities Category </span><a href="<?php echo base_url('/wh_categories_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/wh_categories_management/add_wh_category'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    --><!--<div><span style="display:inline-block; width: 180px;">Cities </span><a href="<?php echo base_url('/productsubcategory_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productsubcategory_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->

                               <!-- </div>
                            </div>
                        </ul>
                    </li>-->

                    <!--<li class="has-submenu">
                        <a href="#"><i class="icon-todolist"></i> HR <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">

                            <div class="col-md-12">
                                <div class="">
                                    <div><span style="display:inline-block; width: 180px;">Manage HR </span>
                                        <hr>
                                        <a href="<?php echo base_url('/hr_profile_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a> |
                                        <a href="<?php echo base_url('/hr_profile_management/index'); ?>"><i class="fa fa-search"></i>Search </a> |
                                        <a href="<?php echo base_url('/list_management/index/1'); ?>"><i class="fa fa-settings"></i>HR Categories</a>
                                    </div>

                                </div>
                            </div>
                        </ul>
                    </li>-->

                </ul>
                </li>

                </ul>

            <?php } elseif (in_array($this->session->get_userdata()['role'], array(8))) {

            ?>
                <ul class="navigation-menu">


                    <li class="has-submenu">
                        <a href="">&nbsp;</a>
                    </li>

                    <li class="has-submenu">
                        <a href="#"><i class="icon-paper-sheet"></i> EMR Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">

                            <div class="col-md-12">
                                <div class="">
                                    <div><span style="display:inline-block; width: 180px;">Manage Patients </span>
                                        <hr>
                                        <a href="<?php echo base_url('/patients/register'); ?>"><i class="fa fa-plus-circle"></i>Register</a> |
                                        <a href="<?php echo base_url('/patients/search'); ?>"><i class="fa fa-search"></i>Search </a> |
                                        <a href="<?php echo base_url('/patients/merge'); ?>"><i class="fa fa-settings"></i>Merge</a>
                                    </div>
                                    <?php if ($this->session->get_userdata()['role'] == 2) { ?>
                                        <hr>
                                        <li><a href="<?php echo base_url('/patients/report'); ?>">Patient Detail Report</a></li>
                                        <li><a href="<?php echo base_url('/patients/summary_report'); ?>">Patient Daily Census</a></li>
                                    <?php } ?>
                                </div>
                            </div>



                        </ul>
                    </li>



                </ul>
                </li>

                </ul>

            <?php } elseif ($this->session->get_userdata()['role'] == 6 || $this->session->get_userdata()['role'] == 9) { ?>
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#"><i class="icon-life-buoy"></i> Analytics Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <li>
                                <ul>
                                    <li><a href="<?php echo base_url('/reports/explorer'); ?>">IM Explorer</a></li>
                                    <li><a href="<?php echo base_url('/reports/soh'); ?>">Stock On Hand</a></li>
                                    <li><a href="<?php echo base_url('/reports/stock_ledger'); ?>">Stock Ledger</a></li>
                                    <li><a href="<?php echo base_url('/reports/issuance_list'); ?>">Stock Issuance Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/receive_list'); ?>">Stock Receive Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/raw_data_report'); ?>">Raw Data Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/pivot'); ?>">BI Tool</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <?php
                    $configuration_menu = array(
                        18 => "Oxygen Status"
                    );

                    ?>
                    <li class="has-submenu">
                        <a href="#"><i class="icon-todolist"></i> Inventory Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <li>
                                <ul>
                                    <li><a href="<?php echo base_url('/inventory_management/stock_receive'); ?>">Stock Receive</a></li>
                                    <li><a href="<?php echo base_url('/inventory_management/stock_receive_search'); ?>">Stock Receive Search</a></li>
                                    <li><a href="<?php echo base_url('/inventory_management/stock_issue'); ?>">Stock Issue</a></li>
                                    <!--<li><a href="<?php echo base_url('/inventory_management/stock_issue_patients'); ?>">Stock Issue to Patients</a></li>-->
                                    <li><a href="<?php echo base_url('/inventory_management/stock_issue_search'); ?>">Stock Issue Search</a></li>
                                    <li><a href="<?php echo base_url('/inventory_management/stock_adjustment'); ?>">Stock Adjustments</a></li>
                                    <!--<li><a href="<?php //echo base_url('/inventory_management/admin_transfers'); 
                                                        ?>">Stock Transfers</a></li>-->


                                </ul>
                            </li>
                        </ul>
                    </li>

                    <li class="has-submenu">
                        <a href="#"><i class="icon-setting-1"></i> CMS Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <div class="col-md-12">
                                <div class="">
                                    <!--<div><span style="display:inline-block; width: 180px;">Products </span><a href="<?php echo base_url('/product_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/product_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                    <div><span style="display:inline-block; width: 180px;">Product Family (Category) </span><a href="<?php echo base_url('/productcategory_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productcategory_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Products (Generic Names) </span><a href="<?php echo base_url('/productgeneric_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productgeneric_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product Brands </span><a href="<?php echo base_url('/product_management/brand'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/product_management/addbrand'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product Strength </span><a href="<?php echo base_url('/productstrength_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productstrength_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <!--<div><span style="display:inline-block; width: 180px;">Product Sub Category </span><a href="<?php echo base_url('/productsubcategory_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productsubcategory_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                    <div><span style="display:inline-block; width: 180px;">Product Method types </span><a href="<?php echo base_url('/productmethodtype_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productmethodtype_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product Manufacturer </span><a href="<?php echo base_url('/productmanufacturer_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productmanufacturer_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Funding Sources </span><a href="<?php echo base_url('/warehouse_management/view_supplier'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/warehouse_management/add_supplier'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    
                                    
                                    <!--<div><span style="display:inline-block; width: 180px;">Contradictory Products </span><a href="<?php echo base_url('/product_management/list_contradicts'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/product_management/contradictory_products'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                        <hr />
                                        <?php foreach ($configuration_menu as $key => $value) { ?>
                                            <!--<div><span style="display:inline-block; width: 180px;"><?php echo $value; ?> </span><a href="<?php echo base_url('/list_management/index/' . $key); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/list_management/add/' . $key); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                        <?php } ?>
                                        <!--<div><span style="display:inline-block; width: 180px;">Facility/Labs </span><a href="<?php echo base_url('/warehouse_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/warehouse_management/add_wh'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                        <div><span style="display:inline-block; width: 180px;">Facilities Types </span><a href="<?php echo base_url('/wh_types_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/wh_types_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                        <div><span style="display:inline-block; width: 180px;">Facilities Category </span><a href="<?php echo base_url('/wh_categories_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/wh_categories_management/add_wh_category'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                        <!--<div><span style="display:inline-block; width: 180px;">Cities </span><a href="<?php echo base_url('/productsubcategory_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productsubcategory_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->

                                </div>
                            </div>
                        </ul>
                    </li>


                    <!--<li class="has-submenu">
                            <a href="#"><i class="icon-todolist"></i> Procurement <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                            <ul class="submenu megamenu">
                                <li>
                                    <ul>
                                        <li><a href="#">Add Purchase Order</a></li>
                                        <li><a href="#">Search Purchase Order</a></li>
                                        <li><a href="#">Procurment Dashboard</a></li>
                                        <li><a href="#">Procurment Report</a></li>
                                        <li><a href="#">Budget Status</a></li>
                                        <li><a href="#">Procurment Portfolio</a></li>
                                        <li><a href="#">Summary Report</a></li>
                                        <li><a href="#">Comprehensive Report</a></li>

                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="has-submenu">
                            <a href="#"><i class="icon-todolist"></i> FICO <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                            <ul class="submenu megamenu">
                                <li>
                                    <ul>
                                        <li><a href="#">Chart of Accounts</a></li>
                                        <li><a href="#">Budget & Cost Centers</a></li>
                                        <li><a href="#">Ledger</a></li>
                                        <li><a href="#">Trial Balance</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>-->

                </ul>
            <?php } elseif ($this->session->get_userdata()['role'] == 10) { ?>
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#"><i class="icon-life-buoy"></i> Analytics <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <li>
                                <ul>
                                    <li><a href="<?php echo base_url('/reports/soh'); ?>">Stock On Hand</a></li>
                                    <li><a href="<?php echo base_url('/reports/stock_ledger'); ?>">Stock Ledger</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>
            <?php } elseif ($this->session->get_userdata()['role'] == 11) { ?>
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#"><i class="icon-life-buoy"></i> Analytics <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <li>
                                <ul>
                                <li><a href="<?php echo base_url('/reports/explorer'); ?>">IM Explorer</a></li>
                                    <li><a href="<?php echo base_url('/reports/soh'); ?>">Stock On Hand</a></li>
                                    <li><a href="<?php echo base_url('/reports/stock_ledger'); ?>">Stock Ledger</a></li>
                                    <li><a href="<?php echo base_url('/reports/issuance_list'); ?>">Stock Issuance Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/receive_list'); ?>">Stock Receive Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/raw_data_report'); ?>">Raw Data Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/pivot'); ?>">BI Tool</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>

            <?php } elseif ($this->session->get_userdata()['role'] == 9) { ?>
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#"><i class="icon-life-buoy"></i> Analytics Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <li>
                                <ul>
                                <li><a href="<?php echo base_url('/reports/explorer'); ?>">IM Explorer</a></li>
                                    <li><a href="<?php echo base_url('/reports/soh'); ?>">Stock On Hand</a></li>
                                    <li><a href="<?php echo base_url('/reports/stock_ledger'); ?>">Stock Ledger</a></li>
                                    <li><a href="<?php echo base_url('/reports/issuance_list'); ?>">Stock Issuance Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/receive_list'); ?>">Stock Receive Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/raw_data_report'); ?>">Raw Data Report</a></li>
                                    <li><a href="<?php echo base_url('/reports/pivot'); ?>">BI Tool</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <?php
                    $configuration_menu = array(
                        18 => "Oxygen Status"
                    );

                    ?>
                    <li class="has-submenu">
                        <a href="#"><i class="icon-todolist"></i> Inventory Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <li>
                                <ul>
                                    <li><a href="<?php echo base_url('/inventory_management/stock_receive'); ?>">Stock Receive</a></li>
                                    <li><a href="<?php echo base_url('/inventory_management/stock_receive_search'); ?>">Stock Receive Search</a></li>
                                    <li><a href="<?php echo base_url('/inventory_management/stock_issue'); ?>">Stock Issue to Centers</a></li>
                                    <li><a href="<?php echo base_url('/inventory_management/stock_issue_patients'); ?>">Stock Issue to Patients</a></li>
                                    <li><a href="<?php echo base_url('/inventory_management/stock_issue_search'); ?>">Stock Issue Search</a></li>
                                    <li><a href="<?php echo base_url('/inventory_management/stock_adjustment'); ?>">Stock Adjustments</a></li>
                                    <!--<li><a href="<?php //echo base_url('/inventory_management/admin_transfers'); 
                                                        ?>">Stock Transfers</a></li>-->


                                </ul>
                            </li>
                        </ul>
                    </li>

                    <li class="has-submenu">
                        <a href="#"><i class="icon-setting-1"></i> CMS Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <div class="col-md-12">
                                <div class="">
                                    <!--<div><span style="display:inline-block; width: 180px;">Products </span><a href="<?php echo base_url('/product_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/product_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                    <div><span style="display:inline-block; width: 180px;">Product Family (Category) </span><a href="<?php echo base_url('/productcategory_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productcategory_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Products (Generic Names) </span><a href="<?php echo base_url('/productgeneric_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productgeneric_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product Brands </span><a href="<?php echo base_url('/product_management/brand'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/product_management/addbrand'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product Strength </span><a href="<?php echo base_url('/productstrength_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productstrength_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <!--<div><span style="display:inline-block; width: 180px;">Product Sub Category </span><a href="<?php echo base_url('/productsubcategory_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productsubcategory_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                   <div><span style="display:inline-block; width: 180px;">Product Method types </span><a href="<?php echo base_url('/productmethodtype_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productmethodtype_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product Manufacturer </span><a href="<?php echo base_url('/productmanufacturer_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productmanufacturer_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>

                                </div>
                            </div>
                        </ul>
                    </li>
                </ul>
            <?php } else if ($this->session->get_userdata()['role'] == 7) { ?>
                <ul class="navigation-menu">
                    <?php
                    $configuration_menu_hr = array(
                        1 => "HR Categories",
                        6 => "HR Status",
                        9 => "Designations",
                        10 => "Departments",
                        11 => "PMC/PNC Category",
                        12 => "Blood Group",
                        13 => "Job Band",
                        14 => "Gender",
                        15 => "Vaccination Status"
                    );
                    ?>
                    <li class="has-submenu">
                        <a href="#"><i class="icon-todolist"></i> HR <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <li>
                                <ul>
                                    <li><a href="<?php echo base_url('/hr_profile_management/add'); ?>"><i class="fa fa-plus-circle"></i> Add HR Profile</a></li>
                                    <li><a href="<?php echo base_url('/hr_profile_management/index'); ?>"><i class="fa fa-search"></i> Search Profile</a></li>

                                </ul>
                            </li>
                            <hr>
                            <div class="col-md-12">
                                <div class="">

                                    <?php foreach ($configuration_menu_hr as $key => $value) { ?>
                                        <div><span style="display:inline-block; width: 180px;"><?php echo $value; ?> </span><a href="<?php echo base_url('/list_management/index/' . $key); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/list_management/add/' . $key); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <?php } ?>
                                </div>
                            </div>
                        </ul>

                    </li>
                </ul>
            <?php } else if ($this->session->get_userdata()['role'] == 5) { ?>

                <ul class="navigation-menu">


                    <li class="has-submenu">
                        <a href="<?php echo base_url('/dashboard/lab_worker'); ?>"><i class="icon-accelerator"></i> Dashboard</a>
                    </li>

                    <li class="has-submenu">
                        <a href="#"><i class="icon-paper-sheet"></i> EMR Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">

                            <div class="col-md-12">
                                <div class="">
                                    <div><span style="display:inline-block; width: 180px;">Manage Patients </span>
                                        <hr>
                                        <a href="<?php echo base_url('/patients/register'); ?>"><i class="fa fa-plus-circle"></i>Register</a> |
                                        <a href="<?php echo base_url('/patients/search'); ?>"><i class="fa fa-search"></i>Search </a> |
                                        <a href="<?php echo base_url('/patients/merge'); ?>"><i class="fa fa-settings"></i>Merge</a>
                                    </div>
                                    <?php if ($this->session->get_userdata()['role'] == 2) { ?>
                                        <hr>
                                        <li><a href="<?php echo base_url('/patients/report'); ?>">Patient Detail Report</a></li>
                                        <li><a href="<?php echo base_url('/patients/summary_report'); ?>">Patient Daily Census</a></li>
                                    <?php } ?>
                                </div>
                            </div>



                        </ul>
                    </li>

                    <li class="has-submenu">
                        <a href="#"><i class="icon-setting-1"></i> CMS Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">
                            <div class="col-md-12">
                                <div class="">
                                    <div><span style="display:inline-block; width: 180px;">Labs Order Settings </span><a href="<?php echo base_url('/lab_tests_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/lab_tests_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Lab Departments </span><a href="<?php echo base_url('/list_management/index/19'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/list_management/add/19'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                </div>
                            </div>
                            <!--                            <li>
                                                            <ul>
                                                                <li><a href="#">Manage Roles</a></li>
                                                                <li><a href="#">Manage Resources</a></li>
                                                                <li><a href="#">Manage ACL</a></li>
                                                            </ul>
                                                        </li>-->
                        </ul>
                    </li>
                </ul>
            <?php } ?>
            <!-- End navigation menu -->
        </div>
        <!-- end #navigation -->
    </div>
    <!-- end container -->
</div>
<!-- end navbar-custom -->