<?php
$products = array();
if (isset($selected) && !empty($selected)) {
    foreach ($selected->result_array() as $row1) {
        $products[] = $row1['pk_id'];
    }
}
?>
<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12">
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <div class="buttons pull-right">
                        <a href="#" id="assignbtn" class="btn btn-danger btn-icon glyphicons"><i class="fas"></i>Assign/Update Selected Products</a>  
                        <a href="<?php echo base_url("product_management/add"); ?>" class="btn btn-primary btn-icon glyphicons circle_plus"><i class="fas fa-user-plus"></i>Add New</a>
                              
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <br>
                    <div class="separator bottom"></div>
                    <div class="innerLR">
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                <div class="card-body">
                                        <br>
                                        <?php
                        if (isset($result) && !empty($result)) {
                            ?>

                                        <div id="divToPrint">
                                            <form name="assign_products" id="assign_products" action="" method="post">
                                            <table
                                                class="table table-striped table-bordered table-condensed dt-responsive "
                                                id="datatable-buttons1">
                                                <thead>
                                                    <tr>
                                                        <th style="width: 1%;" class="center"></th>
                                                        <th>Product Name</th>
                                                        <th>Generic Name</th>
                                                        <th>Strength</th>
                                                        <th>Method Type</th>
                                                        <th>Manufacturer</th>
                                                        <th>Category</th>
                                                        <th>Sub-category</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <!-- Table row -->
                                                    <?php
                                        //$count = 1;
                                        foreach ($result->result_array() as $row) {
                                            ?>
                                                    <tr>
                                                        <td class="center"><input type="checkbox" name="products[<?php echo $row['pk_id']; ?>]" id="products" 
                                                        <?php if(in_array($row['pk_id'], $products)){ ?> checked <?php } ?>
                                                        /></td>
                                                        <td><?php echo $row['product_name']; ?></td>
                                                        <td class="important"><?php echo $row['generic_name']; ?></td>
                                                        <td class="important"><?php echo $row['strength']; ?></td>
                                                        <td class="important"><?php echo $row['method_type']; ?></td>
                                                        <td class="important"><?php echo $row['manufacturer']; ?></td>
                                                        <td class="important"><?php echo $row['category']; ?></td>
                                                        <td class="important"><?php echo $row['sub_category']; ?></td>
                                                    </tr>
                                                    <?php
                                            //$count++;
                                        }
                                        ?>
                                                    <!-- // Table row END -->
                                                    <!-- Table row -->

                                                    <!-- // Table row END -->
                                                </tbody>
                                            </table>
                                            </form>
                                        </div>

                                        <!-- // Table END -->
                                        <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>