<?php
if (isset($result_edit)) {

    $row = $result_edit->result_array();
    $row = $row[0];
    $product_name = $row['product_name'];
    $generic_name_id = $row['generic_name_id'];
    $method_type_id = $row['method_type_id'];
    $strength_id = $row['strength_id'];
    $manufacturer_id = $row['manufacturer_id'];
    $category_id = $row['category_id'];
    $sub_category_id = $row['sub_category_id'];
    $registration_number = $row['registration_number'];
    $barcode = $row['barcode'];
    $gtin = $row['gtin'];
    $desc = $row['description'];
    $products_packets = $row['products_in_packet'];
    $packet_carton = $row['packet_in_cartons'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12">
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Add Items / Medicines / Products</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="add_product" name="add_product" action="<?php echo base_url("product_management/add"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Product Name <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="product_name" id="product_name" class="form-control" required="" <?php
                                                                                                                                                        if (isset($result_edit)) {
                                                                                                                                                            echo 'value="' . $product_name . '"';
                                                                                                                                                        }
                                                                                                                                                        ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Brand Name <span style="color: red">*</span>&nbsp;<a href="<?php echo base_url('/list_management/add/22'); ?>"><button class="btn btn-success btn-sm" type="button">+</button></a></label>
                                                        <div class="controls">
                                                            <?php echo create_list_combo("generic_name_id", 22, (!empty($generic_name_id) ? $generic_name_id : '')); ?>

                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="strength" required>Strength  &nbsp;<a href="<?php echo base_url('/productstrength_management/add'); ?>"><button class="btn btn-success btn-sm" type="button">+</button></a></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="strength_id" id="strength_id" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($strength as $row) {
                                                            ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($strength_id) && $strength_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['strength'] ?></option>
                                                            <?php
                                                            }
                                                            ?>

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="method_type" required>Method type &nbsp;<a href="<?php echo base_url('/productmethodtype_management/add'); ?>"><button class="btn btn-success btn-sm" type="button">+</button></a></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="method_type_id" id="method_type_id" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($method_type as $row) {
                                                            ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($method_type_id) && $method_type_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['method_type'] ?></option>
                                                            <?php
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="manufacturer" required>Manufacturer <span style="color: red">*</span> &nbsp;<a href="<?php echo base_url('/productmanufacturer_management/add'); ?>"><button class="btn btn-success btn-sm" type="button">+</button></a></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="manufacturer_id" id="manufacturer_id" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($manufacturer as $row) {
                                                            ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($manufacturer_id) && $manufacturer_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['manufacturer'] ?></option>
                                                            <?php
                                                            }
                                                            ?>

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="category" required>Category &nbsp;<a href="<?php echo base_url('/productcategory_management/add'); ?>"><button class="btn btn-success btn-sm" type="button">+</button></a></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="category_id" id="category_id" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($category as $row) {
                                                            ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($category_id) && $category_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['category'] ?></option>
                                                            <?php
                                                            }
                                                            ?>

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="sub_category" required>Sub Category &nbsp;<a href="<?php echo base_url('/productsubcategory_management/add'); ?>"><button class="btn btn-success btn-sm" type="button">+</button></a></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="sub_category_id" id="sub_category_id" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($sub_category as $row) {
                                                            ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($sub_category_id) && $sub_category_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['sub_category'] ?></option>
                                                            <?php
                                                            }
                                                            ?>

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="registration_number" required>Registration Number (DRAP Number) </label>
                                                        <div class="controls">
                                                            <input type="text" name="registration_number" id="registration_number" class="form-control" <?php
                                                                                                                                                        if (isset($result_edit)) {
                                                                                                                                                            echo 'value="' . $registration_number . '"';
                                                                                                                                                        }
                                                                                                                                                        ?>>
                                                        </div>
                                                    </div>
                                                </div>


                                            </div>

                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Barcode </label>
                                                        <div class="controls">
                                                            <input type="text" name="barcode" id="barcode" class="form-control" <?php
                                                                                                                                if (isset($result_edit)) {
                                                                                                                                    echo 'value="' . $barcode . '"';
                                                                                                                                }
                                                                                                                                ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Code/GTIN </label>
                                                        <div class="controls">
                                                            <input type="text" name="gtin" id="gtin" class="form-control" <?php
                                                                                                                            if (isset($result_edit)) {
                                                                                                                                echo 'value="' . $gtin . '"';
                                                                                                                            }
                                                                                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>Description </label>
                                                        <div class="controls">
                                                            <input type="text" name="description" id="description" class="form-control" <?php
                                                                                                                                        if (isset($result_edit)) {
                                                                                                                                            echo 'value="' . $desc . '"';
                                                                                                                                        }
                                                                                                                                        ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>No of products in one packet </label>
                                                        <div class="controls">
                                                            <input type="text" name="products_packet" id="products_packet" class="form-control" <?php
                                                                                                                                                if (isset($result_edit)) {
                                                                                                                                                    echo 'value="' . $products_packets . '"';
                                                                                                                                                }
                                                                                                                                                ?>>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required>No of packets in one carton </label>
                                                        <div class="controls">
                                                            <input type="text" name="packets_carton" id="packets_carton" class="form-control" <?php
                                                                                                                                                if (isset($result_edit)) {
                                                                                                                                                    echo 'value="' . $packet_carton . '"';
                                                                                                                                                }
                                                                                                                                                ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                                                                                                                        if (isset($result_edit))
                                                                                                                                                            echo 'value="edit"';
                                                                                                                                                        ?>>
                                                        <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div>

                                                <input type="hidden" name="generic_name" id="generic_name" value="">
                                                <input type="hidden" name="strength" id="strength" value="">
                                                <input type="hidden" name="method_type" id="method_type" value="">
                                                <input type="hidden" name="manufacturer" id="manufacturer" value="">
                                                <input type="hidden" name="category" id="category" value="">
                                                <input type="hidden" name="sub_category" id="sub_category" value="">
                                                <?php if (isset($result_edit)) {
                                                ?>
                                                    <input type="hidden" name="pk_id" id="pk_id" value="<?php echo $_REQUEST['id'] ?>">
                                                <?php }
                                                ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>