<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12">
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Products</h3>
                        <div class="buttons pull-right">
                            <a href="<?php echo base_url("product_management/add"); ?>"
                                class="btn btn-primary btn-icon glyphicons circle_plus"><i class="fas fa-user-plus"></i>
                                Add</a>
                                <a href="<?php echo base_url("product_management/assign"); ?>"
                                class="btn btn-primary btn-icon glyphicons circle_plus"><i class="fas fa-user-plus"></i>
                                Import Products</a>
                        </div>
                        <div class="clearfix"></div>
                        <br>
                    </div>
                    <div class="separator bottom"></div>
                    <div class="innerLR">
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <br>
                                        <?php
                        if (isset($result) && !empty($result)) {
                            ?>

                                        <div id="divToPrint">
                                            <table
                                                class="table table-striped table-bordered table-condensed dt-responsive "
                                                id="datatable-buttons">
                                                <thead>
                                                    <tr>
                                                        <th style="width: 1%;" class="center">No.</th>
                                                        <th>Product Name</th>
                                                        <th>Generic Name</th>
                                                        <th>Strength</th>
                                                        <th>Method Type</th>
                                                        <th>Manufacturer</th>
                                                        <th>Category</th>
                                                        <th>Sub-category</th>
                                                        <th>Action</th>
                                                        <!--<th style="width:100px;"></th>-->
                                                        <!--<th></th>-->
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <!-- Table row -->
                                                    <?php
                                        $count = 1;
//        echo '<pre>';
//        print_r($result->result_array());
//        exit;
                                        foreach ($result->result_array() as $row) {
                                            ?>
                                                    <tr>
                                                        <td class="center"><?php echo $count; ?></td>
                                                        <td><?php echo $row['product_name']; ?></td>
                                                        <td class="important"><?php echo $row['generic_name']; ?></td>
                                                        <td class="important"><?php echo $row['strength']; ?></td>
                                                        <td class="important"><?php echo $row['method_type']; ?></td>
                                                        <td class="important"><?php echo $row['manufacturer']; ?></td>
                                                        <td class="important"><?php echo $row['category']; ?></td>
                                                        <td class="important"><?php echo $row['sub_category']; ?></td>
                                                        <td> <a href="<?php echo base_url("product_management/edit?id=") . $row['pk_id']; ?> "
                                                                class="btn btn-danger" title="edit">Edit</a>
                                                        </td>
                                                        <!--<td> <a onclick="return confirm('Are you sure you want to remove this product?');"
                                                                href="<?php //echo base_url("product_management/unassign?id=") . $row['pk_id']; ?>"
                                                                class="btn btn-sm btn-light glyphicons bin"><i
                                                                    class="fas fa-check success"></i> Remove</a>
                                                        </td>-->
                                                    </tr>
                                                    <?php
                                            $count++;
                                        }
                                        ?>
                                                    <!-- // Table row END -->
                                                    <!-- Table row -->

                                                    <!-- // Table row END -->
                                                </tbody>
                                            </table>
                                        </div>

                                        <!-- // Table END -->
                                        <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>