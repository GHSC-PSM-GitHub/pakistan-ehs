<?php
//print_r($result_edit);exit;
if (isset($result_edit)) {

    $row = $result_edit->result_array();
    $row = $row[0];
    $generic_name = $row['generic_name'];
    $category_id = $row['category_id'];  
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Add Generic Name</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="add_ext_system" name="add_ext_system" action="<?php echo base_url("Productgeneric_management/add"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row"> 
                                                 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="ext_system" >Generic Name <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="generic_name" id="generic_name" required style="width:100%;" 
                                                               <?php
                                                               if(isset($generic_name))
                                                               {
                                                                   echo 'value="'.$generic_name.'"';
                                                               }
                                                               ?>
                                                               >
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="ext_system" >Family <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <?php echo create_combo("category_id", $categories, (!empty($category_id) ? $category_id : "" )); ?>
                                                    </div>
                                                </div>
                                            </div> 
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                            if (isset($result))
                                                                echo 'value="edit"';
                                                            ?>>
                                                            <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 
                                                <?php if(isset($result_edit)){?>
                                                <input type="hidden" id="id" name="id" value="<?php echo $_REQUEST['id'] ?>">
                                                <?php
                                                }
                                                ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                    
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>
 