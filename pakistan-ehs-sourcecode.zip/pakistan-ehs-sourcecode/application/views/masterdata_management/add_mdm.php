<?php
if (isset($result)) {

    $row = $result->result_array();
    $row = $row[0];
    $stakeholder_id = $row['stakeholder_id'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Master Data Management</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="addmdm" name="addmdm" action="<?php echo base_url("Masterdata_management/add_mdm"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row"> 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="mdm_type" required >Master Data Type <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="form-control" name="mdm_type" id="mdm_type" required style="width:100%;" disabled='true'>
                                                            <option value="">Select</option>
                                                            <option value="warehouse" <?php if ($_REQUEST['type'] == 'warehouse') echo 'selected="selected"'; ?>>Warehouse</option>
                                                            <option value="location" <?php if ($_REQUEST['type'] == 'location') echo 'selected="selected"'; ?>>Location</option>
                                                            <option value="patient" <?php if ($_REQUEST['type'] == 'patient') echo 'selected="selected"'; ?>>Patient</option>

                                                        </select>  
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="entity" required >Entity <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="entity" id="entity" required style="width:100%;" readonly='true'>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="ext_system" required >External systems <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="ext_system" id="ext_system" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            if (isset($ext_systems)) {
                                                                $ext_systems_array = $ext_systems->result_array();
                                                                foreach ($ext_systems_array as $row) {
                                                                    ?>
                                                                    <option value="<?php echo $row['pk_id'] ?>" ><?php echo $row['external_system_name'] ?></option>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="external_pk" required >External System id/code <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="external_pk" id="external_pk" class="form-control" required=""
                                                            <?php
                                                            if (isset($result)) {
                                                                echo 'value="' . $wh_name . '"';
                                                            }
                                                            ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>  
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="external_name" ><?php if($_REQUEST['type']=='patient') echo 'External System Patient MR No.'; else { echo 'External System Entity Name'; } ?> <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="external_name" id="external_name" class="form-control" required=""
                                                            <?php
                                                            if (isset($result)) {
                                                                echo 'value="' . $wh_name . '"';
                                                            }
                                                            ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                    if (isset($result))
                                                        echo 'value="edit"';
                                                    ?>>
                                                        <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 

                                                <input type="hidden" id="type" name="type" value="<?php echo $_REQUEST['type'] ?>">
                                                <input type="hidden" id="id" name="id" value="<?php echo $_REQUEST['id'] ?>">
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>