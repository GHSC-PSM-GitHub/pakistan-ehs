<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12">
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <!-- // Heading END -->
                    <h3>Master Data</h3>

                    <div class="innerLR">
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <br>
                                        <?php
                                        if (isset($result) && !empty($result)) {
                                        ?>

                                            <div id="divToPrint">
                                                <table id="datatable-buttons" class="table table-striped table-bordered table-condensed dt-responsive nowrap">
                                                    <thead>
                                                        <tr>
                                                            <th class="center">No.</th>
                                                            <th>Entity Name</th>
                                                            <th>Entity Type</th>
                                                            <th>External System</th>
                                                            <th>ID/Code in External System </th>
                                                            <th>Name/MR No. in External System </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <!-- Table row -->
                                                        <?php
                                                        $count = 1;
                                                        foreach ($result->result_array() as $row) {
                                                        ?>
                                                            <tr>
                                                                <td class="center"><?php echo $count; ?></td>
                                                                <td><?php
                                                                    if ($row['entity_type'] == 'warehouse') {
                                                                        echo $row['warehouse_name'];
                                                                    } else {
                                                                        echo $row['location_name'];
                                                                    }
                                                                    ?></td>
                                                                <td class="important">
                                                                    <?php echo ucfirst($row['entity_type']) ?>
                                                                </td>
                                                                <td> <?php echo $row['external_system_name'] ?> </td>
                                                                <td> <?php echo $row['external_pk'] ?> </td>
                                                                <td> <?php echo $row['external_entity_name'] ?> </td>
                                                            </tr>
                                                        <?php
                                                            $count++;
                                                        }
                                                        ?>
                                                        <!-- // Table row END -->
                                                        <!-- Table row -->

                                                        <!-- // Table row END -->
                                                    </tbody>
                                                </table>
                                            </div>

                                            <!-- // Table END -->
                                        <?php
                                        } else {
                                            echo "<hr><h5>No data found!</h5>";
                                        }
                                        ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>