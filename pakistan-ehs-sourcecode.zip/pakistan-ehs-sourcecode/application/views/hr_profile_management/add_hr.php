<?php
//print_r($users);exit;
$hr_type_id = $hr_status_id = '';
$label = "Add";
if (isset($result_edit)) {

    $row = $result_edit->result_array();
    $row = $row[0];
    foreach($row as $k=>$v){
        $$k = $v;
    }
    $label = "Update";
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12">
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3><?php echo $label; ?> HR Profile</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="add_hr" name="add_hr" action="<?php echo base_url("Hr_profile_management/add"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="pmdc_number">Employee Number </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="pmdc_number" id="pmdc_number" placeholder="leave empty to auto generate" style="width:100%;" <?php
                                                                                                                                                                                                    if (isset($pmdc_number)) {
                                                                                                                                                                                                        echo 'value="' . $pmdc_number . '"';
                                                                                                                                                                                                    }
                                                                                                                                                                                                    ?>>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="full_name">Full Name <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="full_name" id="full_name" required style="width:100%;" <?php
                                                                                                                                                                if (isset($full_name)) {
                                                                                                                                                                    echo 'value="' . $full_name . '"';
                                                                                                                                                                }
                                                                                                                                                                ?>>
                                                    </div>
                                                </div>


                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="cnic_number">CNIC Number</label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="cnic_number" id="cnic_number" style="width:100%;" <?php
                                                                                                                                                        if (isset($cnic_number)) {
                                                                                                                                                            echo 'value="' . $cnic_number . '"';
                                                                                                                                                        }
                                                                                                                                                        ?>>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="hr_type" required>HR Status </label>
                                                    <div class="controls">
                                                        <?php echo create_list_combo("hr_status", 6, (!empty($hr_status_id) ? $hr_status_id : 112)); ?>

                                                    </div>
                                                </div>

                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="designation">Designation <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <?php echo create_list_combo("designation", 9, (!empty($designation) ? $designation : 78)); ?>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="department">Department <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <?php echo create_list_combo("department", 10, (!empty($department) ? $department : 93)); ?>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="hr_type" required>HR Category </label>
                                                    <div class="controls">
                                                        <?php echo create_list_combo("hr_type", 1, (!empty($hr_type_id) ? $hr_type_id : 6)); ?>

                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="link_user" required>Link User </label>
                                                    <div class="controls">
                                                        <select class="select2me" name="link_user" id="link_user" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($users as $row) {
                                                            ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($link_user) && $link_user == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['login_id'] ?></option>
                                                            <?php
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="reg_number">Registration Number </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="reg_number" id="reg_number" placeholder="" style="width:100%;" <?php
                                                                                                                                                                        if (isset($reg_number)) {
                                                                                                                                                                            echo 'value="' . $reg_number . '"';
                                                                                                                                                                        }
                                                                                                                                                                        ?>>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="pmc_expiry">PMC/PNC Expiry </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="pmc_expiry" id="pmc_expiry" placeholder="" style="width:100%;" <?php
                                                                                                                                                                        if (isset($pmc_expiry)) {
                                                                                                                                                                            echo 'value="' . convert_date($pmc_expiry,"toview") . '"';
                                                                                                                                                                        }
                                                                                                                                                                        ?>>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="pmc_category">PMC/PNC Category <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <?php echo create_list_combo("pmc_category", 11, @$pmc_category); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="blood_group">Blood Group <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <?php echo create_list_combo("blood_group", 12, (!empty($blood_group) ? $blood_group : 27)); ?>
                                                    </div>
                                                </div>


                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="doj">Date of Joining </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="doj" id="doj" placeholder="" style="width:100%;" <?php if (isset($doj)) {
                                                                                                                                                            echo 'value="' . convert_date($doj,"toview") . '"';
                                                                                                                                                        } ?>>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="job_band">Job Band <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <?php echo create_list_combo("job_band", 13, (!empty($job_band) ? $job_band : 28)); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="address">Address </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="address" id="address" placeholder="" style="width:100%;" <?php if (isset($address)) {
                                                                                                                                                                    echo 'value="' . $address . '"';
                                                                                                                                                                } ?>>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="pcn">Primary Contact Number </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="pcn" id="pcn" placeholder="" style="width:100%;" <?php if (isset($pcn)) {
                                                                                                                                                            echo 'value="' . $pcn . '"';
                                                                                                                                                        } ?>>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="email">Email Address </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="email" id="email" placeholder="" style="width:100%;" <?php if (isset($email)) {
                                                                                                                                                            echo 'value="' . $email . '"';
                                                                                                                                                        } ?>>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="em_contact">Emergency Contact </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="em_contact" id="em_contact" placeholder="" style="width:100%;" <?php if (isset($em_contact)) {
                                                                                                                                                            echo 'value="' . $em_contact . '"';
                                                                                                                                                        } ?>>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="em_contact_no">Emergency Contact Number </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="em_contact_no" id="em_contact_no" placeholder="" style="width:100%;" <?php if (isset($em_contact_no)) {
                                                                                                                                                            echo 'value="' . $em_contact_no . '"';
                                                                                                                                                        } ?>>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="experience">Experience </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="experience" id="experience" placeholder="" style="width:100%;" <?php if (isset($experience)) {
                                                                                                                                                            echo 'value="' . $experience . '"';
                                                                                                                                                        } ?>>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                            <div class="col-md-3">
                                                    <label class="example-text-input" for="education">Education </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="education" id="education" placeholder="" style="width:100%;" <?php if (isset($education)) {
                                                                                                                                                            echo 'value="' . $education . '"';
                                                                                                                                                        } ?>>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="dob">Date of Birth </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="dob" id="dob" placeholder="" style="width:100%;" <?php if (isset($dob)) {
                                                                                                                                                            echo 'value="' . convert_date($dob,"toview") . '"';
                                                                                                                                                        } ?>>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="gender">Gender </label>
                                                    <div class="controls">
                                                    <?php echo create_list_combo("gender", 14, (!empty($gender) ? $gender : 29)); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="hf" required>Facility</label>
                                                    <div class="controls">
                                                        <select class="select2me" id="hf" name="hf" required="true" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($hf as $row) {
                                                            ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if ((isset($warehouse_id) && $warehouse_id == $row['pk_id']) || $row['pk_id'] == 1) echo "selected='selected'"; ?>><?php echo $row['warehouse_name'] ?></option>
                                                            <?php
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                                                                                                                        if (isset($result))
                                                                                                                                                            echo 'value="edit"';
                                                                                                                                                        ?>>
                                                        <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div>
                                                <?php if (isset($result_edit)) { ?>
                                                    <input type="hidden" id="id" name="id" value="<?php echo $_REQUEST['id'] ?>">
                                                <?php
                                                }
                                                ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>

                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>