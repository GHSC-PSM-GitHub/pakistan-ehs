/*
 Navicat Premium Data Transfer

 Source Server         : MySQL
 Source Server Type    : MySQL
 Source Server Version : 100422
 Source Host           : localhost:3306
 Source Schema         : ehs

 Target Server Type    : MySQL
 Target Server Version : 100422
 File Encoding         : 65001

 Date: 10/06/2024 17:11:09
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for cities
-- ----------------------------
DROP TABLE IF EXISTS `cities`;
CREATE TABLE `cities`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `city_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 100 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for data_detail
-- ----------------------------
DROP TABLE IF EXISTS `data_detail`;
CREATE TABLE `data_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `data_master_id` int NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `years1217` int NULL DEFAULT NULL,
  `years18` int NULL DEFAULT NULL,
  `total` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for data_master
-- ----------------------------
DROP TABLE IF EXISTS `data_master`;
CREATE TABLE `data_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `wh_id` int NULL DEFAULT NULL,
  `auto_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `submission_date` datetime NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp,
  `updated_at` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for departments
-- ----------------------------
DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'Hospitals Departments' ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for external_systems
-- ----------------------------
DROP TABLE IF EXISTS `external_systems`;
CREATE TABLE `external_systems`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `external_system_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for funding_sources
-- ----------------------------
DROP TABLE IF EXISTS `funding_sources`;
CREATE TABLE `funding_sources`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `funding_source_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` tinyint NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for hr_profile
-- ----------------------------
DROP TABLE IF EXISTS `hr_profile`;
CREATE TABLE `hr_profile`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `designation` int NULL DEFAULT NULL,
  `pmdc_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `cnic_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` tinyint NULL DEFAULT NULL,
  `warehouse_id` int NULL DEFAULT NULL,
  `hr_type_id` int NULL DEFAULT NULL,
  `hr_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `link_user` int NULL DEFAULT NULL,
  `hr_status_id` int NULL DEFAULT NULL,
  `department` int NULL DEFAULT NULL,
  `reg_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `pmc_expiry` date NULL DEFAULT NULL,
  `pmc_category` int NULL DEFAULT NULL,
  `blood_group` int NULL DEFAULT NULL,
  `doj` date NULL DEFAULT NULL,
  `job_band` int NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `pcn` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `em_contact` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `em_contact_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `experience` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `education` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `dob` date NULL DEFAULT NULL,
  `gender` int NULL DEFAULT NULL,
  `stakeholder_id` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 286 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hr_types
-- ----------------------------
DROP TABLE IF EXISTS `hr_types`;
CREATE TABLE `hr_types`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'Hospitals Departments' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for initial_checkup
-- ----------------------------
DROP TABLE IF EXISTS `initial_checkup`;
CREATE TABLE `initial_checkup`  (
  `pk_id` int NOT NULL,
  `patient_id` int NULL DEFAULT NULL,
  `temprature` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `bp` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `heart_pulse` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `other` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `checkup_date` datetime NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lab_test_detail
-- ----------------------------
DROP TABLE IF EXISTS `lab_test_detail`;
CREATE TABLE `lab_test_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `lab_test_master_id` int NULL DEFAULT NULL,
  `lab_test_master_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `test_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `unit` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ref_range_min_male` int NULL DEFAULT NULL,
  `ref_range_max_male` int NULL DEFAULT NULL,
  `ref_range_min_female` int NULL DEFAULT NULL,
  `ref_range_max_female` int NULL DEFAULT NULL,
  `ref_range_min_general` int NULL DEFAULT NULL,
  `ref_range_max_general` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  `sample_type_id` int NULL DEFAULT NULL,
  `sample_type_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 98 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'lab_test_detail' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lab_test_master
-- ----------------------------
DROP TABLE IF EXISTS `lab_test_master`;
CREATE TABLE `lab_test_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `department_id` int NULL DEFAULT NULL,
  `final_result` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `comments` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'lab_test_master' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lab_types
-- ----------------------------
DROP TABLE IF EXISTS `lab_types`;
CREATE TABLE `lab_types`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'Hospitals Departments' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for list_detail
-- ----------------------------
DROP TABLE IF EXISTS `list_detail`;
CREATE TABLE `list_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `list_value` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `rank` int NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `list_master_id` int NULL DEFAULT NULL,
  `created_by` int NOT NULL DEFAULT 1,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp,
  `modified_by` int NULL DEFAULT 1,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE,
  UNIQUE INDEX `list_value`(`list_value`, `list_master_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 197 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for list_master
-- ----------------------------
DROP TABLE IF EXISTS `list_master`;
CREATE TABLE `list_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `list_master_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `role_id` int NULL DEFAULT NULL,
  `created_by` int NOT NULL DEFAULT 1,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp,
  `modified_by` int NOT NULL DEFAULT 1,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for locations
-- ----------------------------
DROP TABLE IF EXISTS `locations`;
CREATE TABLE `locations`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `location_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `location_level` int NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `location_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_by` int NOT NULL DEFAULT 1,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `modified_by` int NOT NULL DEFAULT 1,
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '1',
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10024 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for master_data
-- ----------------------------
DROP TABLE IF EXISTS `master_data`;
CREATE TABLE `master_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `entity_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `entity_pk` int NULL DEFAULT NULL,
  `external_system_id` int NULL DEFAULT NULL,
  `external_pk` int NULL DEFAULT NULL,
  `external_entity_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_allocation
-- ----------------------------
DROP TABLE IF EXISTS `patient_allocation`;
CREATE TABLE `patient_allocation`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `date` datetime NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `wh_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `consultant_id` int NULL DEFAULT NULL,
  `consultant_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `notes` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `patient_condition` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  `nurse_id` int NULL DEFAULT NULL,
  `nurse_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `bed_no_allocated` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_clinical_notes
-- ----------------------------
DROP TABLE IF EXISTS `patient_clinical_notes`;
CREATE TABLE `patient_clinical_notes`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `checkup_date` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `hr_type_id` int NULL DEFAULT NULL,
  `hr_id` int NULL DEFAULT NULL,
  `notes` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  `diagnosis` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3000 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_ipd
-- ----------------------------
DROP TABLE IF EXISTS `patient_ipd`;
CREATE TABLE `patient_ipd`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `admission_date` datetime NULL DEFAULT NULL,
  `ward_id` int NULL DEFAULT NULL,
  `ward_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `notes` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `patient_condition` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_lab_detail
-- ----------------------------
DROP TABLE IF EXISTS `patient_lab_detail`;
CREATE TABLE `patient_lab_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_lab_master_id` int NULL DEFAULT NULL,
  `lab_test_detail_id` int NULL DEFAULT NULL,
  `lab_test_detail_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `lab_test_master_id` int NULL DEFAULT NULL,
  `lab_test_master_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `test_result` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `patient_id` int NULL DEFAULT NULL,
  `patient_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  `verified_date` datetime NULL DEFAULT NULL,
  `verified_by` int NULL DEFAULT NULL,
  `comments` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 134 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'patient_lab_detail' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_lab_master
-- ----------------------------
DROP TABLE IF EXISTS `patient_lab_master`;
CREATE TABLE `patient_lab_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `patient_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL,
  `province_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `district_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `tehsil_id` int NULL DEFAULT NULL,
  `tehsil_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `uc_id` int NULL DEFAULT NULL,
  `uc_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `hf_id` int NULL DEFAULT NULL,
  `hf_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `department_id` int NULL DEFAULT NULL,
  `department_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `lab_test_master_id` int NULL DEFAULT NULL,
  `lab_test_master_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `lab_test_master_description` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sample_datetime` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sample_collection_type_id` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sample_collection_type_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  `ordered_date` datetime NULL DEFAULT NULL,
  `ordered_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'Patients Test Main Table' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_other_products
-- ----------------------------
DROP TABLE IF EXISTS `patient_other_products`;
CREATE TABLE `patient_other_products`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `visit_code` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `product_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `quantity` int NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 128 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_preliminary_exam
-- ----------------------------
DROP TABLE IF EXISTS `patient_preliminary_exam`;
CREATE TABLE `patient_preliminary_exam`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `examination_date` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `indicator_id` int NULL DEFAULT NULL,
  `indicator_value` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 275 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_prescriptions
-- ----------------------------
DROP TABLE IF EXISTS `patient_prescriptions`;
CREATE TABLE `patient_prescriptions`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `patient_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `medicine_id` int NULL DEFAULT NULL,
  `medicine_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `medicine_type` int NULL DEFAULT NULL,
  `dose` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `method` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `days` int NULL DEFAULT NULL,
  `schedule` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `schedule_start_date` date NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_rdt
-- ----------------------------
DROP TABLE IF EXISTS `patient_rdt`;
CREATE TABLE `patient_rdt`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `rdt_id` int NULL DEFAULT NULL,
  `result` enum('Error','Negative','Positive') CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `test_date` timestamp NULL DEFAULT current_timestamp,
  `result_date` datetime NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  UNIQUE INDEX `patient_id`(`patient_id`, `rdt_id`, `result`, `test_date`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_status
-- ----------------------------
DROP TABLE IF EXISTS `patient_status`;
CREATE TABLE `patient_status`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `visit_date` datetime NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `wh_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `consultant_id` int NULL DEFAULT NULL,
  `consultant_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `notes` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `diagnosis` int NULL DEFAULT NULL,
  `visit_fees` int NULL DEFAULT NULL,
  `payment_method` int NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 51837 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patients
-- ----------------------------
DROP TABLE IF EXISTS `patients`;
CREATE TABLE `patients`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `prefix` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `full_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `mr_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `date_of_birth` date NULL DEFAULT NULL,
  `marital_status` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `nic_no` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `city` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `province` int NULL DEFAULT NULL,
  `district` int NULL DEFAULT NULL,
  `tehsil` int NULL DEFAULT NULL,
  `uc` int NULL DEFAULT NULL,
  `father_guardian_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `mobile_no` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `payment` int NULL DEFAULT NULL,
  `payment_method` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT 1,
  `is_nadra_verified` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int NULL DEFAULT NULL,
  `vaccination_status` int NULL DEFAULT NULL,
  `last_dose_date` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `vaccine_name` int NULL DEFAULT NULL,
  `covid_status` int NULL DEFAULT NULL,
  `oxygen_status` int NULL DEFAULT NULL,
  `date_of_discharge` datetime NULL DEFAULT NULL,
  `discharge_reason` int NULL DEFAULT NULL,
  `discharge_notes` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `stakeholder_id` int NULL DEFAULT 1,
  `landline` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `country` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `passport_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  UNIQUE INDEX `full_name`(`full_name`, `nic_no`) USING BTREE,
  INDEX `mr_no`(`mr_no`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 52614 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patients_copy1
-- ----------------------------
DROP TABLE IF EXISTS `patients_copy1`;
CREATE TABLE `patients_copy1`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `prefix` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `full_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `mr_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `date_of_birth` date NULL DEFAULT NULL,
  `marital_status` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `nic_no` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `city` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `province` int NULL DEFAULT NULL,
  `district` int NULL DEFAULT NULL,
  `tehsil` int NULL DEFAULT NULL,
  `uc` int NULL DEFAULT NULL,
  `father_guardian_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `mobile_no` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `payment` int NULL DEFAULT NULL,
  `payment_method` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT 1,
  `is_nadra_verified` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int NULL DEFAULT NULL,
  `vaccination_status` int NULL DEFAULT NULL,
  `last_dose_date` date NULL DEFAULT NULL,
  `vaccine_name` int NULL DEFAULT NULL,
  `covid_status` int NULL DEFAULT NULL,
  `oxygen_status` int NULL DEFAULT NULL,
  `date_of_discharge` datetime NULL DEFAULT NULL,
  `discharge_reason` int NULL DEFAULT NULL,
  `discharge_notes` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `stakeholder_id` int NULL DEFAULT 1,
  `landline` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  UNIQUE INDEX `full_name`(`full_name`, `nic_no`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2093 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `generic_name_id` int NULL DEFAULT NULL,
  `generic_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength_id` int NULL DEFAULT NULL,
  `method_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `method_type_id` int NULL DEFAULT NULL,
  `manufacturer` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `manufacturer_id` int NULL DEFAULT NULL,
  `category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `sub_category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sub_category_id` int NULL DEFAULT NULL,
  `registration_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `barcode` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `gtin` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `products_in_packet` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `packet_in_cartons` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  `daily_units_in_single_item` int NULL DEFAULT NULL,
  `issuance_limit` int NULL DEFAULT 0,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1377 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_brands
-- ----------------------------
DROP TABLE IF EXISTS `product_brands`;
CREATE TABLE `product_brands`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `generic_name_id` int NULL DEFAULT NULL,
  `generic_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength_id` int NULL DEFAULT NULL,
  `method_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `method_type_id` int NULL DEFAULT NULL,
  `manufacturer` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `manufacturer_id` int NULL DEFAULT NULL,
  `category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `sub_category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sub_category_id` int NULL DEFAULT NULL,
  `registration_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `barcode` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `gtin` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `products_in_packet` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `packet_in_cartons` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  `daily_units_in_single_item` int NULL DEFAULT NULL,
  `issuance_limit` int NULL DEFAULT 0,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 512 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_category
-- ----------------------------
DROP TABLE IF EXISTS `product_category`;
CREATE TABLE `product_category`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 58 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_contradicts
-- ----------------------------
DROP TABLE IF EXISTS `product_contradicts`;
CREATE TABLE `product_contradicts`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `generic_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `generic_name_id` int NULL DEFAULT NULL,
  `contrast_product_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_generic_name
-- ----------------------------
DROP TABLE IF EXISTS `product_generic_name`;
CREATE TABLE `product_generic_name`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `generic_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 740 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_manufacturer
-- ----------------------------
DROP TABLE IF EXISTS `product_manufacturer`;
CREATE TABLE `product_manufacturer`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `manufacturer` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 119 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_method_type
-- ----------------------------
DROP TABLE IF EXISTS `product_method_type`;
CREATE TABLE `product_method_type`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `method_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_oldd
-- ----------------------------
DROP TABLE IF EXISTS `product_oldd`;
CREATE TABLE `product_oldd`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `generic_name_id` int NULL DEFAULT NULL,
  `generic_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength_id` int NULL DEFAULT NULL,
  `method_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `method_type_id` int NULL DEFAULT NULL,
  `manufacturer` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `manufacturer_id` int NULL DEFAULT NULL,
  `category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `sub_category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sub_category_id` int NULL DEFAULT NULL,
  `registration_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `barcode` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `gtin` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `products_in_packet` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `packet_in_cartons` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_strength
-- ----------------------------
DROP TABLE IF EXISTS `product_strength`;
CREATE TABLE `product_strength`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `strength` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1377 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_sub_category
-- ----------------------------
DROP TABLE IF EXISTS `product_sub_category`;
CREATE TABLE `product_sub_category`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `sub_category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for raw_data_report
-- ----------------------------
DROP TABLE IF EXISTS `raw_data_report`;
CREATE TABLE `raw_data_report`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `batch_number` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `batch_expiry` date NULL DEFAULT NULL,
  `product_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `generic_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `method_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `manufacturer` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `prescribed_quantity` bigint NULL DEFAULT NULL,
  `quantity` bigint NULL DEFAULT NULL,
  `transaction_date` date NULL DEFAULT NULL,
  `transaction_reference` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `trans_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `trans_nature` varchar(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `from_wh` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `to_wh` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cnic` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `mr_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `remarks` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `username` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `designation` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `hospital` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 93543 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for rdt_list
-- ----------------------------
DROP TABLE IF EXISTS `rdt_list`;
CREATE TABLE `rdt_list`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `rdt_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT 1,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `approved_by` int NULL DEFAULT 1,
  `approved_date` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for resource_types
-- ----------------------------
DROP TABLE IF EXISTS `resource_types`;
CREATE TABLE `resource_types`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `resource_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int NOT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `created_by`(`created_by`) USING BTREE,
  INDEX `modified_by`(`modified_by`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for resources
-- ----------------------------
DROP TABLE IF EXISTS `resources`;
CREATE TABLE `resources`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `resource_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `page_title` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `meta_title` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `meta_description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `rank` int NULL DEFAULT NULL,
  `level` int NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `resource_type_id` int NOT NULL,
  `icon_class` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `modified_by` int NOT NULL,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `resource_type_id`(`resource_type_id`) USING BTREE,
  INDEX `resources_created_by_users_pk`(`created_by`) USING BTREE,
  INDEX `resources_created_by_users_pk2`(`modified_by`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for role_resources
-- ----------------------------
DROP TABLE IF EXISTS `role_resources`;
CREATE TABLE `role_resources`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `permission` enum('DENY','ALLOW') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'ALLOW',
  `role_id` int NOT NULL,
  `resource_id` int NOT NULL,
  `is_default` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `role_resources_roles_fk1`(`role_id`) USING BTREE,
  INDEX `role_resources_resources_fk2`(`resource_id`) USING BTREE,
  CONSTRAINT `role_resources_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `role_resources_ibfk_2` FOREIGN KEY (`resource_id`) REFERENCES `resources` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `role_level_id` int NULL DEFAULT NULL,
  `status` tinyint(1) NULL DEFAULT NULL,
  `created_by` int NOT NULL DEFAULT 1,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `modified_by` int NOT NULL DEFAULT 1,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'contain user type information' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sample_collection_types
-- ----------------------------
DROP TABLE IF EXISTS `sample_collection_types`;
CREATE TABLE `sample_collection_types`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'sample_collection_types' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for stakeholder
-- ----------------------------
DROP TABLE IF EXISTS `stakeholder`;
CREATE TABLE `stakeholder`  (
  `pk_id` int NOT NULL AUTO_INCREMENT COMMENT 'stakeholder id',
  `stakeholder_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stkorder` int UNSIGNED NULL DEFAULT NULL COMMENT 'the order in which stakeholder will appear in report or data entry form',
  `parent_id` int NULL DEFAULT NULL,
  `stk_type_id` int NULL DEFAULT 0,
  `level` int NULL DEFAULT NULL,
  `is_reporting` tinyint NULL DEFAULT 1,
  `logo` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `background_image` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `extra_css` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `code` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `url` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_date` date NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `stkid`(`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'contain information about stakeholders' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for stakeholder_generic_names
-- ----------------------------
DROP TABLE IF EXISTS `stakeholder_generic_names`;
CREATE TABLE `stakeholder_generic_names`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `product_generic_id` int NULL DEFAULT NULL,
  `stakeholder_id` int NULL DEFAULT NULL,
  `created_date` date NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Fixed;

-- ----------------------------
-- Table structure for stakeholder_products
-- ----------------------------
DROP TABLE IF EXISTS `stakeholder_products`;
CREATE TABLE `stakeholder_products`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NULL DEFAULT NULL,
  `stakeholder_id` int NULL DEFAULT NULL,
  `created_date` date NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  UNIQUE INDEX `product_id`(`product_id`, `stakeholder_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 7584 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Fixed;

-- ----------------------------
-- Table structure for stock_batch
-- ----------------------------
DROP TABLE IF EXISTS `stock_batch`;
CREATE TABLE `stock_batch`  (
  `batch_id` int NOT NULL AUTO_INCREMENT,
  `batch_number` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `batch_expiry` date NULL DEFAULT NULL,
  `item_id` int NULL DEFAULT NULL,
  `quantity` bigint NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `funding_source` int NULL DEFAULT NULL,
  `manufacturer` int NULL DEFAULT NULL,
  `manufacturing_date` date NULL DEFAULT NULL,
  PRIMARY KEY (`batch_id`) USING BTREE,
  INDEX `batch_id`(`batch_id`) USING BTREE,
  INDEX `item_id`(`item_id`) USING BTREE,
  INDEX `wh_id`(`wh_id`) USING BTREE,
  INDEX `funding_source`(`funding_source`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 416 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for stock_detail
-- ----------------------------
DROP TABLE IF EXISTS `stock_detail`;
CREATE TABLE `stock_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `stock_master_id` int NULL DEFAULT NULL,
  `batch_id` int NULL DEFAULT NULL,
  `prescribed_quantity` bigint NULL DEFAULT NULL,
  `quantity` bigint NULL DEFAULT NULL,
  `temp` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `PkDetailID`(`pk_id`) USING BTREE,
  INDEX `fkStockID`(`stock_master_id`) USING BTREE,
  INDEX `BatchID`(`batch_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 76577 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for stock_master
-- ----------------------------
DROP TABLE IF EXISTS `stock_master`;
CREATE TABLE `stock_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `transaction_date` date NULL DEFAULT NULL,
  `transaction_type_id` int NULL DEFAULT NULL,
  `transaction_reference` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `warehouse_from` int NULL DEFAULT NULL,
  `warehouse_to` int NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_on` date NULL DEFAULT NULL,
  `remarks` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `temp` tinyint(1) NULL DEFAULT NULL,
  `linked_transaction` int NULL DEFAULT NULL,
  `issuance_to` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `vials_returned` int NULL DEFAULT NULL,
  `mcc_year` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `is_received` int NULL DEFAULT 0,
  `invoice_no` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `PkStockID`(`pk_id`) USING BTREE,
  INDEX `WHIDFrom`(`warehouse_from`) USING BTREE,
  INDEX `WHIDTo`(`warehouse_to`) USING BTREE,
  INDEX `temp`(`temp`) USING BTREE,
  INDEX `TranTypeID`(`transaction_type_id`) USING BTREE,
  INDEX `TranTypeID_3`(`transaction_type_id`, `warehouse_from`) USING BTREE,
  INDEX `TranTypeID_2`(`transaction_type_id`, `warehouse_from`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 76464 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for transaction_types
-- ----------------------------
DROP TABLE IF EXISTS `transaction_types`;
CREATE TABLE `transaction_types`  (
  `trans_id` int NOT NULL AUTO_INCREMENT,
  `trans_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `trans_nature` varchar(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_adjustment` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`trans_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `designation` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `login_id` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `landing_page` int NULL DEFAULT NULL,
  `role_id` int NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL,
  `warehouse_id` int NULL DEFAULT NULL,
  `stakeholder_id` int NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `role_id`(`role_id`) USING BTREE,
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 66 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for vitals
-- ----------------------------
DROP TABLE IF EXISTS `vitals`;
CREATE TABLE `vitals`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  `rank` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for warehouse_categories
-- ----------------------------
DROP TABLE IF EXISTS `warehouse_categories`;
CREATE TABLE `warehouse_categories`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for warehouse_population
-- ----------------------------
DROP TABLE IF EXISTS `warehouse_population`;
CREATE TABLE `warehouse_population`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `facility_total_pouplation` int NULL DEFAULT NULL,
  `estimation_year` year NULL DEFAULT NULL,
  `warehouse_id` int NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `modified_by` int NOT NULL,
  `modified_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 115574 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for warehouse_types
-- ----------------------------
DROP TABLE IF EXISTS `warehouse_types`;
CREATE TABLE `warehouse_types`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `type_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `category_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for warehouses
-- ----------------------------
DROP TABLE IF EXISTS `warehouses`;
CREATE TABLE `warehouses`  (
  `pk_id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `warehouse_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL COMMENT 'province of warehouse',
  `stakeholder_id` int NULL DEFAULT NULL COMMENT 'stakeholder',
  `tehsil_id` int NULL DEFAULT NULL,
  `uc_id` int NULL DEFAULT NULL,
  `city_id` int NULL DEFAULT NULL,
  `province_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `district_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `uc_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tehsil_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `city_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `category_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `facility_type_id` int NULL DEFAULT NULL,
  `facility_type_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stakeholder_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `facility_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_person` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_designation` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_number` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `status` tinyint(1) NULL DEFAULT 1,
  `total_bed_space` int NULL DEFAULT NULL,
  `created_by` int NOT NULL DEFAULT 1,
  `created_date` datetime NULL DEFAULT current_timestamp,
  `modified_by` int NOT NULL DEFAULT 1,
  `modified_date` datetime NOT NULL DEFAULT current_timestamp,
  `longitude` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `latitude` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `parent_hospital_id` int NULL DEFAULT NULL,
  `parent_hospital_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `facility_type_id`(`facility_type_id`) USING BTREE,
  CONSTRAINT `warehouses_ibfk_1` FOREIGN KEY (`facility_type_id`) REFERENCES `warehouse_types` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 47 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'contain information about warehouse' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for wh_data
-- ----------------------------
DROP TABLE IF EXISTS `wh_data`;
CREATE TABLE `wh_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `report_date` date NULL DEFAULT NULL,
  `item_id` int NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `opening` decimal(10, 0) NULL DEFAULT NULL,
  `received` decimal(10, 0) NULL DEFAULT NULL,
  `issued` decimal(10, 0) NULL DEFAULT NULL,
  `closing` decimal(10, 0) NULL DEFAULT NULL,
  `pos_adjustment` decimal(10, 0) NULL DEFAULT NULL,
  `neg_adjustment` decimal(10, 0) NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 166656 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Fixed;

SET FOREIGN_KEY_CHECKS = 1;
